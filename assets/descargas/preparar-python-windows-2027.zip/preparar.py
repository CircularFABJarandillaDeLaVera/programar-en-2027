"""Preparador de entorno para Windows. No requiere paquetes externos previos."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback


ROOT = Path.home() / "Programar2027"
KERNEL = "programar2027"


def run(args):
    print("\n> " + subprocess.list2cmdline([str(a) for a in args]), flush=True)
    with subprocess.Popen([str(a) for a in args], stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, text=True,
                          encoding="utf-8", errors="replace") as proc:
        for line in proc.stdout:
            print(line, end="", flush=True)
        if proc.wait():
            raise RuntimeError("El comando anterior no se ha completado correctamente.")


def refresh_path():
    import winreg
    paths = [os.environ.get("PATH", "")]
    for key, subkey in [(winreg.HKEY_LOCAL_MACHINE,
                         r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"),
                        (winreg.HKEY_CURRENT_USER, r"Environment")]:
        try:
            with winreg.OpenKey(key, subkey) as handle:
                paths.append(os.path.expandvars(winreg.QueryValueEx(handle, "Path")[0]))
        except OSError:
            pass
    os.environ["PATH"] = os.pathsep.join(paths)


def find_code():
    found = shutil.which("code")
    if found:
        return Path(found)
    for base in [Path(os.environ["LOCALAPPDATA"]) / "Programs",
                 Path(os.environ.get("ProgramFiles", r"C:\Program Files")),
                 Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"))]:
        path = base / "Microsoft VS Code" / "bin" / "code.cmd"
        if path.is_file():
            return path
    return None


def install(package, scope=None):
    winget = shutil.which("winget")
    if not winget:
        raise RuntimeError("Falta WinGet. Actualiza Instalador de aplicacion en Microsoft Store y repite.")
    args = [winget, "install", "--id", package, "--exact", "--source", "winget",
            "--accept-source-agreements", "--accept-package-agreements"]
    if scope:
        args += ["--scope", scope]
    run(args)
    refresh_path()


def write_new(path, content):
    # Una segunda ejecucion conserva los ejercicios y configuraciones del alumno.
    if not path.exists():
        path.write_bytes(content.encode("utf-8"))


def main():
    if sys.platform != "win32":
        raise RuntimeError("Este preparador es exclusivo de Windows.")
    if sys.version_info[:2] != (3, 13):
        raise RuntimeError("Ejecuta Preparar_curso.cmd para usar Python 3.13.")
    refresh_path()
    code = find_code()
    if not code:
        install("Microsoft.VisualStudioCode", "user")
        code = find_code()
    if not code:
        raise RuntimeError("No se encuentra VS Code despues de instalarlo.")
    if not shutil.which("git"):
        install("Git.Git")
    if not shutil.which("git"):
        for base in [Path(os.environ.get("ProgramFiles", r"C:\Program Files")),
                     Path(os.environ["LOCALAPPDATA"]) / "Programs"]:
            if (base / "Git" / "cmd" / "git.exe").is_file():
                os.environ["PATH"] += os.pathsep + str(base / "Git" / "cmd")
    if not shutil.which("git"):
        raise RuntimeError("No se encuentra Git. Reinicia Windows y vuelve a ejecutar el preparador.")
    print("\nInstalando extensiones de VS Code...")
    for ext in ["ms-python.python", "MS-CEINTL.vscode-language-pack-es",
                "ms-toolsai.jupyter", "GitHub.copilot-chat"]:
        run([code, "--install-extension", ext])
    env = ROOT / ".venv"
    python = env / "Scripts" / "python.exe"
    if not python.exists():
        run([sys.executable, "-m", "venv", env])
    run([python, "-m", "pip", "install", "ipykernel"])
    run([python, "-m", "ipykernel", "install", "--user", "--name", KERNEL,
         "--display-name", "Python (Programar 2027)"])
    run([python, "-c", "import tkinter, csv, json, datetime, ipykernel; print('Python, Tkinter e ipykernel: OK')"])
    run([python, "-m", "pip", "check"])
    run(["git", "--version"])
    workspace = ROOT / "Programar2027.code-workspace"
    settings = {"folders": [{"path": "."}], "settings": {
        "python.defaultInterpreterPath": str(python),
        "files.encoding": "utf8", "files.autoGuessEncoding": True,
        "python.terminal.executeInFileDir": True,
        "files.exclude": {"**/.venv": True}}}
    write_new(workspace, json.dumps(settings, ensure_ascii=False, indent=2))
    write_new(ROOT / "hola.py", 'nombre = input("¿Cómo te llamas? ")\nprint("Hola,", nombre)\n')
    notebook = {"cells": [{"cell_type": "code", "execution_count": None,
        "metadata": {}, "outputs": [], "source": ["print('¡El cuaderno funciona!')"]}],
        "metadata": {"kernelspec": {"display_name": "Python (Programar 2027)",
                      "language": "python", "name": KERNEL},
                     "language_info": {"name": "python", "version": "3.13"}},
        "nbformat": 4, "nbformat_minor": 5}
    notebook["cells"][0]["id"] = "prueba-curso"
    write_new(ROOT / "prueba.ipynb", json.dumps(notebook, ensure_ascii=False, indent=2))
    # Duplica los porcentajes para las rutas de usuario que los contienen en CMD.
    safe_code = str(code).replace("%", "%%")
    launcher = ('@echo off\r\nchcp 65001 >nul\r\nsetlocal\r\n'
                f'call "{safe_code}" --new-window --locale es "%~dp0Programar2027.code-workspace"\r\n'
                'if errorlevel 1 pause\r\n')
    write_new(ROOT / "Abrir_curso.cmd", launcher)
    write_new(ROOT / ".gitignore", ".venv/\n__pycache__/\n*.log\n")
    print("\nPREPARACION COMPLETADA\nCarpeta: " + str(ROOT))
    print("Abre Abrir_curso.cmd para abrir el espacio de trabajo local en VS Code.")
    print("Completa el inicio de sesion de GitHub/Copilot desde VS Code.")
    # Se abre la carpeta preparada; el alumno decide despues si confia en ella.
    os.startfile(ROOT)


class Tee:
    def __init__(self, console, log):
        self.console, self.log = console, log

    def write(self, data):
        self.console.write(data)
        self.log.write(data)

    def flush(self):
        self.console.flush()
        self.log.flush()


if __name__ == "__main__":
    ROOT.mkdir(parents=True, exist_ok=True)
    with (ROOT / "preparacion.log").open("a", encoding="utf-8") as log:
        original_out, original_err = sys.stdout, sys.stderr
        sys.stdout = Tee(original_out, log)
        sys.stderr = Tee(original_err, log)
        try:
            main()
        except Exception:
            traceback.print_exc()
            print("\nPREPARACION INCOMPLETA. Comparte preparacion.log con el profesor.")
            sys.exit(1)
        finally:
            sys.stdout, sys.stderr = original_out, original_err

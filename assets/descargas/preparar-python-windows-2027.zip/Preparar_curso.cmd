@echo off
setlocal
title Preparar Programar en 2027
echo PREPARAR PROGRAMAR EN 2027 - Windows 10/11
echo Necesitas Internet. Acepta los avisos de los instaladores si procede.
echo Se instalara Python 3.13 y se prepararan VS Code, Git y las extensiones.
echo Cierra VS Code antes de continuar.
pause
if not exist "%~dp0preparar.py" goto falta
set "CURSO_PY="
if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set "CURSO_PY=%LocalAppData%\Programs\Python\Python313\python.exe"
if defined CURSO_PY goto preparar
for /f "delims=" %%P in ('py -3.13 -c "import sys; print(sys.executable)" 2^>nul') do set "CURSO_PY=%%P"
if defined CURSO_PY goto preparar
where winget >nul 2>&1
if errorlevel 1 goto sinwinget
winget install --id Python.Python.3.13 --exact --source winget --scope user --accept-source-agreements --accept-package-agreements
if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set "CURSO_PY=%LocalAppData%\Programs\Python\Python313\python.exe"
if defined CURSO_PY goto preparar
for /f "delims=" %%P in ('py -3.13 -c "import sys; print(sys.executable)" 2^>nul') do set "CURSO_PY=%%P"
if not defined CURSO_PY goto sinpython
:preparar
"%CURSO_PY%" "%~dp0preparar.py"
if errorlevel 1 goto error
echo.
echo PREPARACION COMPLETADA. Lee las instrucciones para GitHub, VS Code y el kernel.
pause
exit /b 0
:falta
echo ERROR: usa Extraer todo sobre el ZIP y conserva juntos los archivos.
goto error
:sinwinget
echo No se encuentra WinGet. Actualiza Instalador de aplicacion desde Microsoft Store.
echo Despues vuelve a ejecutar este archivo. Si el PC esta gestionado, consulta al tecnico.
goto error
:sinpython
echo No se ha podido localizar Python 3.13. Reinicia Windows y vuelve a intentarlo.
:error
echo.
echo NO SE HA COMPLETADO LA PREPARACION.
echo Copia el error o consulta el registro en tu carpeta Programar2027.
pause
exit /b 1

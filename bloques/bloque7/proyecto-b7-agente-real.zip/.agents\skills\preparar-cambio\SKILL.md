---
name: preparar-cambio
description: Preparar un cambio de código antes de editarlo: inspeccionar el proyecto, aclarar lo que falta, definir alcance y criterios de aceptación, y presentar un plan para autorización humana.
---

# Preparar un cambio

Usa este procedimiento cuando la persona quiera crear o modificar código y todavía no exista un plan autorizado para ese cambio. Su resultado es una ficha breve y un plan; no implementes ni cierres el cambio dentro de esta preparación.

## 1. Inspeccionar sin efectos externos

- Lee las instrucciones aplicables, el README útil y el estado de Git.
- Inspecciona los archivos relacionados con la petición.
- Identifica las comprobaciones existentes y las que podrían aplicar.
- Inspecciona los intérpretes Python disponibles y reutiliza uno adecuado si existe.
- Separa hechos observados, requisitos expresados y suposiciones.
- No crees entornos, instales dependencias ni cambies configuración por rutina. No publiques ni ejecutes acciones con efectos externos para preparar el plan.
- Si no puedes ejecutar una comprobación con el entorno disponible, explica el impedimento y propone el siguiente paso.
- No inventes arquitectura, librerías, documentos, arneses ni convenciones.

## 2. Aclarar lo que falta

Averigua, solo cuando no pueda saberse leyendo el proyecto:

- qué quiere conseguir la persona;
- qué ocurre actualmente;
- qué debe conservarse;
- cómo reconoceremos que funciona.

Pregunta de una en una y con lenguaje sencillo. No preguntes lo que ya esté respondido. Si el objetivo o el alcance cambia, vuelve a aclarar solo lo que haya quedado invalidado.

## 3. Presentar la ficha

Muestra en la conversación:

- **Objetivo.**
- **Situación actual y evidencia.**
- **Alcance y límites.**
- **Criterios de aceptación observables.**
- **Archivos que propones modificar.**
- **Comprobaciones disponibles y pendientes.**

En un proyecto nuevo, propone un README inicial solo si hace falta. En un proyecto existente, conserva el README útil y prepara la ficha del cambio en la conversación. No crees documentos automáticamente.

Para este ejercicio, `unittest` forma parte de Python y puede ejecutarse directamente con `python -m unittest -v`. Un fallo del detector de pruebas del editor no demuestra que las pruebas no existan.

## 4. Proponer y esperar

Presenta un plan corto, ordenado y con sus comprobaciones. Espera autorización antes de modificar código.

Si la persona ya aprobó ese plan y alcance, continúa sin repetir la preparación ni pedir la misma autorización. Reabre las preguntas si cambia el objetivo, el alcance o aparece información que invalida el plan.

Las consultas explicativas no requieren iniciar este procedimiento. Este procedimiento no concede permiso para instalar, hacer commits, crear tags, publicar ni realizar acciones externas.

Tras un cambio autorizado, pide y deja constancia de: archivo modificado, líneas cambiadas mediante `git diff` o comparación equivalente, comprobaciones ejecutadas y sus resultados, y elementos que siguen sin verificarse. Si no hay Git, no lo inicialices automáticamente ni finjas disponer de `git diff`: muestra una comparación antes/después si conservaste el original y declara la limitación si no es posible.


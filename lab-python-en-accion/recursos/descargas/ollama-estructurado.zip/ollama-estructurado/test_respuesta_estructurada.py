import json

import pytest
import respuesta_estructurada

from respuesta_estructurada import (
    ACCION_REVISAR_TEMPERATURA,
    FORBIDDEN_TERMS,
    OLLAMA_SCHEMA,
    cargar_contexto_demo,
    decidir_que_hacer,
    generar_explicacion_determinista,
    validar_respuesta_llm,
    construir_payload_ollama,
    explicar_con_llm,
)


class RespuestaOllama:
    status_code = 200

    def __init__(self, contenido):
        self.contenido = contenido

    def raise_for_status(self):
        return None

    def json(self):
        return {"response": self.contenido}


CONTEXTO_DEMO = {"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}
DECISION_DEMO = "REVISAR_TEMPERATURA"


def test_decision_determinista():
    estado = {"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}
    assert decidir_que_hacer(estado) == "REVISAR_TEMPERATURA"


def test_demo_contexto():
    contexto = cargar_contexto_demo()
    assert contexto["dispositivo_id"] == "compostera-cf-01"
    assert contexto["temperatura_c"] == 48
    assert contexto["humedad_pct"] == 60


def test_fiware_sin_fallback_silencioso(monkeypatch):
    def fallo():
        raise RuntimeError("FIWARE no disponible")

    monkeypatch.setattr(respuesta_estructurada, "consultar_fiware_real", fallo)
    with pytest.raises(RuntimeError, match="FIWARE no disponible"):
        respuesta_estructurada.consultar_fiware_real()


def test_schema_ollama_estructura():
    payload = construir_payload_ollama({"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}, "REVISAR_TEMPERATURA")
    assert payload["model"] == "llama3.2:1b"
    assert payload["format"] == OLLAMA_SCHEMA
    assert payload["format"]["required"] == ["explicacion", "accion"]
    assert payload["format"]["additionalProperties"] is False


def test_json_correcto_aceptado():
    payload = {
        "explicacion": "El dispositivo compostera-cf-01 registra 48 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is True
    assert motivo == "RESPUESTA ACEPTADA"


def test_respuesta_real_demo_es_aceptada():
    payload = {
        "explicacion": "El dispositivo compostera-cf-01 registra 48 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is True
    assert motivo == "RESPUESTA ACEPTADA"


def test_respuesta_real_fiware_es_aceptada():
    payload = {
        "explicacion": "El dispositivo compostera-cf-01 registra 43.5 °C y 60 % de humedad. La decisión del sistema es SIN_REVISION_PRIORITARIA.",
        "accion": "El sistema no requiere una revisión prioritaria según las reglas didácticas actuales.",
    }
    ok, motivo = validar_respuesta_llm(payload, "SIN_REVISION_PRIORITARIA", 43.5, 60)
    assert ok is True
    assert motivo == "RESPUESTA ACEPTADA"


def test_parafrasis_de_temperatura_es_aceptada_sin_identificador_interno():
    payload = {
        "explicacion": "La disposición correcta es revisar la temperatura del dispositivo.",
        "accion": "una persona debe revisar la temperatura del dispositivo.",
    }
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is True
    assert motivo == "RESPUESTA ACEPTADA"


def test_explicacion_de_humedad_no_puede_cambiar_decision_de_temperatura():
    payload = {
        "explicacion": "Hay que revisar la humedad del dispositivo.",
        "accion": "Una persona debe revisar la humedad.",
    }
    ok, _ = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_parafrasis_sin_cifras_inventadas_sigue_rechazando_contenido_prohibido():
    payload = {
        "explicacion": "La temperatura puede matar microorganismos.",
        "accion": "Una persona debe revisar la temperatura.",
    }
    ok, _ = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_parafrasis_con_numero_no_permitido_sigue_rechazada():
    payload = {
        "explicacion": "La disposición correcta es revisar la temperatura a 49 °C.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    ok, _ = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_json_estructura_correcta_con_contenido_inventado_descartado():
    payload = {
        "explicacion": "El dispositivo compostera-cf-01 registra 48 °C y 60 % de humedad. Hay microorganismos y condiciones óptimas para la evaporación.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False
    assert "prohibido" in motivo.lower() or "inventado" in motivo.lower() or "respuesta no válida" in motivo.lower()


def test_numeros_modificados_descartado():
    payload = {
        "explicacion": "El dispositivo compostera-cf-01 registra 49 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    ok, _ = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_accion_incompatible_descartada():
    payload = {
        "explicacion": "El dispositivo compostera-cf-01 registra 48 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.",
        "accion": "Una persona debe revisar la humedad del dispositivo.",
    }
    ok, _ = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_ollama_no_disponible_fallback():
    payload = {
        "explicacion": "El dispositivo compostera-cf-01 registra 48 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.",
        "accion": ACCION_REVISAR_TEMPERATURA,
    }
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is True
    assert motivo == "RESPUESTA ACEPTADA"


def test_sin_ia_no_llama_ollama(monkeypatch):
    llamadas = {"count": 0}

    def falla(*args, **kwargs):
        llamadas["count"] += 1
        raise AssertionError("No se debe llamar a Ollama en modo --sin-ia")

    monkeypatch.setattr("respuesta_estructurada.requests.post", falla)
    resultado = generar_explicacion_determinista({"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}, "REVISAR_TEMPERATURA")
    assert "REVISAR_TEMPERATURA" in resultado
    assert llamadas["count"] == 0


def test_llm_no_puede_reemplazar_decision():
    payload = {
        "explicacion": "La decisión del sistema es SIN_REVISION_PRIORITARIA aunque el dato es 48 °C.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    ok, _ = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_blacklist_didactica_esta_presenta():
    assert any(term in FORBIDDEN_TERMS for term in ["microorganismos", "evaporación", "gases tóxicos", "contaminación", "toxicidad"])


def test_microorganismos_sigue_siendodescartada_aunque_json_estructuralmente_correcto():
    payload = {
        "explicacion": "La temperatura provoca la muerte de microorganismos.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    ok, _ = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_explicacion_determinista_formato_esperado():
    texto = generar_explicacion_determinista({"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}, "REVISAR_TEMPERATURA")
    assert "48 °C" in texto
    assert "60 %" in texto
    assert "REVISAR_TEMPERATURA" in texto


def test_respuesta_ollama_valida_se_conserva_sin_fallback(monkeypatch):
    respuesta_modelo = {
        "explicacion": "El dispositivo compostera-cf-01 registra 48 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    monkeypatch.setattr(respuesta_estructurada.requests, "post", lambda *args, **kwargs: RespuestaOllama(json.dumps(respuesta_modelo)))

    resultado = explicar_con_llm(CONTEXTO_DEMO, DECISION_DEMO)

    assert resultado["respuesta_modelo"] == respuesta_modelo
    assert resultado["fallback"] is False
    assert resultado["explicacion"] == respuesta_modelo["explicacion"]
    assert resultado["accion"] == respuesta_modelo["accion"]


def test_respuesta_ollama_invalida_conserva_modelo_y_separa_fallback(monkeypatch):
    respuesta_modelo = {
        "explicacion": "El dispositivo compostera-cf-01 registra 49 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.",
        "accion": "Una persona debe revisar la temperatura del dispositivo.",
    }
    monkeypatch.setattr(respuesta_estructurada.requests, "post", lambda *args, **kwargs: RespuestaOllama(json.dumps(respuesta_modelo)))

    resultado = explicar_con_llm(CONTEXTO_DEMO, DECISION_DEMO)

    assert resultado["respuesta_modelo"] == respuesta_modelo
    assert resultado["fallback"] is True
    assert resultado["explicacion"] == generar_explicacion_determinista(CONTEXTO_DEMO, DECISION_DEMO)
    assert resultado["accion"] == ACCION_REVISAR_TEMPERATURA
    assert resultado["respuesta_modelo"] != {"explicacion": resultado["explicacion"], "accion": resultado["accion"]}


def test_json_invalido_conserva_raw_y_usa_fallback(monkeypatch):
    raw_modelo = "No puedo responder con JSON válido."
    monkeypatch.setattr(respuesta_estructurada.requests, "post", lambda *args, **kwargs: RespuestaOllama(raw_modelo))

    resultado = explicar_con_llm(CONTEXTO_DEMO, DECISION_DEMO)

    assert resultado["raw_modelo"] == raw_modelo
    assert "JSON no válido" in resultado["motivo"]
    assert resultado["fallback"] is True
    assert resultado["explicacion"] == generar_explicacion_determinista(CONTEXTO_DEMO, DECISION_DEMO)


def test_sin_ia_no_conserva_respuesta_modelo_ni_llama_ollama(monkeypatch):
    def no_deberia_llamarse(*args, **kwargs):
        raise AssertionError("No se debe llamar a Ollama en modo --sin-ia")

    monkeypatch.setattr(respuesta_estructurada.requests, "post", no_deberia_llamarse)

    resultado = explicar_con_llm(CONTEXTO_DEMO, DECISION_DEMO, sin_ia=True)

    assert "respuesta_modelo" not in resultado
    assert "raw_modelo" not in resultado
    assert resultado["explicacion"] == generar_explicacion_determinista(CONTEXTO_DEMO, DECISION_DEMO)
    assert resultado["motivo"] == "IA DESACTIVADA (--sin-ia)"

import argparse
import json
import os
import re
from pathlib import Path

import requests


def _normalizar_semantica(texto: str) -> str:
    texto = texto.lower()
    texto = texto.replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u").replace("ü", "u")
    texto = re.sub(r"[^a-z0-9%\s]", " ", texto)
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto


def _accion_es_compatible(accion: str, decision: str) -> bool:
    texto = _normalizar_semantica(accion)
    if decision == "REVISAR_TEMPERATURA":
        return (
            "revisar" in texto
            and "temperatura" in texto
            and "humedad" not in texto
            and "no requiere" not in texto
        )
    if decision == "REVISAR_HUMEDAD":
        return (
            "revisar" in texto
            and "humedad" in texto
            and "temperatura" not in texto
            and "no requiere" not in texto
        )
    if decision == "SIN_REVISION_PRIORITARIA":
        return (
            "no requiere" in texto
            and "revision" in texto
            and "temperatura" not in texto
            and "humedad" not in texto
        )
    if decision == "DATOS_INCOMPLETOS":
        return "datos" in texto and "comprobar" in texto
    return False


def _texto_mantiene_decision(texto: str, decision: str) -> bool:
    texto_normalizado = _normalizar_semantica(texto)
    expresiones = {
        "REVISAR_TEMPERATURA": (
            "revisar la temperatura",
            "comprobar la temperatura",
            "revision de temperatura",
        ),
        "REVISAR_HUMEDAD": (
            "revisar la humedad",
            "comprobar la humedad",
            "revision de humedad",
        ),
        "SIN_REVISION_PRIORITARIA": (
            "no requiere revision prioritaria",
            "no es necesaria una revision prioritaria",
            "sin revision prioritaria",
        ),
        "DATOS_INCOMPLETOS": (
            "faltan datos",
            "datos incompletos",
            "comprobar los datos disponibles",
        ),
    }
    return any(expresion in texto_normalizado for expresion in expresiones.get(decision, ()))

ORION_URL = os.getenv("ORION_URL", "http://localhost:1026").rstrip("/")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:1b")
DEMO_PATH = Path(__file__).with_name("datos_contexto_demo.json")

ACCION_REVISAR_TEMPERATURA = "Una persona debe revisar la temperatura del dispositivo."
ACCION_REVISAR_HUMEDAD = "Una persona debe revisar la humedad del dispositivo."
ACCION_DATOS_INCOMPLETOS = "Una persona debe comprobar los datos disponibles del dispositivo."
ACCION_SIN_REVISION = "El sistema no requiere una revisión prioritaria según las reglas didácticas actuales."

ACCIONES_BASE = {
    "DATOS_INCOMPLETOS": ACCION_DATOS_INCOMPLETOS,
    "REVISAR_TEMPERATURA": ACCION_REVISAR_TEMPERATURA,
    "REVISAR_HUMEDAD": ACCION_REVISAR_HUMEDAD,
    "SIN_REVISION_PRIORITARIA": ACCION_SIN_REVISION,
}

FORBIDDEN_TERMS = (
    "microorganismos",
    "evaporación",
    "gases tóxicos",
    "contaminación",
    "toxicidad",
    "condiciones óptimas",
)

OLLAMA_SCHEMA = {
    "type": "object",
    "properties": {
        "explicacion": {"type": "string"},
        "accion": {"type": "string"},
    },
    "required": ["explicacion", "accion"],
    "additionalProperties": False,
}


def cargar_contexto_demo() -> dict:
    with DEMO_PATH.open("r", encoding="utf-8") as archivo:
        return json.load(archivo)


def consultar_fiware_real(dispositivo_id: str = "compostera-cf-01") -> dict:
    url = f"{ORION_URL}/ngsi-ld/v1/entities/urn:ngsi-ld:Device:{dispositivo_id}"
    try:
        respuesta = requests.get(url, timeout=3)
        if respuesta.status_code == 200:
            datos = respuesta.json()
            return {
                "dispositivo_id": dispositivo_id,
                "temperatura_c": datos.get("temperature", {}).get("value"),
                "humedad_pct": datos.get("humidity", {}).get("value"),
            }
        raise RuntimeError(
            f"FIWARE no disponible: HTTP {respuesta.status_code}. Ejecuta --demo para explorar el flujo con datos de demostración."
        )
    except requests.RequestException as exc:
        raise RuntimeError(
            f"FIWARE no disponible: {exc}. Ejecuta --demo para explorar el flujo con datos de demostración."
        ) from exc


def decidir_que_hacer(contexto: dict) -> str:
    temperatura = contexto.get("temperatura_c")
    humedad = contexto.get("humedad_pct")
    if temperatura is None or humedad is None:
        return "DATOS_INCOMPLETOS"
    if temperatura >= 45:
        return "REVISAR_TEMPERATURA"
    if humedad < 50:
        return "REVISAR_HUMEDAD"
    return "SIN_REVISION_PRIORITARIA"


def generar_explicacion_determinista(contexto: dict, decision: str) -> str:
    dispositivo = contexto.get("dispositivo_id", "compostera-cf-01")
    temperatura = contexto.get("temperatura_c")
    humedad = contexto.get("humedad_pct")
    if temperatura is None or humedad is None:
        return (
            f"El dispositivo {dispositivo} no aporta todos los datos necesarios. "
            f"La decisión del sistema es DATOS_INCOMPLETOS."
        )
    return (
        f"El dispositivo {dispositivo} registra {temperatura} °C y {humedad} % de humedad. "
        f"La decisión del sistema es {decision}."
    )


def construir_payload_ollama(contexto: dict, decision: str) -> dict:
    accion = ACCIONES_BASE.get(decision, ACCIONES_BASE["SIN_REVISION_PRIORITARIA"])
    prompt = (
        "Eres un generador de explicaciones controladas para un sistema industrial.\n"
        "Debes responder con JSON estructurado.\n"
        f"Dispositivo: {contexto.get('dispositivo_id', 'compostera-cf-01')}\n"
        f"Temperatura: {contexto.get('temperatura_c')} °C\n"
        f"Humedad: {contexto.get('humedad_pct')} %\n"
        f"Decisión determinista: {decision}\n"
        f"Acción permitida: {accion}\n"
        "Reglas: no cambies la decisión; no inventes causas ni consecuencias; no modifiques cifras; no añadas información externa; usa solo el contenido factual disponible; responde con JSON con explicacion y accion."
    )
    return {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "format": OLLAMA_SCHEMA,
        "temperature": 0,
    }


def _extraer_json(raw: str):
    if raw is None:
        raise ValueError("JSON no válido: respuesta vacía")
    text = raw.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text, flags=re.IGNORECASE)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidate = text[start:end + 1]
            try:
                return json.loads(candidate)
            except json.JSONDecodeError as exc:
                raise ValueError(f"JSON no válido: {exc}") from exc
        raise ValueError("JSON no válido: no se recibió un objeto JSON")


def validar_respuesta_llm(respuesta: object, decision: str, temperatura: float | int | None, humedad: float | int | None) -> tuple[bool, str]:
    if not isinstance(respuesta, dict):
        return False, "Respuesta no válida: no se recibió JSON válido."

    if "explicacion" not in respuesta or "accion" not in respuesta:
        return False, "Respuesta no válida: faltan campos explicacion o accion."

    explicacion = str(respuesta["explicacion"]).strip()
    accion = str(respuesta["accion"]).strip()
    if not explicacion or not accion:
        return False, "Respuesta no válida: explicacion o accion vacíos."

    if not _accion_es_compatible(accion, decision):
        return False, f"Respuesta no válida: la acción no corresponde a la decisión {decision}."

    text = (explicacion + " " + accion).upper()
    if not _texto_mantiene_decision(text, decision):
        return False, f"Respuesta no válida: la explicación no mantiene la decisión {decision}."

    if any(d for d in ["DATOS_INCOMPLETOS", "REVISAR_TEMPERATURA", "REVISAR_HUMEDAD", "SIN_REVISION_PRIORITARIA"] if d != decision and d in text):
        return False, f"Respuesta no válida: la explicación sustituye la decisión {decision} por otra ruta."

    text_lower = (explicacion + " " + accion).lower()
    terminos_prohibidos = []
    for termino in FORBIDDEN_TERMS:
        if termino in text_lower:
            terminos_prohibidos.append(termino)
    if terminos_prohibidos:
        return False, f"Respuesta no válida: contiene términos prohibidos: {', '.join(terminos_prohibidos)}."

    allowed_numbers = set()
    for value in (temperatura, humedad):
        if value is not None:
            allowed_numbers.add(str(int(value)) if float(value).is_integer() else str(value))

    numbers_found = re.findall(r"(?<![A-Za-z0-9-])\d+(?:[.,]\d+)?(?![A-Za-z0-9-])", explicacion + " " + accion)
    for numero in numbers_found:
        normalized = numero.replace(",", ".")
        if normalized not in {n.replace(",", ".") for n in allowed_numbers}:
            return False, f"Respuesta no válida: contiene número no permitido: {numero}."

    return True, "RESPUESTA ACEPTADA"


def explicar_con_llm(contexto: dict, decision: str, fuente: str = "DATOS DE DEMOSTRACIÓN", sin_ia: bool = False) -> dict:
    accion = ACCIONES_BASE.get(decision, ACCIONES_BASE["SIN_REVISION_PRIORITARIA"])
    fallback = {
        "explicacion": generar_explicacion_determinista(contexto, decision),
        "accion": accion,
        "fallback": True,
        "motivo": "USANDO FALLBACK DETERMINISTA",
        "decision": decision,
        "sin_ia": sin_ia,
        "fuente": fuente,
    }

    if sin_ia:
        return {
            "explicacion": generar_explicacion_determinista(contexto, decision),
            "accion": accion,
            "fallback": False,
            "motivo": "IA DESACTIVADA (--sin-ia)",
            "decision": decision,
            "sin_ia": True,
            "fuente": fuente,
        }

    payload = construir_payload_ollama(contexto, decision)
    try:
        respuesta = requests.post(f"{OLLAMA_URL}/api/generate", json=payload, timeout=20)
        respuesta.raise_for_status()
        raw = respuesta.json().get("response", "")
        parsed = _extraer_json(raw)
        ok, motivo = validar_respuesta_llm(parsed, decision, contexto.get("temperatura_c"), contexto.get("humedad_pct"))
        if ok:
            return {
                "explicacion": str(parsed["explicacion"]).strip(),
                "accion": str(parsed["accion"]).strip(),
                "respuesta_modelo": parsed,
                "fallback": False,
                "motivo": motivo,
                "decision": decision,
                "sin_ia": False,
                "fuente": fuente,
            }
        fallback["respuesta_modelo"] = parsed
        fallback["raw_modelo"] = raw
        fallback["motivo"] = motivo
        return fallback
    except Exception as exc:
        if "raw" in locals():
            fallback["raw_modelo"] = raw
        fallback["motivo"] = str(exc)
        return fallback


def imprimir_resultado(contexto: dict, decision: str, resultado: dict, usa_demo: bool) -> None:
    print(f"FUENTE DE DATOS\n{'DATOS DE DEMOSTRACIÓN' if usa_demo else 'FIWARE REAL'}")
    print("")
    print("CONTEXTO")
    print(f"Dispositivo: {contexto.get('dispositivo_id', 'compostera-cf-01')}")
    print(f"Temperatura: {contexto.get('temperatura_c')} °C")
    print(f"Humedad: {contexto.get('humedad_pct')} %")
    print("")
    print("DECISIÓN LANGGRAPH")
    print(decision)
    print("")
    print("SALIDA ESTRUCTURADA")
    print("JSON SCHEMA ACTIVO")
    print("")

    if resultado.get("sin_ia"):
        print("MODELO")
        print("IA DESACTIVADA (--sin-ia)")
        print("")
        print("EXPLICACIÓN DETERMINISTA")
        print(resultado["explicacion"])
        print("")
        print("ACCIÓN")
        print(resultado["accion"])
        return

    print("MODELO")
    print(OLLAMA_MODEL)
    print("")
    print("RESPUESTA DEL MODELO")
    if "respuesta_modelo" in resultado:
        print(json.dumps(resultado["respuesta_modelo"], ensure_ascii=False, indent=2))
    elif "raw_modelo" in resultado:
        print(resultado["raw_modelo"])
    else:
        print("(sin respuesta del modelo)")
    print("")
    print("VALIDACIÓN SEMÁNTICA")
    if resultado.get("fallback"):
        print("RESPUESTA DESCARTADA")
        print(f"Motivo: {resultado.get('motivo', 'USANDO FALLBACK DETERMINISTA')}")
        print("")
        print("USANDO FALLBACK DETERMINISTA")
    else:
        print("RESPUESTA ACEPTADA")
    print("")
    print("EXPLICACIÓN")
    print(resultado["explicacion"])
    print("")
    print("ACCIÓN")
    print(resultado["accion"])


def main() -> None:
    parser = argparse.ArgumentParser(description="Muestra cómo la API de Ollama + JSON Schema + Python pueden trabajar juntos.")
    parser.add_argument("--demo", action="store_true", help="Usa datos de demostración en lugar de FIWARE real.")
    parser.add_argument("--sin-ia", action="store_true", help="Desactiva el modelo local y usa solo la explicación determinista.")
    parser.add_argument("--dispositivo", default="compostera-cf-01", help="ID del dispositivo a consultar.")
    args = parser.parse_args()

    if args.demo:
        contexto = cargar_contexto_demo()
        contexto["dispositivo_id"] = args.dispositivo
        fuente = "DATOS DE DEMOSTRACIÓN"
        usa_demo = True
    else:
        try:
            contexto = consultar_fiware_real(args.dispositivo)
            fuente = "FIWARE REAL"
            usa_demo = False
        except RuntimeError as exc:
            print(f"ERROR: {exc}")
            print("Recomendación: ejecuta --demo para seguir con la práctica sin FIWARE disponible.")
            raise SystemExit(1) from exc

    decision = decidir_que_hacer(contexto)
    resultado = explicar_con_llm(contexto, decision, fuente=fuente, sin_ia=args.sin_ia)
    imprimir_resultado(contexto, decision, resultado, usa_demo)


if __name__ == "__main__":
    main()

# Experiencia 24 · Una IA que responde con estructura

Este paquete muestra la diferencia entre:

- JSON válido
- contenido válido
- decisión determinista protegida

## Ejecutar sin IA

```bash
python respuesta_estructurada.py --demo --sin-ia
```

## Ejecutar con Ollama local

```bash
python respuesta_estructurada.py --demo
```

## Detecciones didácticas

El validador no acepta:

- cifras distintas a las del contexto
- decisiones distintas a la de LangGraph
- acciones incompatibles
- términos prohibidos como microorganismos, evaporación, gases tóxicos, contaminación o toxicidad

Esto es una validación pedagógica y no una garantía universal contra alucinaciones.

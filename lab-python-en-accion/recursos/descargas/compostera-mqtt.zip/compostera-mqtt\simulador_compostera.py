import json
import time

import paho.mqtt.client as mqtt

BROKER_HOST = "localhost"
BROKER_PORT = 1883
dispositivo_id = "compostera-cf-01"
TOPIC = f"circularfab/dispositivos/{dispositivo_id}/telemetria"
LECTURAS = [
    (24.8, 72),
    (27.3, 70),
    (30.5, 68),
    (33.9, 66),
    (37.2, 64),
    (40.1, 62),
    (42.0, 61),
    (43.5, 60),
]


def main():
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1, client_id="simulador-compostera")
    client.connect(BROKER_HOST, BROKER_PORT, 60)
    client.loop_start()

    try:
        for temperatura_c, humedad_pct in LECTURAS:
            payload = {
                "dispositivo_id": dispositivo_id,
                "temperatura_c": temperatura_c,
                "humedad_pct": humedad_pct,
            }
            print(dispositivo_id.upper())
            print(f"Temperatura: {temperatura_c:.1f} °C")
            print(f"Humedad: {humedad_pct} %")
            print("Publicando en MQTT...\n")
            client.publish(TOPIC, json.dumps(payload), qos=0)
            time.sleep(3)
    except KeyboardInterrupt:
        print("\nSimulador detenido.")
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    main()

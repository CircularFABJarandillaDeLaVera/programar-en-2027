# Experiencia 19 · Una compostera conectada

## La nueva necesidad

Hasta ahora los datos del proyecto han venido de formularios, usuarios, aplicaciones y bases de datos. Ahora queremos observar qué ocurre cuando los datos los genera continuamente una máquina o un sensor.

Todavía no tenemos un sensor físico. Primero simulamos el dispositivo con Python. La secuencia de temperatura y humedad es una **secuencia de demostración plausible**, no un modelo científico del compostaje.

```text
SIMULADOR PYTHON
temperatura + humedad
        ↓ publica
      MQTT
        ↓ distribuye
    MOSQUITTO
        ↓ entrega
MONITOR PYTHON
```

## Conceptos

- **Publicador**: el simulador envía mensajes.
- **Topic**: la dirección lógica del mensaje: `circularfab/dispositivos/compostera-cf-01/telemetria`.
- **Suscriptor**: el monitor escucha mensajes de un topic.

Mosquitto es el broker: un intermediario que recibe mensajes y los entrega a quienes están suscritos.

El monitor escucha `circularfab/dispositivos/+/telemetria`. El símbolo `+` permite aceptar un nivel variable, en este caso cualquier `dispositivo_id`.

## Contrato MQTT

```json
{
  "dispositivo_id": "compostera-cf-01",
  "temperatura_c": 36.8,
  "humedad_pct": 62
}
```

Usamos `dispositivo_id` porque el mismo contrato puede servir para otros dispositivos.

## Tecnologías con responsabilidades distintas

```text
POSTGRESQL → conserva histórico
MQTT       → transporta mensajes entre dispositivos y aplicaciones
FIWARE     → representa contexto actual e interoperable
```

Esta práctica no conecta MQTT con FIWARE.

## Ejecución

1. Crea y activa un entorno Python si corresponde.
2. Instala la dependencia:

```bash
pip install -r requirements.txt
```

3. Levanta únicamente Mosquitto:

```bash
docker compose up -d
```

4. En la Terminal A, inicia el monitor:

```bash
python monitor_compostera.py
```

5. En la Terminal B, inicia el simulador:

```bash
python simulador_compostera.py
```

Observa los mensajes recibidos. Al terminar:

```bash
docker compose down
```

`allow_anonymous true` y la ausencia de persistencia son decisiones para este laboratorio local. No son una configuración de producción.

## Mini-reto

Cambia en `simulador_compostera.py`:

```python
dispositivo_id = "compostera-cf-01"
```

por:

```python
dispositivo_id = "compostera-cf-02"
```

Vuelve a ejecutar el simulador y comprueba que el mismo monitor recibe el nuevo dispositivo. El topic reutilizable y el campo `dispositivo_id` hacen posible ese cambio.

## Puente

Ahora los datos los genera Python simulando un dispositivo.

¿Y si sustituimos el simulador por un sensor real?

Esa será la siguiente necesidad.

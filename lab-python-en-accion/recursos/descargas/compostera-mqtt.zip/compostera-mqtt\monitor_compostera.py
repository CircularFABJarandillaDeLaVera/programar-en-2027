import json

import paho.mqtt.client as mqtt

BROKER_HOST = "localhost"
BROKER_PORT = 1883
TOPIC = "circularfab/dispositivos/+/telemetria"
REQUIRED_FIELDS = {"dispositivo_id", "temperatura_c", "humedad_pct"}


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        client.subscribe(TOPIC)
        print(f"Monitor conectado. Escuchando: {TOPIC}\n")
    else:
        print(f"No se pudo conectar al broker: {reason_code}")


def on_message(client, userdata, message):
    try:
        payload = json.loads(message.payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        print("Mensaje ignorado: no contiene JSON válido.")
        return

    if not REQUIRED_FIELDS.issubset(payload):
        print("Mensaje ignorado: faltan campos del contrato.")
        return

    if not isinstance(payload["dispositivo_id"], str):
        print("Mensaje ignorado: dispositivo_id debe ser texto.")
        return

    print("MENSAJE RECIBIDO")
    print(f"Dispositivo: {payload['dispositivo_id']}")
    print(f"Temperatura: {payload['temperatura_c']} °C")
    print(f"Humedad: {payload['humedad_pct']} %\n")


def main():
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="monitor-compostera")
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(BROKER_HOST, BROKER_PORT, 60)
    print("Monitor de compostera. Pulsa Ctrl+C para detenerlo.\n")

    try:
        client.loop_forever()
    except KeyboardInterrupt:
        print("\nMonitor detenido.")
    finally:
        client.disconnect()


if __name__ == "__main__":
    main()

# LAB — Trabajar con un agente de programación

Pequeño proyecto preparado para practicar un flujo seguro con un agente de programación.

## Objetivo observable

Al principio, el programa acepta una edad negativa:

```text
Nombre: Luis
Edad: -15
Participante registrado: Luis (-15 años)
```

Al terminar la primera parte del laboratorio debe responder:

```text
Nombre: Luis
Edad: -15
Error: la edad debe estar entre 0 y 120 años.
```

Además, las pruebas deben terminar correctamente.

---

## 1. Comprueba el fallo

Ejecuta:

```bash
python app.py
```

Prueba, por ejemplo:

```text
Nombre: Luis
Edad: -15
```

No corrijas todavía el código.

---

## 2. Prepara Git como red de seguridad

Si esta carpeta todavía no es un repositorio Git:

```bash
git init
git add app.py participantes.py test_participantes.py README.md AGENTS.md
git commit -m "inicio: práctica de agentes"
```

> Si Git te pide configurar tu nombre o correo, hazlo siguiendo las indicaciones de tu instalación.

### ¿Para qué sirve `git status`?

Muestra el estado actual del proyecto: qué archivos han cambiado, cuáles son nuevos y cuáles están preparados para guardar.

```bash
git status
```

Es como preguntar:

> “¿Qué ha pasado en mi proyecto desde el último punto guardado?”

### ¿Para qué sirve `git diff`?

Compara el código actual con la versión guardada en Git y muestra exactamente qué líneas se han añadido, eliminado o modificado.

```bash
git diff
```

Es nuestra **lupa** para revisar lo que haya hecho el agente antes de aceptar sus cambios.

---

## 3. Primer prompt: investigar antes de tocar

Puedes utilizar Codex u otro agente que tenga acceso a la carpeta del proyecto.

Prueba este prompt:

```text
Analiza este proyecto y localiza por qué permite registrar edades negativas.
No modifiques ningún archivo todavía.

Explícame:
1. dónde está el problema;
2. qué comportamiento produce;
3. qué archivo necesitarías modificar para corregirlo.
```

### ¿Por qué hacemos esto?

Estamos imponiendo un **alcance**.

Primero queremos que el agente investigue. Separar análisis y modificación reduce el riesgo de que empiece a cambiar archivos antes de comprender el problema.

---

## 4. Segundo prompt: autorizar una modificación pequeña

Cuando estés conforme con el análisis:

```text
Corrige el problema.

Una edad válida debe estar entre 0 y 120 años, ambos incluidos.
Modifica únicamente los archivos estrictamente necesarios.
No añadas dependencias.
No hagas ninguna otra mejora.
Después explica exactamente qué has cambiado.
```

---

## 5. Revisa al agente

Primero:

```bash
git status
```

Pregunta clave:

> ¿Qué archivos ha tocado?

Después:

```bash
git diff
```

Pregunta clave:

> ¿Ha cambiado únicamente lo necesario?

No aceptes automáticamente una modificación solo porque el agente diga que está bien.

---

## 6. Comprueba el resultado

Ejecuta de nuevo:

```bash
python app.py
```

Prueba:

```text
Nombre: Luis
Edad: -15
```

Ahora debería aparecer:

```text
Error: la edad debe estar entre 0 y 120 años.
```

---

## 7. Ejecuta las pruebas

```bash
python -m unittest -v
```

### ¿Para qué sirven las pruebas?

Ejecutar el programa permite comprobar manualmente un caso.

Las pruebas permiten comprobar automáticamente varios comportamientos esperados y ayudan a detectar si una modificación rompe algo que antes funcionaba.

El objetivo es terminar con:

```text
OK
```

---

## 8. Guarda el resultado validado

Cuando hayas revisado el `diff` y las pruebas sean correctas:

```bash
git add participantes.py
git commit -m "fix: validar la edad de participantes"
```

### ¿Para qué sirve `git commit`?

Guarda un punto conocido del proyecto después de revisarlo y validarlo.

El flujo completo es:

```text
AGENTE
  ↓
git status
¿Qué archivos ha tocado?
  ↓
git diff
¿Qué ha cambiado exactamente?
  ↓
EJECUTAR
¿Funciona?
  ↓
PRUEBAS
¿Cumple lo esperado?
  ↓
REVISIÓN HUMANA
¿Aceptamos el cambio?
  ↓
git commit
Guardamos el resultado validado
```

---

# MINI-RETO — Ahora con menos ayuda

Hay un segundo problema:

> El programa permite registrar un participante sin nombre.

Ejemplo:

```text
Nombre:
Edad: 25
Participante registrado:  (25 años)
```

Tu misión es resolverlo trabajando con el agente, pero esta vez decide tú cómo redactar los prompts.

## Criterios de éxito

- El agente debe investigar antes de modificar.
- Un nombre vacío o formado solo por espacios debe rechazarse.
- El mensaje esperado será:

```text
Error: el nombre no puede estar vacío.
```

- Debes revisar `git status` y `git diff`.
- Debes añadir al menos una prueba automática para este caso.
- Debes ejecutar todas las pruebas.
- Solo después debes guardar el cambio con un commit.

---

## Resultado final del laboratorio

No se trata de que “la IA programe por ti”.

Se trata de aprender a trabajar con un agente sin perder el control del proyecto:

```text
ANALIZAR → AUTORIZAR → MODIFICAR → COMPARAR → PROBAR → REVISAR → GUARDAR
```

import json
import os

import httpx
import paho.mqtt.client as mqtt

BROKER_HOST = "localhost"
BROKER_PORT = 1883
TOPIC = "circularfab/dispositivos/+/telemetria"
ORION_LD_URL = os.getenv("ORION_LD_URL", "http://localhost:1026").rstrip("/")
TIMEOUT_ORION_LD = 3.0
CONTEXT = "https://uri.etsi.org/ngsi-ld/v1/ngsi-ld-core-context.jsonld"
REQUIRED_FIELDS = {"dispositivo_id", "temperatura_c", "humedad_pct"}


def construir_id_entidad(dispositivo_id: str) -> str:
    return f"urn:ngsi-ld:Device:{dispositivo_id}"


def construir_entidad(dispositivo_id: str, temperatura_c: float, humedad_pct: int) -> dict:
    return {
        "id": construir_id_entidad(dispositivo_id),
        "type": "Device",
        "temperature": {"type": "Property", "value": temperatura_c},
        "humidity": {"type": "Property", "value": humedad_pct},
        "@context": [CONTEXT],
    }


def publicar_en_fiware(dispositivo_id: str, temperatura_c: float, humedad_pct: int) -> None:
    entidad = construir_entidad(dispositivo_id, temperatura_c, humedad_pct)
    headers = {
        "Content-Type": "application/ld+json",
        "Accept": "application/ld+json",
    }
    entity_id = entidad["id"]
    try:
        with httpx.Client(timeout=TIMEOUT_ORION_LD) as cliente:
            respuesta_patch = cliente.patch(
                f"{ORION_LD_URL}/ngsi-ld/v1/entities/{entity_id}/attrs",
                json={
                    "temperature": {"type": "Property", "value": temperatura_c},
                    "humidity": {"type": "Property", "value": humedad_pct},
                    "@context": [CONTEXT],
                },
                headers=headers,
            )

            if respuesta_patch.status_code == 404:
                respuesta_post = cliente.post(
                    f"{ORION_LD_URL}/ngsi-ld/v1/entities",
                    json=entidad,
                    headers=headers,
                )
                if 200 <= respuesta_post.status_code < 300:
                    print(f"ENTIDAD FIWARE CREADA: {entity_id}")
                    return
                print(f"ERROR al crear entidad FIWARE: {respuesta_post.status_code}")
                return

            if 200 <= respuesta_patch.status_code < 300:
                print(f"ENTIDAD FIWARE ACTUALIZADA: {entity_id}")
                return

            print(f"ERROR al actualizar entidad FIWARE: {respuesta_patch.status_code}")
    except httpx.RequestError as exc:
        print(f"No se pudo conectar con Orion-LD: {exc.__class__.__name__}: {exc}")


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        client.subscribe(TOPIC)
        print(f"Puente conectado. Escuchando: {TOPIC}\n")
    else:
        print(f"No se pudo conectar al broker: {reason_code}")


def on_message(client, userdata, message):
    try:
        payload = json.loads(message.payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        print("Mensaje ignorado: no contiene JSON válido.")
        return

    if not REQUIRED_FIELDS.issubset(payload):
        print("Mensaje ignorado: faltan campos del contrato.")
        return

    if not isinstance(payload["dispositivo_id"], str):
        print("Mensaje ignorado: dispositivo_id debe ser texto.")
        return

    print("MENSAJE MQTT RECIBIDO")
    print(f"Dispositivo: {payload['dispositivo_id']}")
    print(f"Temperatura: {payload['temperatura_c']} °C")
    print(f"Humedad: {payload['humedad_pct']} %")

    publicar_en_fiware(
        payload["dispositivo_id"],
        float(payload["temperatura_c"]),
        int(payload["humedad_pct"]),
    )
    print()


def main():
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="puente-mqtt-fiware")
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(BROKER_HOST, BROKER_PORT, 60)
    print("Puente MQTT -> FIWARE. Pulsa Ctrl+C para detenerlo.\n")

    try:
        client.loop_forever()
    except KeyboardInterrupt:
        print("\nPuente detenido.")
    finally:
        client.disconnect()


if __name__ == "__main__":
    main()

# Experiencia 21 · Del sensor al contexto de la empresa

En esta práctica seguimos usando el simulador de la Experiencia 19 como fuente real de prueba.

```text
SIMULADOR PYTHON
      ↓
     MQTT
      ↓
  MOSQUITTO
      ↓
PUENTE PYTHON
      ↓
   FIWARE
      ↓
CONTEXTO ACTUAL
DE LA EMPRESA
```

> En esta validación seguimos usando el simulador de la Experiencia 19. Cuando hagamos la Experiencia 20, el origen será un sensor real, pero el contrato MQTT y este puente no deberían cambiar.

## Objetivo

- Suscribirse al topic MQTT de la compostera.
- Validar el JSON del contrato.
- Transformar la lectura al modelo FIWARE usado en este curso.
- Crear o actualizar la entidad correspondiente en Orion-LD.
- Mostrar en terminal qué recibió y qué envió.

## Contrato MQTT

```json
{
  "dispositivo_id": "compostera-cf-01",
  "temperatura_c": 36.8,
  "humedad_pct": 62
}
```

Topic reuse:

```text
circularfab/dispositivos/+/telemetria
```

## Modelo FIWARE

La práctica usa el mismo estilo del curso en 17 y 18:

```json
{
  "id": "urn:ngsi-ld:Device:compostera-cf-01",
  "type": "Device",
  "temperature": {
    "type": "Property",
    "value": 36.8
  },
  "humidity": {
    "type": "Property",
    "value": 62
  },
  "@context": [
    "https://uri.etsi.org/ngsi-ld/v1/ngsi-ld-core-context.jsonld"
  ]
}
```

## Requisitos

1. Tener arrancado Mosquitto local.
2. Tener Orion-LD funcionando en `http://localhost:1026`.
3. Instalar dependencias:

```bash
pip install -r requirements.txt
```

## Ejecutar

### 1) Arrancar Mosquitto

```bash
docker compose up -d
```

### 2) Arrancar FIWARE local

Usa la infraestructura local ya preparada en la experiencia 17/18 y revisa que Orion-LD responda:

```bash
curl http://localhost:1026/version
```

### 3) Lanzar el puente

Terminal A:

```bash
python puente_mqtt_fiware.py
```

### 4) Lanzar el simulador

Terminal B:

```bash
python simulador_compostera.py
```

## Qué deberías ver

En la terminal del puente verás algo parecido a:

```text
MENSAJE MQTT RECIBIDO
Dispositivo: compostera-cf-01
Temperatura: 36.8 °C
Humedad: 62 %

ENTIDAD FIWARE ENVIADA
id: urn:ngsi-ld:Device:compostera-cf-01
JSON: {...}
```

Y en Orion-LD puedes consultar:

```bash
curl http://localhost:1026/ngsi-ld/v1/entities/urn:ngsi-ld:Device:compostera-cf-01
```

## Mini-reto

Cambia en `simulador_compostera.py`:

```python
dispositivo_id = "compostera-cf-01"
```

por:

```python
dispositivo_id = "compostera-cf-02"
```

Comprueba que:

- MQTT sigue funcionando;
- el puente recibe el nuevo dispositivo;
- FIWARE crea o actualiza una entidad distinta;
- no hace falta modificar el puente.

Eso refuerza que el contrato es reutilizable y que `dispositivo_id` es la clave de diferenciación.

## Puente pedagógico

Ya tenemos personas y dispositivos representados como contexto.

¿Qué podemos hacer cuando queremos razonar automáticamente sobre todo ese contexto?

Sin resolverlo todavía, queda planteada la siguiente etapa: razonamiento sobre contexto, no solo representación.

## Limites

- No hay sensor real ni ESP32.
- No se añade PostgreSQL nuevo.
- No se crea dashboard ni alertas.
- No se implementan decisiones automáticas.
- Esta práctica no sustituye la experiencia 20.

## Cierre

Cuando la Exp 20 conecte un sensor real, el contrato MQTT y el puente de contexto deberían seguir siendo iguales. La diferencia estará en la fuente del dato, no en el patrón de integración.

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


TipoFichaje = Literal["ENTRADA", "SALIDA"]
RolUsuario = Literal["EMPRESA", "TRABAJADOR"]
EstadoDashboard = Literal["TRABAJANDO", "FUERA", "SIN ACTIVIDAD"]


class TrabajadorEntrada(BaseModel):
    nombre: str = Field(min_length=1, max_length=80)


class Trabajador(TrabajadorEntrada):
    id: int


class TrabajadorConUsuarioEntrada(TrabajadorEntrada):
    usuario: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=8, max_length=120)


class FichajeEntrada(BaseModel):
    latitud: float | None = Field(default=None, ge=-90, le=90)
    longitud: float | None = Field(default=None, ge=-180, le=180)
    precision_m: float | None = Field(default=None, ge=0)


class Fichaje(BaseModel):
    id: int
    trabajador_id: int
    trabajador_nombre: str
    tipo: TipoFichaje
    fecha_hora: datetime
    latitud: float | None = None
    longitud: float | None = None
    precision_m: float | None = None


class LoginEntrada(BaseModel):
    usuario: str = Field(min_length=1, max_length=80)
    password: str = Field(min_length=1, max_length=120)


class UsuarioSesion(BaseModel):
    id: int
    usuario: str
    rol: RolUsuario
    trabajador_id: int | None = None
    trabajador_nombre: str | None = None


class EstadoTrabajador(BaseModel):
    entrada_abierta: bool
    ultimo_fichaje: TipoFichaje | None = None


class ResumenTrabajador(BaseModel):
    trabajador_id: int
    nombre: str
    estado: EstadoDashboard
    ultimo_fichaje: TipoFichaje | None = None
    ultima_actividad: datetime | None = None
    tiempo_cerrado_hoy_minutos: int


class ResumenEmpresa(BaseModel):
    fecha_local: str
    zona_horaria: str
    trabajando_ahora: int
    entradas_hoy: int
    salidas_hoy: int
    ultima_actividad: Fichaje | None = None
    trabajadores: list[ResumenTrabajador]

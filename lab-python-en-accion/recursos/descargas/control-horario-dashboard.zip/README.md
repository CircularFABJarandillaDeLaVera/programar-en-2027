# Control horario con dashboard de empresa

En la practica anterior la aplicacion ya permitia fichar con geolocalizacion, autenticacion y roles.

Ahora aparece una necesidad nueva:

```text
Tenemos fichajes guardados,
pero una lista de filas no siempre responde rapido a preguntas utiles.
```

Idea central:

```text
DATO != INFORMACION
```

La empresa necesita saber, por ejemplo:

- cuantas personas estan trabajando ahora;
- cuantas entradas se han registrado hoy;
- cuantas salidas se han registrado hoy;
- cuanto tiempo registrado lleva hoy cada trabajador;
- cual ha sido la ultima actividad.

## 1. Que queremos comprobar

Queremos validar este recorrido desde la interfaz de empresa:

```text
EMPRESA
  -> inicia sesion
  -> consulta Resumen de hoy
  -> ve tarjetas de metricas
  -> revisa estado de cada trabajador
  -> actualiza los datos tras nuevos fichajes
```

Y conservar lo anterior:

```text
TRABAJADOR -> ficha entrada/salida
FastAPI -> aplica reglas
PostgreSQL -> conserva datos
```

## 2. Preparar PostgreSQL

Puedes reutilizar el PostgreSQL con volumen de las practicas anteriores.

Si necesitas arrancar uno nuevo para `control_horario`:

```bash
docker volume create postgres_control_horario

docker run --name postgres-control-horario -e POSTGRES_USER=python -e POSTGRES_PASSWORD=CONTRASENA_DE_EJEMPLO -e POSTGRES_DB=control_horario -p 5432:5432 -v postgres_control_horario:/var/lib/postgresql/data -d postgres:16
```

Si ya existe y esta parado:

```bash
docker start postgres-control-horario
```

Usa una contrasena de practica y pon la misma en `.env`.

## 3. Preparar .env

Copia el archivo de ejemplo:

```bash
copy .env.example .env
```

En PowerShell:

```powershell
Copy-Item .env.example .env
```

Completa las variables:

```text
DB_HOST=localhost
DB_PORT=5432
DB_NAME=control_horario
DB_USER=python
DB_PASSWORD=CONTRASENA_DE_EJEMPLO
EMPRESA_USUARIO=empresa
EMPRESA_PASSWORD=password123
APP_TIMEZONE=Europe/Madrid
```

`EMPRESA_USUARIO` y `EMPRESA_PASSWORD` se usan para crear el primer usuario de empresa si todavia no existe.

`APP_TIMEZONE` indica que zona horaria se usa para interpretar "hoy".

La base guarda las fechas en UTC. Para mostrar el resumen de hoy, la aplicacion calcula el inicio y el fin del dia local y los convierte a UTC antes de filtrar fichajes.

No uses offsets fijos como `+01` o `+02`, porque cambian con el horario de verano.

En Windows, Python puede necesitar `tzdata` para encontrar zonas como `Europe/Madrid`. Por eso esta practica la incluye como dependencia de datos horarios.

El archivo `.env` no debe subirse a Git. Por eso esta en `.gitignore`.

## 4. Crear entorno e instalar dependencias

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 5. Arrancar FastAPI

```bash
uvicorn main:app --reload
```

Swagger sigue disponible para revisar la API:

```text
http://localhost:8000/docs
```

## 6. Entrar como empresa

Abre:

```text
http://localhost:8000/app/empresa/
```

Inicia sesion con el usuario y password que hayas configurado en `.env`.

Desde esa pantalla:

1. Crea un trabajador.
2. Dale un usuario.
3. Dale un password inicial de al menos 8 caracteres.
4. Comprueba que aparece en la lista.
5. Revisa la seccion "Resumen de hoy".

El resumen muestra:

- trabajadores trabajando ahora;
- entradas registradas hoy;
- salidas registradas hoy;
- ultima actividad;
- estado de cada trabajador;
- tiempo registrado hoy.

Estados:

```text
TRABAJANDO
FUERA
SIN ACTIVIDAD
```

`TRABAJANDO` se calcula con el ultimo fichaje conocido del trabajador, no solo con los fichajes de hoy.

El tiempo registrado hoy solo suma tramos completos:

```text
ENTRADA -> SALIDA -> duracion
```

Si una entrada sigue abierta:

- indica que el trabajador esta TRABAJANDO;
- no inventa una hora de SALIDA;
- no se suma como tramo terminado.

## 7. Entrar como trabajador

Abre:

```text
http://localhost:8000/app/fichar/
```

Inicia sesion con el usuario y password del trabajador creado por la empresa.

Desde esa pantalla:

1. Registra una ENTRADA.
2. Acepta o rechaza la ubicacion.
3. Comprueba que el fichaje aparece en "Mis fichajes".
4. Registra una SALIDA.

La aplicacion conserva la regla anterior:

```text
No puede haber dos ENTRADAS seguidas sin una SALIDA.
No puede haber una SALIDA sin una ENTRADA abierta.
```

Tambien conserva la geolocalizacion:

```text
Con ubicacion -> guarda latitud, longitud y precision_m.
Sin ubicacion -> registra el fichaje con esos campos en NULL.
```

## 8. Comprobar autorizacion

Un trabajador no debe poder usar endpoints administrativos aunque conozca la URL.

Con la sesion de trabajador abierta, prueba en Swagger o con una peticion directa un endpoint reservado a empresa, por ejemplo:

```text
GET /trabajadores
```

El resultado esperado es:

```text
403 Forbidden
```

Esto demuestra la idea principal de la experiencia:

```text
Ocultar botones en HTML no es seguridad.
La autorizacion debe aplicarse en FastAPI.
```

## 9. Que cambia en PostgreSQL

La tabla `trabajadores` se mantiene:

```text
trabajadores
- id
- nombre
```

La tabla `fichajes` se mantiene con geolocalizacion:

```text
fichajes
- id
- trabajador_id
- tipo
- fecha_hora
- latitud
- longitud
- precision_m
```

Se añaden dos tablas nuevas:

```text
usuarios
- id
- usuario
- password_hash
- rol
- trabajador_id
```

```text
sesiones
- token_hash
- usuario_id
- creada_en
- expira_en
```

La contrasena no se guarda en texto plano. Se guarda un hash.

## 10. Pruebas automaticas

Ejecuta:

```bash
python -m unittest
```

Las pruebas comprueban:

- login correcto e incorrecto;
- endpoint protegido sin sesion;
- operaciones permitidas a empresa;
- operaciones prohibidas al trabajador;
- resumen de empresa;
- trabajador sin permiso para ver el resumen;
- resumen sin fichajes;
- trabajador con jornada cerrada;
- trabajador con jornada abierta;
- varios trabajadores;
- varios tramos entrada/salida;
- conteos de entradas y salidas de hoy;
- ultima actividad;
- datos fuera del dia actual sin contaminar contadores;
- fichaje usando la identidad de la sesion;
- reglas anteriores de ENTRADA/SALIDA;
- fichajes con y sin ubicacion;
- separacion de interfaces `/app/empresa/` y `/app/fichar/`.

Estas pruebas no sustituyen la validacion manual con PostgreSQL y navegador real.

## 11. Criterio principal de exito manual

La practica temporal estara validada cuando podamos comprobar:

```text
1. La empresa inicia sesion.
2. La empresa crea un trabajador.
3. El trabajador inicia sesion.
4. El trabajador ficha.
5. El resumen cambia tras nuevos fichajes.
6. Un trabajador trabajando aparece como TRABAJANDO.
7. Un trabajador que ha salido aparece como FUERA.
8. Los contadores de entradas y salidas de hoy son coherentes con PostgreSQL.
9. El trabajador no puede usar endpoints de empresa.
10. FastAPI responde 403 ante operaciones no autorizadas.
11. Las reglas de fichaje y geolocalizacion de la experiencia anterior siguen funcionando.
```

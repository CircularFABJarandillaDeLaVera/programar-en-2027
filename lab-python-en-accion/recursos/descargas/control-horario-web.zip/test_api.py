import unittest
from datetime import datetime, timezone
from unittest.mock import patch

from fastapi.testclient import TestClient

import main
from modelos import Fichaje, Trabajador


class TestApiControlHorario(unittest.TestCase):
    def setUp(self):
        self.parche_inicio = patch("main.inicializar_base_de_datos")
        self.parche_inicio.start()
        self.cliente = TestClient(main.app)

    def tearDown(self):
        self.parche_inicio.stop()

    @patch("main.crear_trabajador_db")
    def test_crear_trabajador_valido(self, crear_trabajador_db):
        crear_trabajador_db.return_value = Trabajador(id=1, nombre="Ana")

        respuesta = self.cliente.post("/trabajadores", json={"nombre": "Ana"})

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json(), {"id": 1, "nombre": "Ana"})

    def test_interfaz_web_se_puede_servir(self):
        respuesta = self.cliente.get("/app/")

        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("text/html", respuesta.headers["content-type"])
        self.assertIn("Control horario", respuesta.text)

    @patch("main.obtener_trabajador_db")
    def test_fichaje_trabajador_inexistente(self, obtener_trabajador_db):
        obtener_trabajador_db.return_value = None

        respuesta = self.cliente.post("/fichajes/entrada", json={"trabajador_id": 999})

        self.assertEqual(respuesta.status_code, 404)
        self.assertEqual(respuesta.json()["detail"], "No existe un trabajador con ese id")

    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_trabajador_db")
    def test_entrada_correcta(self, obtener_trabajador_db, obtener_ultimo_fichaje_db, crear_fichaje_db):
        fecha_hora = datetime(2026, 8, 30, 8, 2, tzinfo=timezone.utc)
        obtener_trabajador_db.return_value = Trabajador(id=1, nombre="Ana")
        obtener_ultimo_fichaje_db.return_value = None
        crear_fichaje_db.return_value = Fichaje(
            id=1,
            trabajador_id=1,
            trabajador_nombre="Ana",
            tipo="ENTRADA",
            fecha_hora=fecha_hora,
        )

        respuesta = self.cliente.post("/fichajes/entrada", json={"trabajador_id": 1})

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json()["tipo"], "ENTRADA")

    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_trabajador_db")
    def test_doble_entrada_rechazada(self, obtener_trabajador_db, obtener_ultimo_fichaje_db):
        obtener_trabajador_db.return_value = Trabajador(id=1, nombre="Ana")
        obtener_ultimo_fichaje_db.return_value = Fichaje(
            id=1,
            trabajador_id=1,
            trabajador_nombre="Ana",
            tipo="ENTRADA",
            fecha_hora=datetime(2026, 8, 30, 8, 2, tzinfo=timezone.utc),
        )

        respuesta = self.cliente.post("/fichajes/entrada", json={"trabajador_id": 1})

        self.assertEqual(respuesta.status_code, 400)
        self.assertIn("SALIDA previa", respuesta.json()["detail"])

    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_trabajador_db")
    def test_salida_correcta(self, obtener_trabajador_db, obtener_ultimo_fichaje_db, crear_fichaje_db):
        obtener_trabajador_db.return_value = Trabajador(id=1, nombre="Ana")
        obtener_ultimo_fichaje_db.return_value = Fichaje(
            id=1,
            trabajador_id=1,
            trabajador_nombre="Ana",
            tipo="ENTRADA",
            fecha_hora=datetime(2026, 8, 30, 8, 2, tzinfo=timezone.utc),
        )
        crear_fichaje_db.return_value = Fichaje(
            id=2,
            trabajador_id=1,
            trabajador_nombre="Ana",
            tipo="SALIDA",
            fecha_hora=datetime(2026, 8, 30, 14, 7, tzinfo=timezone.utc),
        )

        respuesta = self.cliente.post("/fichajes/salida", json={"trabajador_id": 1})

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json()["tipo"], "SALIDA")

    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_trabajador_db")
    def test_doble_salida_rechazada(self, obtener_trabajador_db, obtener_ultimo_fichaje_db):
        obtener_trabajador_db.return_value = Trabajador(id=1, nombre="Ana")
        obtener_ultimo_fichaje_db.return_value = Fichaje(
            id=2,
            trabajador_id=1,
            trabajador_nombre="Ana",
            tipo="SALIDA",
            fecha_hora=datetime(2026, 8, 30, 14, 7, tzinfo=timezone.utc),
        )

        respuesta = self.cliente.post("/fichajes/salida", json={"trabajador_id": 1})

        self.assertEqual(respuesta.status_code, 400)
        self.assertIn("ENTRADA abierta", respuesta.json()["detail"])

    @patch("main.listar_fichajes_de_trabajador_db")
    @patch("main.obtener_trabajador_db")
    def test_historial_de_trabajador(self, obtener_trabajador_db, listar_fichajes_de_trabajador_db):
        obtener_trabajador_db.return_value = Trabajador(id=1, nombre="Ana")
        listar_fichajes_de_trabajador_db.return_value = [
            Fichaje(
                id=1,
                trabajador_id=1,
                trabajador_nombre="Ana",
                tipo="ENTRADA",
                fecha_hora=datetime(2026, 8, 30, 8, 2, tzinfo=timezone.utc),
            ),
            Fichaje(
                id=2,
                trabajador_id=1,
                trabajador_nombre="Ana",
                tipo="SALIDA",
                fecha_hora=datetime(2026, 8, 30, 14, 7, tzinfo=timezone.utc),
            ),
        ]

        respuesta = self.cliente.get("/trabajadores/1/fichajes")

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual([fichaje["tipo"] for fichaje in respuesta.json()], ["ENTRADA", "SALIDA"])


if __name__ == "__main__":
    unittest.main()

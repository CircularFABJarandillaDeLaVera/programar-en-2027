# Control horario con interfaz web

En la practica anterior construimos una API real de control horario:

```text
trabajadores -> fichajes -> ENTRADA / SALIDA -> PostgreSQL
```

Swagger nos sirvio muy bien para desarrollar y probar la API, pero aparece una necesidad evidente:

```text
Un trabajador real no va a utilizar Swagger para fichar.
```

Ahora vamos a anadir una pagina web sencilla para que una persona pueda seleccionar su nombre, pulsar ENTRADA o SALIDA y consultar su historial.

## 1. Que vamos a construir

Queremos pasar de esto:

```text
Swagger
POST /fichajes/entrada
{
  "trabajador_id": 1
}
```

a esto:

```text
Control horario
-> selecciono trabajador
-> pulso FICHAR ENTRADA
-> veo confirmacion
-> pulso FICHAR SALIDA
-> consulto historial
```

La idea importante:

```text
La interfaz no guarda los datos.
La interfaz habla con FastAPI.
FastAPI aplica las reglas.
PostgreSQL conserva los datos.
```

## 2. Arquitectura

FastAPI sirve dos cosas:

```text
FastAPI
|-- API
|-- interfaz web en /app/
```

La aplicacion completa queda asi:

```text
NAVEGADOR
HTML + CSS + JavaScript
        |
        v
      fetch()
        |
        v
      FastAPI
        |
        v
 reglas de negocio
        |
        v
    PostgreSQL
```

No necesitamos herramientas adicionales para la interfaz. La practica sigue siendo pequena para centrarnos en la conexion entre interfaz, API y base de datos.

## 3. Que es fetch()

Hasta ahora enviabamos peticiones desde Swagger.

Ahora JavaScript puede enviarlas por nosotros desde la pagina web.

```text
BOTON
  |
  v
JavaScript
  |
  v
fetch()
  |
  v
FastAPI
  |
  v
PostgreSQL
```

`fetch()` permite que una pagina web envie peticiones HTTP a nuestra API.

Por ejemplo, cuando pulsas FICHAR ENTRADA, JavaScript ejecuta una peticion parecida a:

```text
POST /fichajes/entrada
```

FastAPI decide si la entrada es valida. Si lo es, guarda el fichaje en PostgreSQL.

## 4. Requisitos

Necesitas:

- Python 3.11 o superior.
- PostgreSQL funcionando.
- Un entorno virtual de Python.
- Un navegador web.

PostgreSQL puede ejecutarse con Docker y un volumen, como en las practicas anteriores.

## 5. Arrancar PostgreSQL con Docker

Si no tienes ya un PostgreSQL preparado para `control_horario`, puedes arrancar uno asi:

```bash
docker volume create postgres_control_horario

docker run --name postgres-control-horario -e POSTGRES_USER=python -e POSTGRES_PASSWORD=CONTRASENA_DE_EJEMPLO -e POSTGRES_DB=control_horario -p 5432:5432 -v postgres_control_horario:/var/lib/postgresql/data -d postgres:16
```

Si el contenedor ya existe y esta parado:

```bash
docker start postgres-control-horario
```

Usa una contrasena de practica y recuerda poner la misma en tu archivo `.env`.

## 6. Preparar la conexion

Copia el archivo de ejemplo:

```bash
copy .env.example .env
```

En PowerShell tambien puedes usar:

```powershell
Copy-Item .env.example .env
```

Edita `.env` con los datos de tu PostgreSQL:

```text
DB_HOST=localhost
DB_PORT=5432
DB_NAME=control_horario
DB_USER=python
DB_PASSWORD=CONTRASENA_DE_EJEMPLO
```

El archivo `.env` no debe subirse a Git. Por eso esta en `.gitignore`.

## 7. Crear y activar el entorno virtual

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 8. Ejecutar FastAPI

```bash
uvicorn main:app --reload
```

Puedes comprobar la API en Swagger:

```text
http://127.0.0.1:8000/docs
```

Pero la nueva interfaz esta aqui:

```text
http://127.0.0.1:8000/app/
```

## 9. Primera prueba manual

Abre:

```text
http://127.0.0.1:8000/app/
```

Despues:

1. Mira si Ana aparece en el selector.
2. Si no aparece, crea un trabajador nuevo llamado Luis.
3. Selecciona el trabajador.
4. Pulsa FICHAR ENTRADA.
5. Debe aparecer un mensaje de confirmacion.
6. El historial debe mostrar una ENTRADA con fecha y hora.
7. Pulsa FICHAR ENTRADA otra vez.
8. Debe aparecer un mensaje comprensible de rechazo.
9. Pulsa FICHAR SALIDA.
10. El historial debe mostrar ENTRADA y SALIDA.
11. Pulsa FICHAR SALIDA otra vez.
12. Debe aparecer un mensaje comprensible de rechazo.

La hora se guarda en PostgreSQL como una referencia temporal correcta. La interfaz la presenta en la hora local del navegador para que sea mas facil leerla.

## 10. Comprobar persistencia

Para FastAPI:

```text
CTRL+C
```

Vuelve a arrancarlo:

```bash
uvicorn main:app --reload
```

Abre de nuevo:

```text
http://127.0.0.1:8000/app/
```

Selecciona el trabajador y consulta el historial.

Resultado esperado:

```text
Los fichajes siguen existiendo.
```

## 11. Pruebas automaticas

Las pruebas automaticas comprueban la API y que FastAPI sirve la interfaz:

```bash
python -m unittest
```

Estas pruebas no sustituyen la validacion visual ni la prueba real con PostgreSQL.

La validacion completa se hace usando la pagina en el navegador, fichando entrada y salida, reiniciando FastAPI y comprobando que el historial sigue ahi.

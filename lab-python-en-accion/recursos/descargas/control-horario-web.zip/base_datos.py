import os
from datetime import datetime, timezone

import psycopg
from dotenv import load_dotenv
from psycopg.rows import dict_row

from modelos import Fichaje, TipoFichaje, Trabajador, TrabajadorEntrada


load_dotenv()


def obtener_conexion():
    return psycopg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "control_horario"),
        user=os.getenv("DB_USER", "python"),
        password=os.getenv("DB_PASSWORD", ""),
        row_factory=dict_row,
    )


def inicializar_base_de_datos() -> None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS trabajadores (
                    id SERIAL PRIMARY KEY,
                    nombre VARCHAR(80) NOT NULL
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS fichajes (
                    id SERIAL PRIMARY KEY,
                    trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
                    tipo VARCHAR(10) NOT NULL CHECK (tipo IN ('ENTRADA', 'SALIDA')),
                    fecha_hora TIMESTAMPTZ NOT NULL
                )
                """
            )


def crear_trabajador_db(datos: TrabajadorEntrada) -> Trabajador:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO trabajadores (nombre)
                VALUES (%s)
                RETURNING id, nombre
                """,
                (datos.nombre,),
            )
            fila = cursor.fetchone()

    return Trabajador(**fila)


def listar_trabajadores_db() -> list[Trabajador]:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("SELECT id, nombre FROM trabajadores ORDER BY id")
            filas = cursor.fetchall()

    return [Trabajador(**fila) for fila in filas]


def obtener_trabajador_db(trabajador_id: int) -> Trabajador | None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                "SELECT id, nombre FROM trabajadores WHERE id = %s",
                (trabajador_id,),
            )
            fila = cursor.fetchone()

    if fila is None:
        return None

    return Trabajador(**fila)


def obtener_ultimo_fichaje_db(trabajador_id: int) -> Fichaje | None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    f.id,
                    f.trabajador_id,
                    t.nombre AS trabajador_nombre,
                    f.tipo,
                    f.fecha_hora
                FROM fichajes f
                JOIN trabajadores t ON t.id = f.trabajador_id
                WHERE f.trabajador_id = %s
                ORDER BY f.fecha_hora DESC, f.id DESC
                LIMIT 1
                """,
                (trabajador_id,),
            )
            fila = cursor.fetchone()

    if fila is None:
        return None

    return Fichaje(**fila)


def crear_fichaje_db(trabajador_id: int, tipo: TipoFichaje) -> Fichaje:
    fecha_hora = datetime.now(timezone.utc)

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO fichajes (trabajador_id, tipo, fecha_hora)
                VALUES (%s, %s, %s)
                RETURNING id, trabajador_id, tipo, fecha_hora
                """,
                (trabajador_id, tipo, fecha_hora),
            )
            fichaje = cursor.fetchone()
            cursor.execute(
                "SELECT nombre FROM trabajadores WHERE id = %s",
                (trabajador_id,),
            )
            trabajador = cursor.fetchone()

    return Fichaje(
        id=fichaje["id"],
        trabajador_id=fichaje["trabajador_id"],
        trabajador_nombre=trabajador["nombre"],
        tipo=fichaje["tipo"],
        fecha_hora=fichaje["fecha_hora"],
    )


def listar_fichajes_db() -> list[Fichaje]:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    f.id,
                    f.trabajador_id,
                    t.nombre AS trabajador_nombre,
                    f.tipo,
                    f.fecha_hora
                FROM fichajes f
                JOIN trabajadores t ON t.id = f.trabajador_id
                ORDER BY f.fecha_hora, f.id
                """
            )
            filas = cursor.fetchall()

    return [Fichaje(**fila) for fila in filas]


def listar_fichajes_de_trabajador_db(trabajador_id: int) -> list[Fichaje]:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    f.id,
                    f.trabajador_id,
                    t.nombre AS trabajador_nombre,
                    f.tipo,
                    f.fecha_hora
                FROM fichajes f
                JOIN trabajadores t ON t.id = f.trabajador_id
                WHERE f.trabajador_id = %s
                ORDER BY f.fecha_hora, f.id
                """,
                (trabajador_id,),
            )
            filas = cursor.fetchall()

    return [Fichaje(**fila) for fila in filas]

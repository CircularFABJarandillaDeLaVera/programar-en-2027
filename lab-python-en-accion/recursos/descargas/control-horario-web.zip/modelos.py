from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


TipoFichaje = Literal["ENTRADA", "SALIDA"]


class TrabajadorEntrada(BaseModel):
    nombre: str = Field(min_length=1, max_length=80)


class Trabajador(TrabajadorEntrada):
    id: int


class FichajeEntrada(BaseModel):
    trabajador_id: int = Field(gt=0)


class Fichaje(BaseModel):
    id: int
    trabajador_id: int
    trabajador_nombre: str
    tipo: TipoFichaje
    fecha_hora: datetime

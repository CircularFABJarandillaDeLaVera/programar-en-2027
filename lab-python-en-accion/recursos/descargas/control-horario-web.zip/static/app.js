const selectorTrabajador = document.querySelector("#trabajador");
const historial = document.querySelector("#historial");
const mensaje = document.querySelector("#mensaje");
const formularioTrabajador = document.querySelector("#formulario-trabajador");
const campoNombre = document.querySelector("#nombre-trabajador");
const botonEntrada = document.querySelector("#boton-entrada");
const botonSalida = document.querySelector("#boton-salida");

function mostrarMensaje(texto, tipo = "") {
  mensaje.textContent = texto;
  mensaje.className = `mensaje ${tipo}`.trim();
}

async function pedirJson(url, opciones = {}) {
  const respuesta = await fetch(url, opciones);
  const datos = await respuesta.json();

  if (!respuesta.ok) {
    throw new Error(datos.detail || "No se ha podido completar la operación.");
  }

  return datos;
}

function fechaLocal(fechaIso) {
  return new Intl.DateTimeFormat("es-ES", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(fechaIso));
}

async function cargarTrabajadores() {
  const trabajadores = await pedirJson("/trabajadores");
  selectorTrabajador.innerHTML = "";

  if (trabajadores.length === 0) {
    const opcion = document.createElement("option");
    opcion.value = "";
    opcion.textContent = "Crea un trabajador";
    selectorTrabajador.append(opcion);
    mostrarMensaje("Crea un trabajador para empezar.");
    historial.innerHTML = "";
    return;
  }

  for (const trabajador of trabajadores) {
    const opcion = document.createElement("option");
    opcion.value = trabajador.id;
    opcion.textContent = trabajador.nombre;
    selectorTrabajador.append(opcion);
  }

  await cargarHistorial();
}

async function cargarHistorial() {
  const trabajadorId = selectorTrabajador.value;

  if (!trabajadorId) {
    historial.innerHTML = "";
    return;
  }

  const fichajes = await pedirJson(`/trabajadores/${trabajadorId}/fichajes`);
  historial.innerHTML = "";

  if (fichajes.length === 0) {
    const item = document.createElement("li");
    item.textContent = "Todavía no hay fichajes para este trabajador.";
    historial.append(item);
    return;
  }

  for (const fichaje of fichajes) {
    const item = document.createElement("li");
    item.innerHTML = `
      <span class="tipo">${fichaje.tipo}</span>
      <span class="fecha">${fechaLocal(fichaje.fecha_hora)}</span>
    `;
    historial.append(item);
  }
}

async function crearTrabajador(evento) {
  evento.preventDefault();
  const nombre = campoNombre.value.trim();

  if (!nombre) {
    mostrarMensaje("Escribe un nombre para crear el trabajador.", "error");
    return;
  }

  try {
    const trabajador = await pedirJson("/trabajadores", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre }),
    });
    campoNombre.value = "";
    mostrarMensaje(`${trabajador.nombre} creado correctamente.`, "ok");
    await cargarTrabajadores();
    selectorTrabajador.value = trabajador.id;
    await cargarHistorial();
  } catch (error) {
    mostrarMensaje(error.message, "error");
  }
}

async function fichar(tipo) {
  const trabajadorId = selectorTrabajador.value;

  if (!trabajadorId) {
    mostrarMensaje("Selecciona un trabajador antes de fichar.", "error");
    return;
  }

  try {
    await pedirJson(`/fichajes/${tipo.toLowerCase()}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ trabajador_id: Number(trabajadorId) }),
    });
    mostrarMensaje(`${tipo} registrada correctamente.`, "ok");
    await cargarHistorial();
  } catch (error) {
    mostrarMensaje(error.message, "error");
  }
}

formularioTrabajador.addEventListener("submit", crearTrabajador);
selectorTrabajador.addEventListener("change", cargarHistorial);
botonEntrada.addEventListener("click", () => fichar("ENTRADA"));
botonSalida.addEventListener("click", () => fichar("SALIDA"));

cargarTrabajadores().catch((error) => {
  mostrarMensaje(error.message, "error");
});

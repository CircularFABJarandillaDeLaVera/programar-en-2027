import unittest
from fastapi.testclient import TestClient
import main

class TestApiParticipantes(unittest.TestCase):
    def setUp(self):
        main.participantes.clear()
        main.siguiente_id = 1
        self.cliente = TestClient(main.app)

    def test_inicio(self):
        self.assertEqual(self.cliente.get("/").status_code, 200)

    def test_lista_vacia(self):
        respuesta = self.cliente.get("/participantes")
        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.json(), [])

    def test_crear(self):
        respuesta = self.cliente.post("/participantes", json={"nombre":"Ana","edad":35})
        self.assertEqual(respuesta.status_code, 201)

    def test_consultar_id(self):
        self.cliente.post("/participantes", json={"nombre":"Luis","edad":28})
        self.assertEqual(self.cliente.get("/participantes/1").status_code, 200)

    def test_404(self):
        self.assertEqual(self.cliente.get("/participantes/999").status_code, 404)

    def test_edad_negativa(self):
        self.assertEqual(self.cliente.post("/participantes", json={"nombre":"Marta","edad":-5}).status_code, 422)

if __name__ == "__main__":
    unittest.main()

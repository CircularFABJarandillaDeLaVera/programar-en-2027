# Experiencia 9 · La misma API dentro de Docker

## Objetivo

Partimos de la API FastAPI anterior y respondemos a esta pregunta:

> Funciona en mi ordenador... ¿cómo hago para que funcione igual en otro?

La idea:

```text
MISMA API FASTAPI
      ↓
Dockerfile
      ↓
IMAGEN
      ↓
CONTENEDOR
      ↓
PUERTOS
      ↓
DOCKER HUB
      ↓
OTRO PC
      ↓
MISMA API
```

No vamos a cambiar la API. Vamos a cambiar cómo se ejecuta.

---

## 0. Ubícate

Abre PowerShell dentro de esta carpeta y ejecuta:

```powershell
dir
```

Debes ver:

```text
Dockerfile
.dockerignore
.gitignore
README.md
main.py
modelos.py
requirements.txt
test_api.py
```

Si no aparecen, entra primero en la carpeta correcta.

---

## 1. Comprueba Docker

Comprueba que Docker está instalado:

```powershell
docker --version
```

Comprueba que el motor de Docker está funcionando:

```powershell
docker info
```

Si `docker info` muestra información de `Client` pero falla en `Server` con algo como `dockerDesktopLinuxEngine`, Docker Desktop no está arrancado del todo. Abre Docker Desktop, espera a que termine de iniciar y repite:

```powershell
docker info
```

No continúes con `docker build` mientras `docker info` siga fallando.

---

## 2. Lee el Dockerfile

```dockerfile
FROM python:3.12-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

Lectura sencilla:

- `FROM` -> parte de una imagen base con Python.
- `WORKDIR` -> define la carpeta de trabajo dentro del contenedor.
- `COPY` -> copia archivos desde tu carpeta hacia la imagen.
- `RUN` -> ejecuta una orden durante la construcción de la imagen.
- `EXPOSE` -> documenta que la aplicación usa el puerto 8000.
- `CMD` -> indica qué comando se ejecuta al arrancar el contenedor.

---

## 3. Imagen y contenedor

```text
CÓDIGO + PYTHON + DEPENDENCIAS
              ↓
            IMAGEN
              ↓
          CONTENEDOR
```

- `IMAGEN` -> plantilla preparada.
- `CONTENEDOR` -> una ejecución concreta de esa imagen.

Puedes tener una imagen y arrancar muchos contenedores a partir de ella.

---

## 4. Construye la imagen

Ejecuta:

```powershell
docker build -t participantes-api .
```

Después:

```powershell
docker images
```

Debe aparecer `participantes-api`.

---

## 5. Arranca el contenedor

Ejecuta:

```powershell
docker run --rm -p 8000:8000 participantes-api
```

Abre:

```text
http://127.0.0.1:8000/docs
```

Este es el momento importante: debe aparecer el mismo Swagger de la Experiencia 8.

```text
ANTES:
Windows -> Python local -> FastAPI

AHORA:
Windows -> Docker -> Python del contenedor -> FastAPI
```

La API no ha cambiado. Ha cambiado cómo se ejecuta.

---

## 6. Comprueba el contenedor

Con el contenedor funcionando, abre una segunda terminal y ejecuta:

```powershell
docker ps
```

Durante la validación real apareció:

```text
IMAGE: participantes-api
STATUS: Up
PORTS: 0.0.0.0:8000->8000/tcp
```

La parte de puertos significa:

```text
PC:8000 -> CONTENEDOR:8000
```

El navegador entra por el puerto 8000 de tu PC y Docker lo lleva al puerto 8000 del contenedor.

---

## 7. Mini-reto: cambia el puerto exterior

Detén el contenedor actual y prueba:

```powershell
docker run --rm -p 8080:8000 participantes-api
```

Abre:

```text
http://127.0.0.1:8080/docs
```

Ahora el mapa de puertos es:

```text
PC:8080 -> CONTENEDOR:8000
```

La aplicación sigue escuchando dentro del contenedor en `8000`, pero tú entras desde el PC por `8080`.

---

## 8. Del contenedor local a otro ordenador

Docker Hub es un registro donde podemos publicar imágenes Docker para que otros equipos puedan descargarlas.

Busca tu nombre de usuario en Docker Hub y sustituye `TU_USUARIO_DOCKER` por ese nombre.

Si tu usuario fuese `ana123`, el nombre sería `ana123/participantes-api:1.0`.

```powershell
docker tag participantes-api TU_USUARIO_DOCKER/participantes-api:1.0
```

Lectura:

- `participantes-api` -> nombre local.
- `TU_USUARIO_DOCKER/participantes-api` -> usuario/repositorio en Docker Hub.
- `1.0` -> etiqueta de versión.

Después se publicó:

```powershell
docker push TU_USUARIO_DOCKER/participantes-api:1.0
```

```text
PC 1
  ↓ docker build
IMAGEN
  ↓ docker push
DOCKER HUB
```

---

## 9. Paso final: probar en otro ordenador

En otro ordenador con Docker instalado y arrancado:

```powershell
docker pull TU_USUARIO_DOCKER/participantes-api:1.0
docker run --rm -p 8000:8000 TU_USUARIO_DOCKER/participantes-api:1.0
```

Después abre:

```text
http://127.0.0.1:8000/docs
```

Resultado esperado:

```text
PC 1
  ↓
DOCKER HUB
  ↓
PC 2
  ↓
MISMA API
```

El segundo ordenador no necesita tus archivos Python, tu entorno virtual ni instalar FastAPI manualmente. La aplicación viaja preparada dentro de la imagen Docker.

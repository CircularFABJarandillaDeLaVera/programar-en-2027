# Control horario con geolocalizacion

En la practica anterior ya podiamos fichar desde una pagina web.

Ahora aparece una nueva pregunta:

```text
Una persona puede fichar desde el movil,
pero desde donde esta fichando?
```

En esta practica ampliaremos el fichaje para que el usuario pueda compartir voluntariamente su ubicacion aproximada al registrar una ENTRADA o una SALIDA.

La aplicacion seguira guardando:

- trabajador;
- tipo de fichaje;
- fecha y hora automatica;
- reglas de negocio;
- datos persistentes en PostgreSQL.

Y ahora, si el usuario da permiso, tambien guardara:

- latitud;
- longitud;
- precision aproximada en metros.

## 1. Idea principal

El navegador puede pedir al dispositivo su ubicacion usando `navigator.geolocation`.

Pero hay cuatro ideas importantes:

1. El navegador debe pedir permiso al usuario.
2. El usuario puede aceptar o rechazar el permiso.
3. La precision es aproximada.
4. No debemos asumir que la ubicacion siempre estara disponible.

Flujo:

```text
BOTON FICHAR
     |
     v
navegador pide ubicacion
     |
     v
usuario acepta
     |
     v
latitud + longitud + precision
     |
     v
fetch()
     |
     v
FastAPI
     |
     v
PostgreSQL
```

## 2. Privacidad

La ubicacion es un dato sensible.

La aplicacion no debe obtenerla a escondidas. El usuario debe saber que se va a pedir ubicacion y que puede rechazarlo.

Este MVP no intenta resolver normativa laboral ni RGPD en profundidad. Solo introduce una forma transparente de registrar la ubicacion que el usuario decide compartir al fichar.

## 3. Que ocurre si el usuario rechaza la ubicacion

La aplicacion no debe romperse.

Si el usuario rechaza el permiso, o el navegador no puede obtener la ubicacion, el fichaje se registra igualmente sin coordenadas.

En PostgreSQL se guardan estos campos como `NULL`:

```text
latitud
longitud
precision_m
```

La interfaz muestra un mensaje claro:

```text
Fichaje registrado sin ubicacion.
```

Asi aprendemos que una funcion opcional debe degradar de forma razonable.

## 4. Evolucion de PostgreSQL

La base `control_horario` puede contener datos de practicas anteriores.

No queremos destruirla.

Por eso la aplicacion evoluciona la tabla `fichajes` con columnas nuevas opcionales:

```sql
ALTER TABLE fichajes ADD COLUMN IF NOT EXISTS latitud DOUBLE PRECISION;
ALTER TABLE fichajes ADD COLUMN IF NOT EXISTS longitud DOUBLE PRECISION;
ALTER TABLE fichajes ADD COLUMN IF NOT EXISTS precision_m DOUBLE PRECISION;
```

Los fichajes antiguos siguen siendo validos. Simplemente no tienen ubicacion registrada.

Tambien se mantiene la creacion inicial completa por si partes de una base vacia:

```sql
CREATE TABLE IF NOT EXISTS fichajes (
    id SERIAL PRIMARY KEY,
    trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
    tipo VARCHAR(10) NOT NULL CHECK (tipo IN ('ENTRADA', 'SALIDA')),
    fecha_hora TIMESTAMPTZ NOT NULL,
    latitud DOUBLE PRECISION,
    longitud DOUBLE PRECISION,
    precision_m DOUBLE PRECISION
);
```

Para esta practica basta con guardar numeros sencillos.

## 5. Preparar PostgreSQL

Puedes reutilizar el PostgreSQL con volumen de las practicas anteriores.

Si necesitas arrancar uno nuevo para `control_horario`:

```bash
docker volume create postgres_control_horario

docker run --name postgres-control-horario -e POSTGRES_USER=python -e POSTGRES_PASSWORD=CONTRASENA_DE_EJEMPLO -e POSTGRES_DB=control_horario -p 5432:5432 -v postgres_control_horario:/var/lib/postgresql/data -d postgres:16
```

Si ya existe y esta parado:

```bash
docker start postgres-control-horario
```

Usa una contrasena de practica y pon la misma en `.env`.

## 6. Preparar .env

Copia el archivo de ejemplo:

```bash
copy .env.example .env
```

En PowerShell:

```powershell
Copy-Item .env.example .env
```

Ejemplo:

```text
DB_HOST=localhost
DB_PORT=5432
DB_NAME=control_horario
DB_USER=python
DB_PASSWORD=CONTRASENA_DE_EJEMPLO
```

El archivo `.env` no debe subirse a Git. Por eso esta en `.gitignore`.

## 7. Crear entorno e instalar dependencias

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 8. Arrancar FastAPI

```bash
uvicorn main:app --reload
```

Abre la interfaz en el mismo PC:

```text
http://localhost:8000/app/
```

Swagger sigue disponible para revisar la API:

```text
http://localhost:8000/docs
```

## 9. Localhost, HTTPS y movil

Los navegadores suelen exigir un contexto seguro para permitir geolocalizacion.

Para desarrollo, `localhost` suele tratarse como contexto seguro. Por eso la primera prueba se hara en el mismo PC usando:

```text
http://localhost:8000/app/
```

Si accedes desde otro dispositivo de la red usando una IP local con HTTP, el navegador puede bloquear la geolocalizacion. Esa prueba puede requerir HTTPS o una estrategia adicional.

No resolvemos todavia HTTPS, certificados ni tuneles.

## 10. Prueba manual en el mismo PC

1. Comprueba que PostgreSQL esta funcionando.
2. Arranca FastAPI.
3. Abre `http://localhost:8000/app/`.
4. Selecciona un trabajador.
5. Pulsa FICHAR ENTRADA.
6. El navegador debe pedir permiso para ubicacion.
7. Acepta.
8. Comprueba el mensaje de entrada registrada con ubicacion aproximada.
9. Revisa que el historial muestra latitud, longitud y precision.
10. Abre el enlace Ver ubicacion.
11. Comprueba que el mapa apunta de forma razonable al lugar real.
12. Pulsa FICHAR SALIDA.
13. Repite tambien una prueba rechazando el permiso de ubicacion.
14. Confirma que el fichaje se registra sin ubicacion.
15. Reinicia FastAPI.
16. Vuelve a abrir la interfaz.
17. Comprueba que el historial sigue existiendo.

## 11. Que se muestra en el historial

Con ubicacion aproximada:

```text
ENTRADA
30/08/2026 14:05
Latitud: 40.xxxxx
Longitud: -5.xxxxx
Precision: 12 m
Ver ubicacion
```

Sin ubicacion:

```text
ENTRADA
30/08/2026 14:05
Ubicacion: no registrada
```

`precision_m` es una estimacion del margen de error que proporciona el dispositivo.

No significa precision exacta.

Tener coordenadas no significa tener una posicion exacta:

```text
Precision: 15 m  -> ubicacion razonablemente precisa para una demostracion.
Precision: 70 km -> coordenadas disponibles, pero ubicacion muy imprecisa.
```

La aplicacion no rechaza fichajes por mala precision. Esa podria ser una regla nueva en otra version.

## 12. Pruebas automaticas

Las pruebas automaticas comprueban la API:

```bash
python -m unittest
```

Incluyen fichajes con ubicacion, fichajes sin ubicacion, historial con datos antiguos sin ubicacion y reglas de negocio.

Estas pruebas no sustituyen la validacion real del navegador. `navigator.geolocation` debe comprobarse aceptando y rechazando permisos en un navegador real.

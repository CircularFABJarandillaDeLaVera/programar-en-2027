const selectorTrabajador = document.querySelector("#trabajador");
const historial = document.querySelector("#historial");
const mensaje = document.querySelector("#mensaje");
const formularioTrabajador = document.querySelector("#formulario-trabajador");
const campoNombre = document.querySelector("#nombre-trabajador");
const botonEntrada = document.querySelector("#boton-entrada");
const botonSalida = document.querySelector("#boton-salida");

function mostrarMensaje(texto, tipo = "") {
  mensaje.textContent = texto;
  mensaje.className = `mensaje ${tipo}`.trim();
}

async function pedirJson(url, opciones = {}) {
  const respuesta = await fetch(url, opciones);
  const datos = await respuesta.json();

  if (!respuesta.ok) {
    throw new Error(datos.detail || "No se ha podido completar la operación.");
  }

  return datos;
}

function fechaLocal(fechaIso) {
  return new Intl.DateTimeFormat("es-ES", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(fechaIso));
}

function pedirUbicacion() {
  return new Promise((resolve) => {
    if (!("geolocation" in navigator)) {
      mostrarMensaje("Tu navegador no ha podido obtener la ubicacion. El fichaje se registrara sin ella.");
      resolve(null);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (posicion) => {
        resolve({
          latitud: posicion.coords.latitude,
          longitud: posicion.coords.longitude,
          precision_m: posicion.coords.accuracy,
        });
      },
      () => {
        mostrarMensaje("Has rechazado compartir tu ubicacion. El fichaje se registrara sin ella.");
        resolve(null);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    );
  });
}

function enlaceMapa(fichaje) {
  if (fichaje.latitud === null || fichaje.longitud === null) {
    return "";
  }

  const latitud = encodeURIComponent(fichaje.latitud);
  const longitud = encodeURIComponent(fichaje.longitud);
  return `https://www.openstreetmap.org/?mlat=${latitud}&mlon=${longitud}#map=18/${latitud}/${longitud}`;
}

function textoUbicacion(fichaje) {
  if (fichaje.latitud === null || fichaje.longitud === null) {
    return "Ubicacion: no registrada";
  }

  const precision = fichaje.precision_m === null ? "sin dato" : `${Math.round(fichaje.precision_m)} m`;
  return `Ubicacion aproximada | Latitud: ${fichaje.latitud.toFixed(5)} | Longitud: ${fichaje.longitud.toFixed(5)} | Precision: ${precision}`;
}

async function cargarTrabajadores() {
  const trabajadores = await pedirJson("/trabajadores");
  selectorTrabajador.innerHTML = "";

  if (trabajadores.length === 0) {
    const opcion = document.createElement("option");
    opcion.value = "";
    opcion.textContent = "Crea un trabajador";
    selectorTrabajador.append(opcion);
    mostrarMensaje("Crea un trabajador para empezar.");
    historial.innerHTML = "";
    return;
  }

  for (const trabajador of trabajadores) {
    const opcion = document.createElement("option");
    opcion.value = trabajador.id;
    opcion.textContent = trabajador.nombre;
    selectorTrabajador.append(opcion);
  }

  await cargarHistorial();
}

async function cargarHistorial() {
  const trabajadorId = selectorTrabajador.value;

  if (!trabajadorId) {
    historial.innerHTML = "";
    return;
  }

  const fichajes = await pedirJson(`/trabajadores/${trabajadorId}/fichajes`);
  historial.innerHTML = "";

  if (fichajes.length === 0) {
    const item = document.createElement("li");
    item.textContent = "Todavía no hay fichajes para este trabajador.";
    historial.append(item);
    return;
  }

  for (const fichaje of fichajes) {
    const item = document.createElement("li");
    const mapa = enlaceMapa(fichaje);
    item.innerHTML = `
      <div>
        <span class="tipo">${fichaje.tipo}</span>
        <span class="fecha">${fechaLocal(fichaje.fecha_hora)}</span>
      </div>
      <div class="ubicacion">
        ${textoUbicacion(fichaje)}
        ${mapa ? `<br><a href="${mapa}" target="_blank" rel="noopener">Ver ubicacion</a>` : ""}
      </div>
    `;
    historial.append(item);
  }
}

async function crearTrabajador(evento) {
  evento.preventDefault();
  const nombre = campoNombre.value.trim();

  if (!nombre) {
    mostrarMensaje("Escribe un nombre para crear el trabajador.", "error");
    return;
  }

  try {
    const trabajador = await pedirJson("/trabajadores", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre }),
    });
    campoNombre.value = "";
    mostrarMensaje(`${trabajador.nombre} creado correctamente.`, "ok");
    await cargarTrabajadores();
    selectorTrabajador.value = trabajador.id;
    await cargarHistorial();
  } catch (error) {
    mostrarMensaje(error.message, "error");
  }
}

async function fichar(tipo) {
  const trabajadorId = selectorTrabajador.value;

  if (!trabajadorId) {
    mostrarMensaje("Selecciona un trabajador antes de fichar.", "error");
    return;
  }

  try {
    const ubicacion = await pedirUbicacion();
    const cuerpo = { trabajador_id: Number(trabajadorId) };

    if (ubicacion !== null) {
      cuerpo.latitud = ubicacion.latitud;
      cuerpo.longitud = ubicacion.longitud;
      cuerpo.precision_m = ubicacion.precision_m;
    }

    await pedirJson(`/fichajes/${tipo.toLowerCase()}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cuerpo),
    });
    const detalleUbicacion = ubicacion === null ? "sin ubicacion" : "con ubicacion aproximada";
    mostrarMensaje(`${tipo} registrada correctamente ${detalleUbicacion}.`, "ok");
    await cargarHistorial();
  } catch (error) {
    mostrarMensaje(error.message, "error");
  }
}

formularioTrabajador.addEventListener("submit", crearTrabajador);
selectorTrabajador.addEventListener("change", cargarHistorial);
botonEntrada.addEventListener("click", () => fichar("ENTRADA"));
botonSalida.addEventListener("click", () => fichar("SALIDA"));

cargarTrabajadores().catch((error) => {
  mostrarMensaje(error.message, "error");
});

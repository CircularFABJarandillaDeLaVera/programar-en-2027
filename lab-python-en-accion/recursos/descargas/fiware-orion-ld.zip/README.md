# Broker de contexto con Orion-LD y NGSI-LD

Esta práctica prepara la Experiencia 17.

Todavía no conectamos FastAPI con FIWARE.

Primero queremos comprobar una idea sencilla:

```text
HISTÓRICO != CONTEXTO ACTUAL
```

PostgreSQL responde muy bien a:

```text
¿Qué ocurrió?
```

Por ejemplo:

```text
08:00 ENTRADA
10:00 SALIDA
10:30 ENTRADA
```

Un broker de contexto nos permite publicar y consultar:

```text
¿Cuál es el estado actual?
```

Por ejemplo:

```text
Employee:001
working = true
lastEvent = ENTRADA
lastEventAt = 2026-01-01T10:30:00Z
```

Esto no significa que Orion-LD sea "una base que solo guarda el último dato".

En este proyecto lo usamos para representar y compartir el contexto actual. PostgreSQL seguirá conservando el histórico.

## 1. Requisitos

Necesitas Docker Desktop con Docker Compose.

Comprueba:

```powershell
docker --version
docker compose version
```

## 2. Qué servicios arrancamos

Esta práctica arranca solo dos servicios:

```text
Orion-LD
   ↓
MongoDB propio
```

MongoDB es el almacenamiento interno que necesita Orion-LD.

Importante:

```text
MongoDB de Orion-LD
!=
PostgreSQL del control horario
```

Nuestro PostgreSQL queda fuera de esta primera prueba.

## 3. Arrancar Orion-LD

Desde esta carpeta:

```powershell
docker compose up -d
```

Qué le pedimos:

```text
Arranca Orion-LD y MongoDB en segundo plano.
```

Comprueba los contenedores:

```powershell
docker compose ps
```

Qué esperamos:

```text
orion-ld  Up
mongo     Up
```

## 4. Comprobar el broker

Orion-LD escucha en:

```text
http://localhost:1026
```

Comprueba la versión:

```powershell
Invoke-RestMethod -Uri "http://localhost:1026/version"
```

Qué le pedimos:

```text
Dime si el broker está vivo y qué versión está ejecutando.
```

Qué esperamos:

```text
orionld version : 1.12.0
```

## 5. Conceptos mínimos

ENTIDAD:
la cosa que queremos representar.

ID:
identificador único de esa entidad.

TYPE:
qué clase de cosa es.

PROPERTY:
una característica o estado.

BROKER DE CONTEXTO:
servicio al que podemos decir cuál es el estado actual de algo y preguntárselo después.

NGSI-LD:
forma estandarizada de representar y consultar ese contexto.

## 6. Crear una entidad

Vamos a usar una entidad ficticia. No contiene datos reales de trabajadores.

```text
urn:ngsi-ld:Employee:001
```

Tiene estas propiedades:

- `name`
- `working`
- `lastEvent`
- `lastEventAt`

Creamos la entidad usando el archivo `ejemplos/empleado.json`:

```powershell
Invoke-RestMethod `
  -Method Post `
  -Uri "http://localhost:1026/ngsi-ld/v1/entities" `
  -ContentType "application/ld+json" `
  -InFile "ejemplos/empleado.json"
```

Qué le pedimos:

```text
Guarda en el broker el contexto inicial de Employee:001.
```

Qué esperamos:

```text
No aparece ningún error.
```

Si repites la práctica y la entidad ya existe, la creación puede devolver un conflicto. Para repetir desde cero, elimina primero la entidad de prueba como se indica al final.

## 7. Consultar la entidad

```powershell
Invoke-RestMethod `
  -Uri "http://localhost:1026/ngsi-ld/v1/entities/urn:ngsi-ld:Employee:001" `
  -Headers @{ Accept = "application/ld+json" }
```

Qué le pedimos:

```text
Dime cuál es el contexto actual de Employee:001.
```

Qué esperamos observar:

```text
working = false
lastEvent = SALIDA
```

## 8. Modificar el estado actual

Ahora cambiamos el contexto actual:

```text
working = false → true
lastEvent = SALIDA → ENTRADA
```

No estamos añadiendo una fila histórica como en PostgreSQL.

Estamos actualizando el contexto actual publicado en el broker.

En PowerShell:

```powershell
$actualizacion = @{
  working = @{
    type = "Property"
    value = $true
  }
  lastEvent = @{
    type = "Property"
    value = "ENTRADA"
  }
  lastEventAt = @{
    type = "Property"
    value = "2026-01-01T10:30:00Z"
  }
  "@context" = @(
    "https://uri.etsi.org/ngsi-ld/v1/ngsi-ld-core-context.jsonld"
  )
} | ConvertTo-Json -Depth 10

Invoke-RestMethod `
  -Method Patch `
  -Uri "http://localhost:1026/ngsi-ld/v1/entities/urn:ngsi-ld:Employee:001/attrs" `
  -ContentType "application/ld+json" `
  -Body $actualizacion
```

Qué le pedimos:

```text
Cambia algunas propiedades actuales de Employee:001.
```

Qué esperamos:

```text
No aparece ningún error.
```

## 9. Consultar de nuevo

```powershell
Invoke-RestMethod `
  -Uri "http://localhost:1026/ngsi-ld/v1/entities/urn:ngsi-ld:Employee:001" `
  -Headers @{ Accept = "application/ld+json" }
```

Resultado esperado:

```text
ANTES
Employee:001
working = false
lastEvent = SALIDA

DESPUÉS
Employee:001
working = true
lastEvent = ENTRADA
```

Lo importante es que no hemos creado manualmente una lista de eventos.

Hemos actualizado el contexto actual.

## 10. Mini-reto

Añade una nueva propiedad ficticia:

```text
statusMessage = Disponible
```

Pasos:

1. Analiza la entidad actual.
2. Decide cómo representar la nueva `Property`.
3. Modifícala mediante NGSI-LD.
4. Consulta la entidad.
5. Comprueba que aparece el nuevo valor.

No necesitas conceptos nuevos.

## 11. Limpiar la entidad de prueba

Si quieres repetir la práctica desde cero, elimina la entidad ficticia:

```powershell
Invoke-RestMethod `
  -Method Delete `
  -Uri "http://localhost:1026/ngsi-ld/v1/entities/urn:ngsi-ld:Employee:001"
```

Qué le pedimos:

```text
Borra solo Employee:001 para poder volver a crearla.
```

## 12. Parar la práctica

```powershell
docker compose down
```

Qué le pedimos:

```text
Para Orion-LD y MongoDB.
```

## 13. Qué no estamos haciendo todavía

En esta práctica no conectamos FastAPI con FIWARE.

Eso es intencionado.

Primero queremos entender:

```text
QUÉ ES EL BROKER
y
QUÉ LE ESTAMOS ENVIANDO
```

La siguiente experiencia estudiará:

```text
trabajador ficha ENTRADA
       ↓
PostgreSQL guarda evento
       ↓
FastAPI actualiza Orion-LD
       ↓
Employee:X working = true
```

## 14. Criterio de éxito

La práctica está funcionando si puedes comprobar:

1. Orion-LD responde en `/version`.
2. Puedes crear `Employee:001`.
3. Puedes consultar `Employee:001`.
4. Puedes cambiar `working` de `false` a `true`.
5. Puedes cambiar `lastEvent` de `SALIDA` a `ENTRADA`.
6. Al consultar de nuevo, el cambio aparece.
7. Puedes borrar la entidad de prueba para repetir desde cero.

La conclusión debe quedar clara:

```text
PostgreSQL conserva el histórico de lo ocurrido.
Orion-LD publica el contexto actual que queremos compartir.
```

Interoperable no significa publicar todos los datos.

En esta práctica no publicamos:

- latitud;
- longitud;
- precisión;
- credenciales;
- sesiones;
- hashes;
- histórico completo.

from pathlib import Path

from fastapi import Cookie, Depends, FastAPI, HTTPException, Response, status
from fastapi.staticfiles import StaticFiles
from psycopg.errors import UniqueViolation

from base_datos import (
    crear_fichaje_db,
    crear_sesion_db,
    crear_trabajador_db,
    eliminar_sesion_db,
    inicializar_base_de_datos,
    listar_fichajes_db,
    listar_fichajes_de_trabajador_db,
    listar_trabajadores_db,
    obtener_ultimo_fichaje_db,
    obtener_usuario_por_nombre_db,
    obtener_usuario_por_token_hash_db,
)
from modelos import (
    EstadoTrabajador,
    Fichaje,
    FichajeEntrada,
    LoginEntrada,
    Trabajador,
    TrabajadorConUsuarioEntrada,
    UsuarioSesion,
)
from seguridad import crear_token_hash, crear_token_sesion, verificar_password


COOKIE_SESION = "sesion_control_horario"


app = FastAPI(
    title="API de Control Horario",
    description="MVP con autenticacion, autorizacion, geolocalizacion y PostgreSQL.",
    version="1.0.0",
)

CARPETA_STATIC = Path(__file__).parent / "static"
app.mount("/app", StaticFiles(directory=CARPETA_STATIC, html=True), name="interfaz")


@app.on_event("startup")
def preparar_base_de_datos():
    inicializar_base_de_datos()


def obtener_usuario_actual(sesion_control_horario: str | None = Cookie(default=None)) -> UsuarioSesion:
    if sesion_control_horario is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Debes iniciar sesion",
        )

    usuario = obtener_usuario_por_token_hash_db(crear_token_hash(sesion_control_horario))
    if usuario is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Sesion no valida",
        )

    return usuario


def exigir_empresa(usuario: UsuarioSesion) -> None:
    if usuario.rol != "EMPRESA":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Esta operacion esta reservada a la empresa",
        )


def exigir_trabajador(usuario: UsuarioSesion) -> int:
    if usuario.rol != "TRABAJADOR" or usuario.trabajador_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Esta operacion esta reservada a trabajadores",
        )

    return usuario.trabajador_id


@app.get("/")
def inicio():
    return {
        "mensaje": "API de Control Horario funcionando",
        "documentacion": "/docs",
        "empresa": "/app/empresa/",
        "fichar": "/app/fichar/",
    }


@app.post("/auth/login", response_model=UsuarioSesion)
def login(datos: LoginEntrada, response: Response):
    usuario = obtener_usuario_por_nombre_db(datos.usuario)
    if usuario is None or not verificar_password(datos.password, usuario["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuario o contrasena incorrectos",
        )

    token = crear_token_sesion()
    crear_sesion_db(usuario["id"], crear_token_hash(token))
    response.set_cookie(
        key=COOKIE_SESION,
        value=token,
        httponly=True,
        samesite="lax",
    )
    return UsuarioSesion(
        id=usuario["id"],
        usuario=usuario["usuario"],
        rol=usuario["rol"],
        trabajador_id=usuario["trabajador_id"],
        trabajador_nombre=usuario["trabajador_nombre"],
    )


@app.post("/auth/logout")
def logout(response: Response, sesion_control_horario: str | None = Cookie(default=None)):
    if sesion_control_horario is not None:
        eliminar_sesion_db(crear_token_hash(sesion_control_horario))

    response.delete_cookie(COOKIE_SESION)
    return {"mensaje": "Sesion cerrada"}


@app.get("/auth/me", response_model=UsuarioSesion)
def quien_soy(usuario: UsuarioSesion = Depends(obtener_usuario_actual)):
    return usuario


@app.post("/trabajadores", response_model=Trabajador, status_code=status.HTTP_201_CREATED)
def crear_trabajador(
    datos: TrabajadorConUsuarioEntrada,
    usuario: UsuarioSesion = Depends(obtener_usuario_actual),
):
    exigir_empresa(usuario)

    try:
        return crear_trabajador_db(datos)
    except UniqueViolation:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Ya existe un usuario con ese nombre",
        )


@app.get("/trabajadores", response_model=list[Trabajador])
def listar_trabajadores(usuario: UsuarioSesion = Depends(obtener_usuario_actual)):
    exigir_empresa(usuario)
    return listar_trabajadores_db()


@app.post("/fichajes/entrada", response_model=Fichaje, status_code=status.HTTP_201_CREATED)
def fichar_entrada(datos: FichajeEntrada, usuario: UsuarioSesion = Depends(obtener_usuario_actual)):
    trabajador_id = exigir_trabajador(usuario)
    ultimo_fichaje = obtener_ultimo_fichaje_db(trabajador_id)

    if ultimo_fichaje is not None and ultimo_fichaje.tipo == "ENTRADA":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No se puede registrar otra ENTRADA sin una SALIDA previa",
        )

    return crear_fichaje_db(
        trabajador_id,
        "ENTRADA",
        datos.latitud,
        datos.longitud,
        datos.precision_m,
    )


@app.post("/fichajes/salida", response_model=Fichaje, status_code=status.HTTP_201_CREATED)
def fichar_salida(datos: FichajeEntrada, usuario: UsuarioSesion = Depends(obtener_usuario_actual)):
    trabajador_id = exigir_trabajador(usuario)
    ultimo_fichaje = obtener_ultimo_fichaje_db(trabajador_id)

    if ultimo_fichaje is None or ultimo_fichaje.tipo == "SALIDA":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No se puede registrar una SALIDA sin una ENTRADA abierta",
        )

    return crear_fichaje_db(
        trabajador_id,
        "SALIDA",
        datos.latitud,
        datos.longitud,
        datos.precision_m,
    )


@app.get("/fichajes", response_model=list[Fichaje])
def listar_fichajes(usuario: UsuarioSesion = Depends(obtener_usuario_actual)):
    exigir_empresa(usuario)
    return listar_fichajes_db()


@app.get("/trabajadores/{trabajador_id}/fichajes", response_model=list[Fichaje])
def listar_fichajes_de_trabajador(
    trabajador_id: int,
    usuario: UsuarioSesion = Depends(obtener_usuario_actual),
):
    exigir_empresa(usuario)
    return listar_fichajes_de_trabajador_db(trabajador_id)


@app.get("/yo/fichajes", response_model=list[Fichaje])
def listar_mis_fichajes(usuario: UsuarioSesion = Depends(obtener_usuario_actual)):
    trabajador_id = exigir_trabajador(usuario)
    return listar_fichajes_de_trabajador_db(trabajador_id)


@app.get("/yo/estado", response_model=EstadoTrabajador)
def obtener_mi_estado(usuario: UsuarioSesion = Depends(obtener_usuario_actual)):
    trabajador_id = exigir_trabajador(usuario)
    ultimo_fichaje = obtener_ultimo_fichaje_db(trabajador_id)

    return EstadoTrabajador(
        entrada_abierta=ultimo_fichaje is not None and ultimo_fichaje.tipo == "ENTRADA",
        ultimo_fichaje=None if ultimo_fichaje is None else ultimo_fichaje.tipo,
    )

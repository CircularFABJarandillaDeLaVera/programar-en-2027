const seccionesPrivadas = [
    document.querySelector("#panel"),
    document.querySelector("#alta"),
    document.querySelector("#trabajadores"),
    document.querySelector("#fichajes"),
];

const login = document.querySelector("#login");
const formLogin = document.querySelector("#form-login");
const formTrabajador = document.querySelector("#form-trabajador");
const mensajeLogin = document.querySelector("#mensaje-login");
const mensajeTrabajador = document.querySelector("#mensaje-trabajador");
const usuarioActivo = document.querySelector("#usuario-activo");
const listaTrabajadores = document.querySelector("#lista-trabajadores");
const listaFichajes = document.querySelector("#lista-fichajes");
const botonSalir = document.querySelector("#boton-salir");

function mostrarMensaje(elemento, texto, tipo = "ok") {
    elemento.textContent = texto;
    elemento.className = `mensaje ${tipo}`;
}

function mostrarPanel(usuario) {
    login.classList.add("oculto");
    seccionesPrivadas.forEach((seccion) => seccion.classList.remove("oculto"));
    usuarioActivo.textContent = `Sesion de empresa: ${usuario.usuario}`;
}

function ocultarPanel() {
    login.classList.remove("oculto");
    seccionesPrivadas.forEach((seccion) => seccion.classList.add("oculto"));
    usuarioActivo.textContent = "";
}

async function leerRespuesta(respuesta) {
    const datos = await respuesta.json().catch(() => ({}));
    if (!respuesta.ok) {
        throw new Error(datos.detail || "No se pudo completar la operacion");
    }
    return datos;
}

async function cargarTrabajadores() {
    const respuesta = await fetch("/trabajadores");
    const trabajadores = await leerRespuesta(respuesta);

    if (trabajadores.length === 0) {
        listaTrabajadores.innerHTML = '<p class="muted">Todavia no hay trabajadores.</p>';
        return;
    }

    listaTrabajadores.innerHTML = trabajadores
        .map((trabajador) => `
            <article class="item">
                <strong>${trabajador.nombre}</strong>
                <span class="muted">ID ${trabajador.id}</span>
            </article>
        `)
        .join("");
}

async function cargarFichajes() {
    const respuesta = await fetch("/fichajes");
    const fichajes = await leerRespuesta(respuesta);

    if (fichajes.length === 0) {
        listaFichajes.innerHTML = '<p class="muted">Todavia no hay fichajes.</p>';
        return;
    }

    listaFichajes.innerHTML = fichajes
        .map((fichaje) => {
            const fecha = new Date(fichaje.fecha_hora).toLocaleString();
            const ubicacion = fichaje.latitud === null
                ? "Sin ubicacion"
                : `${fichaje.latitud}, ${fichaje.longitud} (${fichaje.precision_m} m)`;

            return `
                <article class="item">
                    <strong>${fichaje.trabajador_nombre} - ${fichaje.tipo}</strong>
                    <span>${fecha}</span><br>
                    <span class="muted">${ubicacion}</span>
                </article>
            `;
        })
        .join("");
}

async function refrescarDatos() {
    await cargarTrabajadores();
    await cargarFichajes();
}

async function comprobarSesion() {
    const respuesta = await fetch("/auth/me");
    if (!respuesta.ok) {
        ocultarPanel();
        return;
    }

    const usuario = await respuesta.json();
    if (usuario.rol !== "EMPRESA") {
        mostrarMensaje(mensajeLogin, "Esta pantalla esta reservada a la empresa", "error");
        ocultarPanel();
        return;
    }

    mostrarPanel(usuario);
    await refrescarDatos();
}

formLogin.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    mostrarMensaje(mensajeLogin, "");

    const datos = {
        usuario: document.querySelector("#login-usuario").value,
        password: document.querySelector("#login-password").value,
    };

    try {
        const respuesta = await fetch("/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datos),
        });
        const usuario = await leerRespuesta(respuesta);

        if (usuario.rol !== "EMPRESA") {
            await fetch("/auth/logout", { method: "POST" });
            throw new Error("Esta pantalla esta reservada a la empresa");
        }

        mostrarPanel(usuario);
        await refrescarDatos();
    } catch (error) {
        mostrarMensaje(mensajeLogin, error.message, "error");
    }
});

formTrabajador.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    mostrarMensaje(mensajeTrabajador, "");

    const datos = {
        nombre: document.querySelector("#trabajador-nombre").value,
        usuario: document.querySelector("#trabajador-usuario").value,
        password: document.querySelector("#trabajador-password").value,
    };

    try {
        const respuesta = await fetch("/trabajadores", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datos),
        });
        await leerRespuesta(respuesta);
        formTrabajador.reset();
        mostrarMensaje(mensajeTrabajador, "Trabajador creado");
        await refrescarDatos();
    } catch (error) {
        mostrarMensaje(mensajeTrabajador, error.message, "error");
    }
});

botonSalir.addEventListener("click", async () => {
    await fetch("/auth/logout", { method: "POST" });
    ocultarPanel();
});

comprobarSesion();

import hashlib
import hmac
import secrets


ITERACIONES = 310_000


def crear_password_hash(password: str) -> str:
    salt = secrets.token_hex(16)
    hash_bytes = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        ITERACIONES,
    )
    return f"pbkdf2_sha256${ITERACIONES}${salt}${hash_bytes.hex()}"


def verificar_password(password: str, password_hash: str) -> bool:
    try:
        algoritmo, iteraciones_texto, salt, hash_guardado = password_hash.split("$")
        iteraciones = int(iteraciones_texto)
    except ValueError:
        return False

    if algoritmo != "pbkdf2_sha256":
        return False

    hash_bytes = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        iteraciones,
    )
    return hmac.compare_digest(hash_bytes.hex(), hash_guardado)


def crear_token_sesion() -> str:
    return secrets.token_urlsafe(32)


def crear_token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()

# Control horario con empresa y trabajador

En la practica anterior la aplicacion ya permitia fichar con geolocalizacion.

Ahora aparece un problema nuevo:

```text
La misma pantalla sirve para todo.
Cualquier persona podria intentar usar operaciones administrativas.
```

En esta practica temporal separamos dos papeles:

- `EMPRESA`: puede crear trabajadores y consultar fichajes.
- `TRABAJADOR`: puede identificarse y registrar sus propios fichajes.

La regla importante no esta solo en el HTML. FastAPI comprueba quien ha iniciado sesion y decide si puede ejecutar cada operacion.

## 1. Que queremos comprobar

Queremos validar este recorrido:

```text
EMPRESA
  -> inicia sesion
  -> crea trabajador con usuario y password
  -> consulta trabajadores y fichajes

TRABAJADOR
  -> inicia sesion
  -> ficha ENTRADA o SALIDA
  -> solo ve sus propios fichajes
```

Y tambien queremos comprobar el caso de seguridad:

```text
TRABAJADOR
  -> intenta llamar a un endpoint de empresa
  -> FastAPI responde 403
```

`403` significa que el servidor ha entendido la peticion, pero no permite realizar esa operacion a ese usuario.

## 2. Preparar PostgreSQL

Puedes reutilizar el PostgreSQL con volumen de las practicas anteriores.

Si necesitas arrancar uno nuevo para `control_horario`:

```bash
docker volume create postgres_control_horario

docker run --name postgres-control-horario -e POSTGRES_USER=python -e POSTGRES_PASSWORD=CONTRASENA_DE_EJEMPLO -e POSTGRES_DB=control_horario -p 5432:5432 -v postgres_control_horario:/var/lib/postgresql/data -d postgres:16
```

Si ya existe y esta parado:

```bash
docker start postgres-control-horario
```

Usa una contrasena de practica y pon la misma en `.env`.

## 3. Preparar .env

Copia el archivo de ejemplo:

```bash
copy .env.example .env
```

En PowerShell:

```powershell
Copy-Item .env.example .env
```

Completa las variables:

```text
DB_HOST=localhost
DB_PORT=5432
DB_NAME=control_horario
DB_USER=python
DB_PASSWORD=CONTRASENA_DE_EJEMPLO
EMPRESA_USUARIO=empresa
EMPRESA_PASSWORD=password123
```

`EMPRESA_USUARIO` y `EMPRESA_PASSWORD` se usan para crear el primer usuario de empresa si todavia no existe.

El archivo `.env` no debe subirse a Git. Por eso esta en `.gitignore`.

## 4. Crear entorno e instalar dependencias

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 5. Arrancar FastAPI

```bash
uvicorn main:app --reload
```

Swagger sigue disponible para revisar la API:

```text
http://localhost:8000/docs
```

## 6. Entrar como empresa

Abre:

```text
http://localhost:8000/app/empresa/
```

Inicia sesion con el usuario y password que hayas configurado en `.env`.

Desde esa pantalla:

1. Crea un trabajador.
2. Dale un usuario.
3. Dale un password inicial de al menos 8 caracteres.
4. Comprueba que aparece en la lista.

## 7. Entrar como trabajador

Abre:

```text
http://localhost:8000/app/fichar/
```

Inicia sesion con el usuario y password del trabajador creado por la empresa.

Desde esa pantalla:

1. Registra una ENTRADA.
2. Acepta o rechaza la ubicacion.
3. Comprueba que el fichaje aparece en "Mis fichajes".
4. Registra una SALIDA.

La aplicacion conserva la regla anterior:

```text
No puede haber dos ENTRADAS seguidas sin una SALIDA.
No puede haber una SALIDA sin una ENTRADA abierta.
```

Tambien conserva la geolocalizacion:

```text
Con ubicacion -> guarda latitud, longitud y precision_m.
Sin ubicacion -> registra el fichaje con esos campos en NULL.
```

## 8. Comprobar autorizacion

Un trabajador no debe poder usar endpoints administrativos aunque conozca la URL.

Con la sesion de trabajador abierta, prueba en Swagger o con una peticion directa un endpoint reservado a empresa, por ejemplo:

```text
GET /trabajadores
```

El resultado esperado es:

```text
403 Forbidden
```

Esto demuestra la idea principal de la experiencia:

```text
Ocultar botones en HTML no es seguridad.
La autorizacion debe aplicarse en FastAPI.
```

## 9. Que cambia en PostgreSQL

La tabla `trabajadores` se mantiene:

```text
trabajadores
- id
- nombre
```

La tabla `fichajes` se mantiene con geolocalizacion:

```text
fichajes
- id
- trabajador_id
- tipo
- fecha_hora
- latitud
- longitud
- precision_m
```

Se añaden dos tablas nuevas:

```text
usuarios
- id
- usuario
- password_hash
- rol
- trabajador_id
```

```text
sesiones
- token_hash
- usuario_id
- creada_en
- expira_en
```

La contrasena no se guarda en texto plano. Se guarda un hash.

## 10. Pruebas automaticas

Ejecuta:

```bash
python -m unittest
```

Las pruebas comprueban:

- login correcto e incorrecto;
- endpoint protegido sin sesion;
- operaciones permitidas a empresa;
- operaciones prohibidas al trabajador;
- fichaje usando la identidad de la sesion;
- reglas anteriores de ENTRADA/SALIDA;
- fichajes con y sin ubicacion;
- separacion de interfaces `/app/empresa/` y `/app/fichar/`.

Estas pruebas no sustituyen la validacion manual con PostgreSQL y navegador real.

## 11. Criterio principal de exito manual

La practica temporal estara validada cuando podamos comprobar:

```text
1. La empresa inicia sesion.
2. La empresa crea un trabajador.
3. El trabajador inicia sesion.
4. El trabajador ficha.
5. El trabajador no puede usar endpoints de empresa.
6. FastAPI responde 403 ante operaciones no autorizadas.
7. Las reglas de fichaje y geolocalizacion de la experiencia anterior siguen funcionando.
```

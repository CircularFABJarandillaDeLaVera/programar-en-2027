const seccionesPrivadas = [
    document.querySelector("#panel"),
    document.querySelector("#acciones"),
    document.querySelector("#historial"),
];

const login = document.querySelector("#login");
const formLogin = document.querySelector("#form-login");
const mensajeLogin = document.querySelector("#mensaje-login");
const mensajeFichaje = document.querySelector("#mensaje-fichaje");
const usuarioActivo = document.querySelector("#usuario-activo");
const estado = document.querySelector("#estado");
const listaFichajes = document.querySelector("#lista-fichajes");
const botonEntrada = document.querySelector("#boton-entrada");
const botonSalida = document.querySelector("#boton-salida");
const botonSalir = document.querySelector("#boton-salir");
let estadoActual = null;

function mostrarMensaje(elemento, texto, tipo = "ok") {
    elemento.textContent = texto;
    elemento.className = `mensaje ${tipo}`;
}

function mostrarPanel(usuario) {
    login.classList.add("oculto");
    seccionesPrivadas.forEach((seccion) => seccion.classList.remove("oculto"));
    usuarioActivo.textContent = `Trabajador: ${usuario.trabajador_nombre}`;
}

function ocultarPanel() {
    login.classList.remove("oculto");
    seccionesPrivadas.forEach((seccion) => seccion.classList.add("oculto"));
    usuarioActivo.textContent = "";
}

async function leerRespuesta(respuesta) {
    const datos = await respuesta.json().catch(() => ({}));
    if (!respuesta.ok) {
        throw new Error(datos.detail || "No se pudo completar la operacion");
    }
    return datos;
}

function pedirUbicacion() {
    return new Promise((resolve) => {
        if (!navigator.geolocation) {
            resolve({});
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (posicion) => {
                resolve({
                    latitud: posicion.coords.latitude,
                    longitud: posicion.coords.longitude,
                    precision_m: posicion.coords.accuracy,
                });
            },
            () => resolve({}),
            { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 },
        );
    });
}

async function cargarEstado() {
    const respuesta = await fetch("/yo/estado");
    const datos = await leerRespuesta(respuesta);
    estadoActual = datos;

    if (datos.entrada_abierta) {
        estado.textContent = "Tienes una ENTRADA abierta. El siguiente fichaje debe ser una SALIDA.";
    } else {
        estado.textContent = "No tienes una ENTRADA abierta. El siguiente fichaje debe ser una ENTRADA.";
    }
}

async function cargarFichajes() {
    const respuesta = await fetch("/yo/fichajes");
    const fichajes = await leerRespuesta(respuesta);

    if (fichajes.length === 0) {
        listaFichajes.innerHTML = '<p class="muted">Todavia no tienes fichajes.</p>';
        return;
    }

    listaFichajes.innerHTML = fichajes
        .map((fichaje) => {
            const fecha = new Date(fichaje.fecha_hora).toLocaleString();
            const ubicacion = fichaje.latitud === null
                ? "Sin ubicacion"
                : `<a href="https://www.openstreetmap.org/?mlat=${fichaje.latitud}&mlon=${fichaje.longitud}#map=18/${fichaje.latitud}/${fichaje.longitud}" target="_blank" rel="noreferrer">Ver ubicacion</a> (${fichaje.precision_m} m)`;

            return `
                <article class="item">
                    <strong>${fichaje.tipo}</strong>
                    <span>${fecha}</span><br>
                    <span class="muted">${ubicacion}</span>
                </article>
            `;
        })
        .join("");
}

async function refrescarDatos() {
    await cargarEstado();
    await cargarFichajes();
}

async function comprobarSesion() {
    const respuesta = await fetch("/auth/me");
    if (!respuesta.ok) {
        ocultarPanel();
        return;
    }

    const usuario = await respuesta.json();
    if (usuario.rol !== "TRABAJADOR") {
        mostrarMensaje(mensajeLogin, "Esta pantalla esta reservada a trabajadores", "error");
        ocultarPanel();
        return;
    }

    mostrarPanel(usuario);
    await refrescarDatos();
}

async function fichar(tipo) {
    try {
        if (estadoActual === null) {
            await cargarEstado();
        }

        if (tipo === "ENTRADA" && estadoActual.entrada_abierta) {
            mostrarMensaje(
                mensajeFichaje,
                "Ya has registrado una entrada. Debes registrar la salida antes de volver a entrar.",
                "error",
            );
            return;
        }

        if (tipo === "SALIDA" && !estadoActual.entrada_abierta) {
            mostrarMensaje(
                mensajeFichaje,
                "No puedes registrar una salida porque no hay una entrada pendiente.",
                "error",
            );
            return;
        }

        mostrarMensaje(mensajeFichaje, "Solicitando ubicacion...");
        const ubicacion = await pedirUbicacion();
        const respuesta = await fetch(`/fichajes/${tipo.toLowerCase()}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(ubicacion),
        });
        await leerRespuesta(respuesta);
        mostrarMensaje(mensajeFichaje, `${tipo} registrada`);
        await refrescarDatos();
    } catch (error) {
        mostrarMensaje(mensajeFichaje, error.message, "error");
    }
}

formLogin.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    mostrarMensaje(mensajeLogin, "");

    const datos = {
        usuario: document.querySelector("#login-usuario").value,
        password: document.querySelector("#login-password").value,
    };

    try {
        const respuesta = await fetch("/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datos),
        });
        const usuario = await leerRespuesta(respuesta);

        if (usuario.rol !== "TRABAJADOR") {
            await fetch("/auth/logout", { method: "POST" });
            throw new Error("Esta pantalla esta reservada a trabajadores");
        }

        mostrarPanel(usuario);
        await refrescarDatos();
    } catch (error) {
        mostrarMensaje(mensajeLogin, error.message, "error");
    }
});

botonEntrada.addEventListener("click", () => fichar("ENTRADA"));
botonSalida.addEventListener("click", () => fichar("SALIDA"));

botonSalir.addEventListener("click", async () => {
    await fetch("/auth/logout", { method: "POST" });
    ocultarPanel();
});

comprobarSesion();

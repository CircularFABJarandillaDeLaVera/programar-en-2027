import os
from datetime import datetime, timedelta, timezone

import psycopg
from dotenv import load_dotenv
from psycopg.rows import dict_row

from modelos import (
    Fichaje,
    TipoFichaje,
    Trabajador,
    TrabajadorConUsuarioEntrada,
    UsuarioSesion,
)
from seguridad import crear_password_hash


load_dotenv()


def obtener_conexion():
    return psycopg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "control_horario"),
        user=os.getenv("DB_USER", "python"),
        password=os.getenv("DB_PASSWORD", ""),
        row_factory=dict_row,
    )


def inicializar_base_de_datos() -> None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS trabajadores (
                    id SERIAL PRIMARY KEY,
                    nombre VARCHAR(80) NOT NULL
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS fichajes (
                    id SERIAL PRIMARY KEY,
                    trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
                    tipo VARCHAR(10) NOT NULL CHECK (tipo IN ('ENTRADA', 'SALIDA')),
                    fecha_hora TIMESTAMPTZ NOT NULL,
                    latitud DOUBLE PRECISION,
                    longitud DOUBLE PRECISION,
                    precision_m DOUBLE PRECISION
                )
                """
            )
            cursor.execute("ALTER TABLE fichajes ADD COLUMN IF NOT EXISTS latitud DOUBLE PRECISION")
            cursor.execute("ALTER TABLE fichajes ADD COLUMN IF NOT EXISTS longitud DOUBLE PRECISION")
            cursor.execute("ALTER TABLE fichajes ADD COLUMN IF NOT EXISTS precision_m DOUBLE PRECISION")
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS usuarios (
                    id SERIAL PRIMARY KEY,
                    usuario VARCHAR(80) NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,
                    rol VARCHAR(20) NOT NULL CHECK (rol IN ('EMPRESA', 'TRABAJADOR')),
                    trabajador_id INTEGER REFERENCES trabajadores(id)
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS sesiones (
                    token_hash TEXT PRIMARY KEY,
                    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
                    creada_en TIMESTAMPTZ NOT NULL,
                    expira_en TIMESTAMPTZ NOT NULL
                )
                """
            )

    crear_empresa_inicial_desde_entorno()


def crear_empresa_inicial_desde_entorno() -> None:
    usuario = os.getenv("EMPRESA_USUARIO", "").strip()
    password = os.getenv("EMPRESA_PASSWORD", "")

    if not usuario or not password:
        return

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("SELECT id FROM usuarios WHERE usuario = %s", (usuario,))
            if cursor.fetchone() is not None:
                return

            cursor.execute(
                """
                INSERT INTO usuarios (usuario, password_hash, rol, trabajador_id)
                VALUES (%s, %s, 'EMPRESA', NULL)
                """,
                (usuario, crear_password_hash(password)),
            )


def obtener_usuario_por_nombre_db(usuario: str) -> UsuarioSesion | None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    u.id,
                    u.usuario,
                    u.password_hash,
                    u.rol,
                    u.trabajador_id,
                    t.nombre AS trabajador_nombre
                FROM usuarios u
                LEFT JOIN trabajadores t ON t.id = u.trabajador_id
                WHERE u.usuario = %s
                """,
                (usuario,),
            )
            fila = cursor.fetchone()

    return fila


def crear_sesion_db(usuario_id: int, token_hash: str, minutos: int = 480) -> None:
    ahora = datetime.now(timezone.utc)
    expira_en = ahora + timedelta(minutes=minutos)

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO sesiones (token_hash, usuario_id, creada_en, expira_en)
                VALUES (%s, %s, %s, %s)
                """,
                (token_hash, usuario_id, ahora, expira_en),
            )


def obtener_usuario_por_token_hash_db(token_hash: str) -> UsuarioSesion | None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("DELETE FROM sesiones WHERE expira_en <= NOW()")
            cursor.execute(
                """
                SELECT
                    u.id,
                    u.usuario,
                    u.rol,
                    u.trabajador_id,
                    t.nombre AS trabajador_nombre
                FROM sesiones s
                JOIN usuarios u ON u.id = s.usuario_id
                LEFT JOIN trabajadores t ON t.id = u.trabajador_id
                WHERE s.token_hash = %s
                  AND s.expira_en > NOW()
                """,
                (token_hash,),
            )
            fila = cursor.fetchone()

    if fila is None:
        return None

    return UsuarioSesion(**fila)


def eliminar_sesion_db(token_hash: str) -> None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("DELETE FROM sesiones WHERE token_hash = %s", (token_hash,))


def crear_trabajador_db(datos: TrabajadorConUsuarioEntrada) -> Trabajador:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO trabajadores (nombre)
                VALUES (%s)
                RETURNING id, nombre
                """,
                (datos.nombre,),
            )
            trabajador = cursor.fetchone()
            cursor.execute(
                """
                INSERT INTO usuarios (usuario, password_hash, rol, trabajador_id)
                VALUES (%s, %s, 'TRABAJADOR', %s)
                """,
                (datos.usuario, crear_password_hash(datos.password), trabajador["id"]),
            )

    return Trabajador(**trabajador)


def listar_trabajadores_db() -> list[Trabajador]:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("SELECT id, nombre FROM trabajadores ORDER BY id")
            filas = cursor.fetchall()

    return [Trabajador(**fila) for fila in filas]


def obtener_trabajador_db(trabajador_id: int) -> Trabajador | None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                "SELECT id, nombre FROM trabajadores WHERE id = %s",
                (trabajador_id,),
            )
            fila = cursor.fetchone()

    if fila is None:
        return None

    return Trabajador(**fila)


def obtener_ultimo_fichaje_db(trabajador_id: int) -> Fichaje | None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    f.id,
                    f.trabajador_id,
                    t.nombre AS trabajador_nombre,
                    f.tipo,
                    f.fecha_hora,
                    f.latitud,
                    f.longitud,
                    f.precision_m
                FROM fichajes f
                JOIN trabajadores t ON t.id = f.trabajador_id
                WHERE f.trabajador_id = %s
                ORDER BY f.fecha_hora DESC, f.id DESC
                LIMIT 1
                """,
                (trabajador_id,),
            )
            fila = cursor.fetchone()

    if fila is None:
        return None

    return Fichaje(**fila)


def crear_fichaje_db(
    trabajador_id: int,
    tipo: TipoFichaje,
    latitud: float | None = None,
    longitud: float | None = None,
    precision_m: float | None = None,
) -> Fichaje:
    fecha_hora = datetime.now(timezone.utc)

    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO fichajes (
                    trabajador_id,
                    tipo,
                    fecha_hora,
                    latitud,
                    longitud,
                    precision_m
                )
                VALUES (%s, %s, %s, %s, %s, %s)
                RETURNING id, trabajador_id, tipo, fecha_hora, latitud, longitud, precision_m
                """,
                (trabajador_id, tipo, fecha_hora, latitud, longitud, precision_m),
            )
            fichaje = cursor.fetchone()
            cursor.execute(
                "SELECT nombre FROM trabajadores WHERE id = %s",
                (trabajador_id,),
            )
            trabajador = cursor.fetchone()

    return Fichaje(
        id=fichaje["id"],
        trabajador_id=fichaje["trabajador_id"],
        trabajador_nombre=trabajador["nombre"],
        tipo=fichaje["tipo"],
        fecha_hora=fichaje["fecha_hora"],
        latitud=fichaje["latitud"],
        longitud=fichaje["longitud"],
        precision_m=fichaje["precision_m"],
    )


def listar_fichajes_db() -> list[Fichaje]:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    f.id,
                    f.trabajador_id,
                    t.nombre AS trabajador_nombre,
                    f.tipo,
                    f.fecha_hora,
                    f.latitud,
                    f.longitud,
                    f.precision_m
                FROM fichajes f
                JOIN trabajadores t ON t.id = f.trabajador_id
                ORDER BY f.fecha_hora, f.id
                """
            )
            filas = cursor.fetchall()

    return [Fichaje(**fila) for fila in filas]


def listar_fichajes_de_trabajador_db(trabajador_id: int) -> list[Fichaje]:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    f.id,
                    f.trabajador_id,
                    t.nombre AS trabajador_nombre,
                    f.tipo,
                    f.fecha_hora,
                    f.latitud,
                    f.longitud,
                    f.precision_m
                FROM fichajes f
                JOIN trabajadores t ON t.id = f.trabajador_id
                WHERE f.trabajador_id = %s
                ORDER BY f.fecha_hora, f.id
                """,
                (trabajador_id,),
            )
            filas = cursor.fetchall()

    return [Fichaje(**fila) for fila in filas]

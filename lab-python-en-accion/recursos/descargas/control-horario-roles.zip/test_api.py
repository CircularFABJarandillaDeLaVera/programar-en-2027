import unittest
from datetime import datetime, timezone
from unittest.mock import patch

from fastapi.testclient import TestClient

import main
from modelos import Fichaje, Trabajador, UsuarioSesion
from seguridad import crear_password_hash, crear_token_hash


class TestApiControlHorarioRoles(unittest.TestCase):
    def setUp(self):
        self.parche_inicio = patch("main.inicializar_base_de_datos")
        self.parche_inicio.start()
        self.cliente = TestClient(main.app)

    def tearDown(self):
        self.parche_inicio.stop()

    def poner_cookie_sesion(self):
        self.cliente.cookies.set(main.COOKIE_SESION, "token-de-prueba")

    def usuario_empresa(self):
        return UsuarioSesion(id=1, usuario="empresa", rol="EMPRESA")

    def usuario_trabajador(self):
        return UsuarioSesion(
            id=2,
            usuario="ana",
            rol="TRABAJADOR",
            trabajador_id=7,
            trabajador_nombre="Ana",
        )

    def fichaje(self, fichaje_id, trabajador_id, nombre, tipo, latitud=None, longitud=None, precision_m=None):
        return Fichaje(
            id=fichaje_id,
            trabajador_id=trabajador_id,
            trabajador_nombre=nombre,
            tipo=tipo,
            fecha_hora=datetime(2026, 8, 30, 8, 2, tzinfo=timezone.utc),
            latitud=latitud,
            longitud=longitud,
            precision_m=precision_m,
        )

    @patch("main.crear_sesion_db")
    @patch("main.obtener_usuario_por_nombre_db")
    def test_login_empresa_correcto_crea_cookie_de_sesion(self, obtener_usuario_por_nombre_db, crear_sesion_db):
        obtener_usuario_por_nombre_db.return_value = {
            "id": 1,
            "usuario": "empresa",
            "password_hash": crear_password_hash("password123"),
            "rol": "EMPRESA",
            "trabajador_id": None,
            "trabajador_nombre": None,
        }

        respuesta = self.cliente.post(
            "/auth/login",
            json={"usuario": "empresa", "password": "password123"},
        )

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.json()["rol"], "EMPRESA")
        self.assertIn(main.COOKIE_SESION, respuesta.headers["set-cookie"])
        crear_sesion_db.assert_called_once()

    @patch("main.obtener_usuario_por_nombre_db")
    def test_login_con_password_incorrecto_devuelve_401(self, obtener_usuario_por_nombre_db):
        obtener_usuario_por_nombre_db.return_value = {
            "id": 1,
            "usuario": "empresa",
            "password_hash": crear_password_hash("password123"),
            "rol": "EMPRESA",
            "trabajador_id": None,
            "trabajador_nombre": None,
        }

        respuesta = self.cliente.post(
            "/auth/login",
            json={"usuario": "empresa", "password": "mal"},
        )

        self.assertEqual(respuesta.status_code, 401)
        self.assertEqual(respuesta.json()["detail"], "Usuario o contrasena incorrectos")

    def test_endpoint_protegido_sin_sesion_devuelve_401(self):
        respuesta = self.cliente.get("/trabajadores")

        self.assertEqual(respuesta.status_code, 401)
        self.assertEqual(respuesta.json()["detail"], "Debes iniciar sesion")

    @patch("main.crear_trabajador_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_empresa_puede_crear_trabajador(self, obtener_usuario_por_token_hash_db, crear_trabajador_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_empresa()
        crear_trabajador_db.return_value = Trabajador(id=7, nombre="Ana")

        respuesta = self.cliente.post(
            "/trabajadores",
            json={"nombre": "Ana", "usuario": "ana", "password": "password123"},
        )

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json(), {"id": 7, "nombre": "Ana"})

    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_no_puede_crear_trabajador(self, obtener_usuario_por_token_hash_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()

        respuesta = self.cliente.post(
            "/trabajadores",
            json={"nombre": "Luis", "usuario": "luis", "password": "password123"},
        )

        self.assertEqual(respuesta.status_code, 403)
        self.assertEqual(respuesta.json()["detail"], "Esta operacion esta reservada a la empresa")

    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_no_puede_listar_trabajadores(self, obtener_usuario_por_token_hash_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()

        respuesta = self.cliente.get("/trabajadores")

        self.assertEqual(respuesta.status_code, 403)

    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_registra_entrada_con_su_identidad(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None
        crear_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")

        respuesta = self.cliente.post("/fichajes/entrada", json={"trabajador_id": 999})

        self.assertEqual(respuesta.status_code, 201)
        crear_fichaje_db.assert_called_once_with(7, "ENTRADA", None, None, None)

    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_registra_salida_con_su_identidad(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")
        crear_fichaje_db.return_value = self.fichaje(2, 7, "Ana", "SALIDA")

        respuesta = self.cliente.post("/fichajes/salida", json={"trabajador_id": 999})

        self.assertEqual(respuesta.status_code, 201)
        crear_fichaje_db.assert_called_once_with(7, "SALIDA", None, None, None)

    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_doble_entrada_sigue_rechazada(self, obtener_usuario_por_token_hash_db, obtener_ultimo_fichaje_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")

        respuesta = self.cliente.post("/fichajes/entrada", json={})

        self.assertEqual(respuesta.status_code, 400)
        self.assertIn("SALIDA previa", respuesta.json()["detail"])

    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_salida_sin_entrada_sigue_rechazada(self, obtener_usuario_por_token_hash_db, obtener_ultimo_fichaje_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None

        respuesta = self.cliente.post("/fichajes/salida", json={})

        self.assertEqual(respuesta.status_code, 400)
        self.assertIn("ENTRADA abierta", respuesta.json()["detail"])

    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_entrada_con_ubicacion_sigue_guardando_geolocalizacion(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None
        crear_fichaje_db.return_value = self.fichaje(
            1,
            7,
            "Ana",
            "ENTRADA",
            latitud=40.4168,
            longitud=-3.7038,
            precision_m=12.0,
        )

        respuesta = self.cliente.post(
            "/fichajes/entrada",
            json={"latitud": 40.4168, "longitud": -3.7038, "precision_m": 12.0},
        )

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json()["latitud"], 40.4168)
        crear_fichaje_db.assert_called_once_with(7, "ENTRADA", 40.4168, -3.7038, 12.0)

    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_entrada_sin_ubicacion_sigue_permitida(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None
        crear_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")

        respuesta = self.cliente.post("/fichajes/entrada", json={})

        self.assertEqual(respuesta.status_code, 201)
        self.assertIsNone(respuesta.json()["latitud"])
        crear_fichaje_db.assert_called_once_with(7, "ENTRADA", None, None, None)

    @patch("main.listar_fichajes_de_trabajador_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_solo_consulta_sus_fichajes(self, obtener_usuario_por_token_hash_db, listar_fichajes):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        listar_fichajes.return_value = [self.fichaje(1, 7, "Ana", "ENTRADA")]

        respuesta = self.cliente.get("/yo/fichajes")

        self.assertEqual(respuesta.status_code, 200)
        listar_fichajes.assert_called_once_with(7)

    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_no_puede_consultar_fichajes_de_otro_trabajador(self, obtener_usuario_por_token_hash_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()

        respuesta = self.cliente.get("/trabajadores/8/fichajes")

        self.assertEqual(respuesta.status_code, 403)

    @patch("main.listar_fichajes_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_empresa_puede_consultar_todos_los_fichajes(self, obtener_usuario_por_token_hash_db, listar_fichajes):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_empresa()
        listar_fichajes.return_value = [self.fichaje(1, 7, "Ana", "ENTRADA")]

        respuesta = self.cliente.get("/fichajes")

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.json()[0]["trabajador_id"], 7)

    @patch("main.eliminar_sesion_db")
    def test_logout_elimina_la_sesion_por_hash(self, eliminar_sesion_db):
        self.poner_cookie_sesion()

        respuesta = self.cliente.post("/auth/logout")

        self.assertEqual(respuesta.status_code, 200)
        eliminar_sesion_db.assert_called_once_with(crear_token_hash("token-de-prueba"))

    def test_interfaz_empresa_se_puede_servir(self):
        respuesta = self.cliente.get("/app/empresa/")

        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("text/html", respuesta.headers["content-type"])
        self.assertIn("Empresa", respuesta.text)

    def test_interfaz_fichar_se_puede_servir(self):
        respuesta = self.cliente.get("/app/fichar/")

        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("text/html", respuesta.headers["content-type"])
        self.assertIn("Fichar", respuesta.text)


if __name__ == "__main__":
    unittest.main()

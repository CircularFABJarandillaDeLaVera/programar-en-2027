import argparse
import json
import os
import re
from pathlib import Path
from typing import TypedDict

import requests
from langgraph.graph import END, START, StateGraph

ORION_URL = os.getenv("ORION_URL", "http://localhost:1026").rstrip("/")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:1b")
DEMO_PATH = Path(__file__).with_name("datos_contexto_demo.json")

ACCIONES_BASE = {
    "DATOS_INCOMPLETOS": "Una persona debe comprobar los datos disponibles del dispositivo.",
    "REVISAR_TEMPERATURA": "Una persona debe revisar la temperatura del dispositivo.",
    "REVISAR_HUMEDAD": "Una persona debe revisar la humedad del dispositivo.",
    "SIN_REVISION_PRIORITARIA": "El sistema no requiere una revisión prioritaria según las reglas didácticas actuales.",
}

FORBIDDEN_TERMS = (
    "gases tóxicos",
    "contaminación",
    "toxicidad",
)


class EstadoDecision(TypedDict):
    dispositivo_id: str
    temperatura_c: float | None
    humedad_pct: int | None
    datos_validos: bool
    decision: str
    accion: str
    fuente: str
    usa_demo: bool
    ruta: str
    mensaje: str


def cargar_contexto_demo() -> dict:
    with DEMO_PATH.open("r", encoding="utf-8") as archivo:
        return json.load(archivo)


def consultar_fiware_real(dispositivo_id: str = "compostera-cf-01") -> dict:
    url = f"{ORION_URL}/ngsi-ld/v1/entities/urn:ngsi-ld:Device:{dispositivo_id}"
    try:
        respuesta = requests.get(url, timeout=3)
        if respuesta.status_code == 200:
            datos = respuesta.json()
            return {
                "dispositivo_id": dispositivo_id,
                "temperatura_c": datos.get("temperature", {}).get("value"),
                "humedad_pct": datos.get("humidity", {}).get("value"),
            }
        raise RuntimeError(
            f"FIWARE no disponible: HTTP {respuesta.status_code}. Ejecuta --demo para explorar el flujo con datos de demostración."
        )
    except requests.RequestException as exc:
        raise RuntimeError(
            f"FIWARE no disponible: {exc}. Ejecuta --demo para explorar el flujo con datos de demostración."
        ) from exc


def obtener_contexto(estado: EstadoDecision) -> EstadoDecision:
    usa_demo = bool(estado.get("usa_demo", False))
    if usa_demo:
        contexto = cargar_contexto_demo()
        fuente = "DATOS DE DEMOSTRACIÓN"
    else:
        try:
            contexto = consultar_fiware_real(estado.get("dispositivo_id", "compostera-cf-01"))
            fuente = "FIWARE REAL"
        except RuntimeError as exc:
            raise RuntimeError(
                "FIWARE no disponible. Ejecuta --demo para explorar el flujo con datos de demostración."
            ) from exc

    estado["dispositivo_id"] = contexto.get("dispositivo_id", estado.get("dispositivo_id", "compostera-cf-01"))
    estado["temperatura_c"] = contexto.get("temperatura_c")
    estado["humedad_pct"] = contexto.get("humedad_pct")
    estado["fuente"] = fuente
    estado["mensaje"] = f"FUENTE DE DATOS: {fuente}"
    return estado


def validar_datos(estado: EstadoDecision) -> EstadoDecision:
    temperatura = estado.get("temperatura_c")
    humedad = estado.get("humedad_pct")
    if temperatura is None or humedad is None:
        estado["datos_validos"] = False
        estado["decision"] = "DATOS_INCOMPLETOS"
        estado["accion"] = ACCIONES_BASE["DATOS_INCOMPLETOS"]
        estado["mensaje"] = f"{estado.get('mensaje', '')} | Datos incompletos."
        return estado

    estado["datos_validos"] = True
    estado["decision"] = ""
    estado["accion"] = ""
    estado["mensaje"] = f"{estado.get('mensaje', '')} | Datos válidos."
    return estado


def decidir_que_hacer(estado: dict) -> str:
    temperatura = estado.get("temperatura_c")
    humedad = estado.get("humedad_pct")
    if temperatura is None or humedad is None:
        return "DATOS_INCOMPLETOS"
    if temperatura >= 45:
        return "REVISAR_TEMPERATURA"
    if humedad < 50:
        return "REVISAR_HUMEDAD"
    return "SIN_REVISION_PRIORITARIA"


def evaluar_estado(estado: EstadoDecision) -> EstadoDecision:
    if not estado.get("datos_validos", False):
        estado["decision"] = "DATOS_INCOMPLETOS"
        estado["accion"] = ACCIONES_BASE["DATOS_INCOMPLETOS"]
        estado["ruta"] = "datos_incompletos"
        return estado

    decision = decidir_que_hacer(estado)
    estado["decision"] = decision
    estado["accion"] = ACCIONES_BASE[decision]
    estado["ruta"] = {
        "DATOS_INCOMPLETOS": "datos_incompletos",
        "REVISAR_TEMPERATURA": "revisar_temperatura",
        "REVISAR_HUMEDAD": "revisar_humedad",
        "SIN_REVISION_PRIORITARIA": "sin_revision",
    }[decision]
    return estado


def seleccionar_ruta(estado: EstadoDecision) -> str:
    decision = estado.get("decision", "SIN_REVISION_PRIORITARIA")
    return {
        "DATOS_INCOMPLETOS": "datos_incompletos",
        "REVISAR_TEMPERATURA": "revisar_temperatura",
        "REVISAR_HUMEDAD": "revisar_humedad",
        "SIN_REVISION_PRIORITARIA": "sin_revision",
    }.get(decision, "sin_revision")


def nodo_datos_incompletos(estado: EstadoDecision) -> EstadoDecision:
    estado["ruta"] = "datos_incompletos"
    return estado


def nodo_revisar_temperatura(estado: EstadoDecision) -> EstadoDecision:
    estado["ruta"] = "revisar_temperatura"
    return estado


def nodo_revisar_humedad(estado: EstadoDecision) -> EstadoDecision:
    estado["ruta"] = "revisar_humedad"
    return estado


def nodo_sin_revision(estado: EstadoDecision) -> EstadoDecision:
    estado["ruta"] = "sin_revision"
    return estado


def construir_grafo():
    grafo = StateGraph(EstadoDecision)
    grafo.add_node("obtener_contexto", obtener_contexto)
    grafo.add_node("validar_datos", validar_datos)
    grafo.add_node("evaluar_estado", evaluar_estado)
    grafo.add_node("datos_incompletos", nodo_datos_incompletos)
    grafo.add_node("revisar_temperatura", nodo_revisar_temperatura)
    grafo.add_node("revisar_humedad", nodo_revisar_humedad)
    grafo.add_node("sin_revision", nodo_sin_revision)

    grafo.add_edge(START, "obtener_contexto")
    grafo.add_edge("obtener_contexto", "validar_datos")
    grafo.add_edge("validar_datos", "evaluar_estado")
    grafo.add_conditional_edges(
        "evaluar_estado",
        seleccionar_ruta,
        {
            "datos_incompletos": "datos_incompletos",
            "revisar_temperatura": "revisar_temperatura",
            "revisar_humedad": "revisar_humedad",
            "sin_revision": "sin_revision",
        },
    )
    grafo.add_edge("datos_incompletos", END)
    grafo.add_edge("revisar_temperatura", END)
    grafo.add_edge("revisar_humedad", END)
    grafo.add_edge("sin_revision", END)
    return grafo.compile()


def ejecutar_decision(dispositivo_id: str = "compostera-cf-01", usa_demo: bool = False) -> dict:
    estado_inicial: EstadoDecision = {
        "dispositivo_id": dispositivo_id,
        "temperatura_c": None,
        "humedad_pct": None,
        "datos_validos": False,
        "decision": "",
        "accion": "",
        "fuente": "",
        "usa_demo": usa_demo,
        "ruta": "",
        "mensaje": "",
    }
    app = construir_grafo()
    resultado = app.invoke(estado_inicial)
    return resultado


def construir_prompt(contexto: dict, decision: str, accion: str) -> str:
    dispositivo = contexto.get("dispositivo_id", "compostera-cf-01")
    temperatura = contexto.get("temperatura_c")
    humedad = contexto.get("humedad_pct")
    return (
        "Eres un generador de explicaciones controladas para un sistema industrial.\n"
        "Debes responder con un JSON válido con dos claves: explicacion y accion.\n"
        f"Dispositivo: {dispositivo}\n"
        f"Temperatura: {temperatura} °C\n"
        f"Humedad: {humedad} %\n"
        f"Decisión determinista: {decision}\n"
        f"Acción determinista permitida: {accion}\n"
        "Reglas absolutas:\n"
        "- no inventar causas;\n"
        "- no predecir consecuencias;\n"
        "- no añadir conocimiento externo;\n"
        "- no modificar cifras;\n"
        "- no cambiar la decisión;\n"
        "- no usar afirmaciones como 'ha superado 48' si el valor es 48;\n"
        "- produce una explicación breve;\n"
        "- responde solo con JSON válido.\n"
        "- usa exactamente la acción permitida en la clave accion."
    )


def _extraer_json(raw: str):
    if raw is None:
        raise ValueError("JSON no válido: respuesta vacía")
    text = raw.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text, flags=re.IGNORECASE)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        if "{" in text and "}" in text:
            start = text.index("{")
            end = text.rindex("}") + 1
            candidate = text[start:end]
            try:
                return json.loads(candidate)
            except json.JSONDecodeError as exc:
                raise ValueError(f"JSON no válido: {exc}") from exc
        raise ValueError("JSON no válido: la respuesta no estaba en JSON")


def validar_respuesta_llm(respuesta: object, decision: str, temperatura: float | int | None, humedad: float | int | None) -> tuple[bool, str]:
    if not isinstance(respuesta, dict):
        return False, "Respuesta no válida: no se recibió JSON válido."

    if "explicacion" not in respuesta or "accion" not in respuesta:
        return False, "Respuesta no válida: faltan campos explicacion o accion."

    explicacion = str(respuesta["explicacion"]).strip()
    accion = str(respuesta["accion"]).strip()

    if not explicacion or not accion:
        return False, "Respuesta no válida: explicacion o accion vacíos."

    if accion != ACCIONES_BASE.get(decision):
        return False, f"Respuesta no válida: la acción no corresponde a la decisión {decision}."

    text_upper = (explicacion + " " + accion).upper()
    decisiones_validas = [
        "DATOS_INCOMPLETOS",
        "REVISAR_TEMPERATURA",
        "REVISAR_HUMEDAD",
        "SIN_REVISION_PRIORITARIA",
    ]
    decisiones_presentes = [d for d in decisiones_validas if d in text_upper]

    if decision not in text_upper:
        return False, f"Respuesta no válida: la explicación no mantiene la decisión {decision}."

    if any(d != decision for d in decisiones_presentes):
        return False, f"Respuesta no válida: la explicación sustituye la decisión {decision} por otra ruta."

    text_lower = text_upper.lower()
    for termino in FORBIDDEN_TERMS:
        if termino in text_lower:
            return False, f"Respuesta no válida: contiene término prohibido: {termino}."

    allowed_numbers = set()
    for value in [temperatura, humedad]:
        if value is None:
            continue
        allowed_numbers.add(str(int(value)) if float(value).is_integer() else str(value))

    found_numbers = re.findall(r"(?<![A-Za-z0-9-])\d+(?:[.,]\d+)?(?![A-Za-z0-9-])", explicacion + " " + accion)
    for numero in found_numbers:
        normalized = numero.replace(",", ".")
        if normalized not in {n.replace(",", ".") for n in allowed_numbers}:
            return False, f"Respuesta no válida: contiene número no permitido: {numero}."

    return True, "RESPUESTA ACEPTADA"


def generar_explicacion_determinista(contexto: dict, decision: str) -> str:
    dispositivo = contexto.get("dispositivo_id", "compostera-cf-01")
    temperatura = contexto.get("temperatura_c")
    humedad = contexto.get("humedad_pct")
    if temperatura is None or humedad is None:
        return (
            f"El dispositivo {dispositivo} no aporta todos los datos necesarios. "
            f"La decisión del sistema es DATOS_INCOMPLETOS."
        )
    return (
        f"El dispositivo {dispositivo} registra {temperatura} °C y {humedad} % de humedad. "
        f"La decisión del sistema es {decision}."
    )


def explicar_con_llm(contexto: dict, decision: str, fuente: str = "DATOS DE DEMOSTRACIÓN", sin_ia: bool = False) -> dict:
    accion = ACCIONES_BASE.get(decision, ACCIONES_BASE["SIN_REVISION_PRIORITARIA"])
    fallback = {
        "explicacion": generar_explicacion_determinista(contexto, decision),
        "accion": accion,
        "fallback": True,
        "motivo": "USANDO FALLBACK DETERMINISTA",
        "decision": decision,
        "sin_ia": sin_ia,
        "fuente": fuente,
    }

    if sin_ia:
        return {
            "explicacion": generar_explicacion_determinista(contexto, decision),
            "accion": accion,
            "fallback": False,
            "motivo": "IA DESACTIVADA (--sin-ia)",
            "decision": decision,
            "sin_ia": True,
            "fuente": fuente,
        }

    prompt = construir_prompt(contexto, decision, accion)
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
    }

    try:
        respuesta = requests.post(f"{OLLAMA_URL}/api/generate", json=payload, timeout=15)
        respuesta.raise_for_status()
        raw = respuesta.json().get("response", "")
        parsed = _extraer_json(raw)
        ok, motivo = validar_respuesta_llm(parsed, decision, contexto.get("temperatura_c"), contexto.get("humedad_pct"))
        if ok:
            return {
                "explicacion": str(parsed["explicacion"]).strip(),
                "accion": str(parsed["accion"]).strip(),
                "fallback": False,
                "motivo": motivo,
                "decision": decision,
                "fuente": fuente,
            }
        fallback["motivo"] = f"RESPUESTA DESCARTADA: {motivo}"
        return fallback
    except Exception as exc:  # pragma: no cover - real call path
        fallback["motivo"] = f"RESPUESTA DESCARTADA: {exc}"
        return fallback


def imprimir_resultado(contexto: dict, decision: str, resultado_ia: dict, usa_demo: bool) -> None:
    print(f"FUENTE DE DATOS: {'DATOS DE DEMOSTRACIÓN' if usa_demo else 'FIWARE REAL'}")
    print("")
    print("CONTEXTO")
    print(f"Dispositivo: {contexto.get('dispositivo_id', 'compostera-cf-01')}")
    print(f"Temperatura: {contexto.get('temperatura_c')} °C")
    print(f"Humedad: {contexto.get('humedad_pct')} %")
    print("")
    print("DECISIÓN LANGGRAPH")
    print(decision)
    print("")

    if resultado_ia.get("sin_ia"):
        print("MODELO LOCAL")
        print("IA DESACTIVADA (--sin-ia)")
        print("")
        print("EXPLICACIÓN DETERMINISTA")
        print(resultado_ia["explicacion"])
        print("")
        print("ACCIÓN")
        print(resultado_ia["accion"])
        return

    print("MODELO LOCAL")
    print(OLLAMA_MODEL)
    print("")
    print("VALIDACIÓN IA")
    if resultado_ia.get("fallback"):
        print("RESPUESTA DESCARTADA")
        print(f"Motivo: {resultado_ia.get('motivo', 'USANDO FALLBACK DETERMINISTA')}")
        print("")
        print("USANDO FALLBACK DETERMINISTA")
    else:
        print("RESPUESTA ACEPTADA")
    print("")
    print("EXPLICACIÓN")
    print(resultado_ia["explicacion"])
    print("")
    print("ACCIÓN")
    print(resultado_ia["accion"])


def main() -> None:
    parser = argparse.ArgumentParser(description="Explica una decisión determinista con LLM local controlado.")
    parser.add_argument("--demo", action="store_true", help="Usa datos de demostración en lugar de FIWARE real.")
    parser.add_argument("--sin-ia", action="store_true", help="Desactiva el modelo local y usa solo la explicación determinista.")
    parser.add_argument("--dispositivo", default="compostera-cf-01", help="ID del dispositivo a consultar.")
    args = parser.parse_args()

    if args.demo:
        contexto = cargar_contexto_demo()
        contexto["dispositivo_id"] = args.dispositivo
        fuente = "DATOS DE DEMOSTRACIÓN"
    else:
        try:
            contexto = consultar_fiware_real(args.dispositivo)
            fuente = "FIWARE REAL"
        except RuntimeError as exc:
            print(f"ERROR: {exc}")
            print("Recomendación: ejecuta --demo para seguir con la práctica sin FIWARE disponible.")
            raise SystemExit(1) from exc

    decision = decidir_que_hacer(contexto)
    resultado_ia = explicar_con_llm(contexto, decision, fuente=fuente, sin_ia=args.sin_ia)
    imprimir_resultado(contexto, decision, resultado_ia, usa_demo=args.demo)


if __name__ == "__main__":
    main()

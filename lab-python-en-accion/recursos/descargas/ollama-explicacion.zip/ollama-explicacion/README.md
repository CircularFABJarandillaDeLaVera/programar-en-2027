# Experiencia 23 · Una IA que explica, pero no decide

## Objetivo

Esta práctica muestra la diferencia entre:

- `LangGraph` y reglas deterministas -> deciden
- `Ollama` y un modelo local -> explican
- `Python` -> valida la respuesta y decides si la aceptas

La idea no es que el LLM sustituya la lógica del sistema. La idea es que genere una explicación legible, pero controlada.

## Requisitos

```bash
pip install -r requirements.txt
```

## Ejecutar en modo demo

```bash
python explicar_decision.py --demo
```

## Ejecutar sin IA

```bash
python explicar_decision.py --demo --sin-ia
```

En este modo no se llama a Ollama. Se usa directamente la explicación determinista del sistema.

## Modo real con FIWARE

```bash
python explicar_decision.py
```

## Modelo por defecto

- Modelo: `llama3.2:1b`
- URL: `http://localhost:11434`

Se pueden sobrescribir con:

```bash
OLLAMA_MODEL=llama3.2:1b OLLAMA_URL=http://localhost:11434 python explicar_decision.py --demo
```

## Regla central

La decisión la toma el sistema de reglas. El LLM solo genera una explicación segura y breve.

## Diferencias clave

```text
SIN LLM
El sistema ya funciona.

CON LLM
El mismo resultado puede explicarse con lenguaje natural.
```

## Importante

Si Ollama falla o la respuesta no cumple la validación, se usa un fallback determinista.

El validador es didáctico: comprueba que la respuesta no cambia la decisión ni inventa hechos.

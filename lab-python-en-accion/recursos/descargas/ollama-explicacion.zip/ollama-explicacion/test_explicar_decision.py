import json
from pathlib import Path

import pytest

from explicar_decision import (
    ACCIONES_BASE,
    cargar_contexto_demo,
    consultar_fiware_real,
    construir_prompt,
    decidir_que_hacer,
    explicar_con_llm,
    generar_explicacion_determinista,
    validar_respuesta_llm,
)


@pytest.fixture
def estado_demo():
    return {
        "dispositivo_id": "compostera-cf-01",
        "temperatura_c": 48,
        "humedad_pct": 60,
        "fuente": "DATOS DE DEMOSTRACIÓN",
    }


def test_decision_normal():
    estado = {"dispositivo_id": "compostera-cf-01", "temperatura_c": 43.5, "humedad_pct": 60}
    resultado = decidir_que_hacer(estado)
    assert resultado == "SIN_REVISION_PRIORITARIA"


def test_temperatura_alta():
    estado = {"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}
    resultado = decidir_que_hacer(estado)
    assert resultado == "REVISAR_TEMPERATURA"


def test_humedad_baja():
    estado = {"dispositivo_id": "compostera-cf-01", "temperatura_c": 40, "humedad_pct": 45}
    resultado = decidir_que_hacer(estado)
    assert resultado == "REVISAR_HUMEDAD"


def test_datos_incompletos():
    estado = {"dispositivo_id": "compostera-cf-01", "temperatura_c": None, "humedad_pct": 60}
    resultado = decidir_que_hacer(estado)
    assert resultado == "DATOS_INCOMPLETOS"


def test_demo_recorrer_langgraph(monkeypatch):
    monkeypatch.setattr(
        "explicar_decision.cargar_contexto_demo",
        lambda: {"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60},
    )
    datos = cargar_contexto_demo()
    assert datos["temperatura_c"] == 48
    assert decidir_que_hacer(datos) == "REVISAR_TEMPERATURA"


def test_fiware_no_hace_fallback_silencioso(monkeypatch):
    def fallo():
        raise RuntimeError("FIWARE no disponible")

    monkeypatch.setattr("explicar_decision.consultar_fiware_real", fallo)
    with pytest.raises(RuntimeError, match="FIWARE no disponible"):
        consultar_fiware_real()


def test_explicacion_determinista_correcta(estado_demo):
    txt = generar_explicacion_determinista(estado_demo, "REVISAR_TEMPERATURA")
    assert "compostera-cf-01" in txt
    assert "48 °C" in txt
    assert "REVISAR_TEMPERATURA" in txt


def test_ollama_json_valido_aceptado():
    payload = {"explicacion": "El dispositivo compostera-cf-01 registra 48 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.", "accion": "Una persona debe revisar la temperatura del dispositivo."}
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is True
    assert motivo == "RESPUESTA ACEPTADA"


def test_json_invalido_caida_a_fallback():
    ok, motivo = validar_respuesta_llm("texto suelto", "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False
    assert "JSON" in motivo or "válido" in motivo.lower()


def test_numero_inventado_cambiado_caida_a_fallback():
    payload = {"explicacion": "El dispositivo compostera-cf-01 registra 49 °C y 60 % de humedad. La decisión del sistema es REVISAR_TEMPERATURA.", "accion": "Una persona debe revisar la temperatura del dispositivo."}
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_termino_prohibido_caida_a_fallback():
    payload = {"explicacion": "Se detectan gases tóxicos y contaminación del suelo.", "accion": "Una persona debe revisar la temperatura del dispositivo."}
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_ollama_no_disponible_fallback(monkeypatch):
    def falla(_url, **_kwargs):
        raise RuntimeError("Ollama no disponible")

    monkeypatch.setattr("requests.post", falla)
    resultado = explicar_con_llm({"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}, "REVISAR_TEMPERATURA", "--demo")
    assert "REVISAR_TEMPERATURA" in resultado["explicacion"]
    assert resultado["fallback"] is True


def test_sin_ia_no_intenta_llamar_a_ollama(monkeypatch):
    llamado = {"valor": False}

    def falla(*_args, **_kwargs):
        llamado["valor"] = True
        raise AssertionError("No debería llamarse a Ollama en modo --sin-ia")

    monkeypatch.setattr("requests.post", falla)
    resultado = explicar_con_llm({"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}, "REVISAR_TEMPERATURA", "DATOS DE DEMOSTRACIÓN", sin_ia=True)
    assert llamado["valor"] is False
    assert resultado["sin_ia"] is True
    assert "REVISAR_TEMPERATURA" in resultado["explicacion"]
    assert "RESPUESTA DESCARTADA" not in resultado["motivo"]


def test_sin_ia_devuelve_explicacion_determinista():
    resultado = explicar_con_llm({"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}, "REVISAR_TEMPERATURA", "DATOS DE DEMOSTRACIÓN", sin_ia=True)
    assert resultado["fallback"] is False
    assert resultado["sin_ia"] is True
    assert "El dispositivo compostera-cf-01 registra 48 °C y 60 % de humedad." in resultado["explicacion"]


def test_sin_ia_no_se_clasifica_como_respuesta_descartada():
    resultado = explicar_con_llm({"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}, "REVISAR_TEMPERATURA", "DATOS DE DEMOSTRACIÓN", sin_ia=True)
    assert resultado["motivo"] == "IA DESACTIVADA (--sin-ia)"
    assert "RESPUESTA DESCARTADA" not in resultado["motivo"]


def test_sin_ia_funciona_conceptualmente():
    estado = {"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}
    decision = decidir_que_hacer(estado)
    fallback = generar_explicacion_determinista(estado, decision)
    assert decision == "REVISAR_TEMPERATURA"
    assert "REVISAR_TEMPERATURA" in fallback


def test_decision_determinista_nunca_sustituida_por_llm():
    payload = {"explicacion": "La decisión es SIN_REVISION_PRIORITARIA aunque el sistema dijo REVISAR_TEMPERATURA.", "accion": "Una persona debe revisar la temperatura del dispositivo."}
    ok, motivo = validar_respuesta_llm(payload, "REVISAR_TEMPERATURA", 48, 60)
    assert ok is False


def test_prompt_controlado_usa_datos_estructurados():
    prompt = construir_prompt({"dispositivo_id": "compostera-cf-01", "temperatura_c": 48, "humedad_pct": 60}, "REVISAR_TEMPERATURA", "Una persona debe revisar la temperatura del dispositivo.")
    assert "compostera-cf-01" in prompt
    assert "48" in prompt
    assert "no inventar causas" in prompt.lower()
    assert "no cambiar la decisión" in prompt.lower()


def test_acciones_base_corresponden_a_decision():
    assert ACCIONES_BASE["REVISAR_TEMPERATURA"] == "Una persona debe revisar la temperatura del dispositivo."
    assert ACCIONES_BASE["REVISAR_HUMEDAD"] == "Una persona debe revisar la humedad del dispositivo."
    assert ACCIONES_BASE["DATOS_INCOMPLETOS"] == "Una persona debe comprobar los datos disponibles del dispositivo."
    assert ACCIONES_BASE["SIN_REVISION_PRIORITARIA"] == "El sistema no requiere una revisión prioritaria según las reglas didácticas actuales."


def test_cargar_demo_existe():
    path = Path(__file__).resolve().parent / "datos_contexto_demo.json"
    assert path.exists()
    datos = json.loads(path.read_text(encoding="utf-8"))
    assert datos["dispositivo_id"] == "compostera-cf-01"

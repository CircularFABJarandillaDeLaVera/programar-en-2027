# Control horario con FastAPI y PostgreSQL

En las practicas anteriores usamos `participantes` para aprender conceptos tecnicos.

Ahora vamos a cambiar de dominio: una pequena empresa necesita registrar entradas y salidas de sus trabajadores.

El objetivo no es construir un sistema laboral completo. El objetivo es crear el nucleo de una aplicacion real:

```text
Swagger
   |
   v
FastAPI
   |
   v
psycopg
   |
   v
PostgreSQL
   |
   v
trabajadores + fichajes
```

Swagger es la interfaz web que usamos para probar la API. Swagger envia peticiones. FastAPI aplica las reglas. PostgreSQL guarda los datos.

## 1. Que problema vamos a comprobar

Si guardamos los fichajes en una lista de Python, desaparecen al parar la aplicacion.

Con PostgreSQL queremos comprobar algo distinto:

1. Creamos una trabajadora llamada Ana.
2. Ana ficha ENTRADA.
3. Ana ficha SALIDA.
4. Paramos FastAPI.
5. Volvemos a arrancar FastAPI.
6. El historial de Ana sigue existiendo.

Ese es el momento importante de la practica: los datos permanecen.

## 2. Requisitos

Necesitas:

- Python 3.11 o superior.
- PostgreSQL funcionando.
- Un entorno virtual de Python.

PostgreSQL puede ejecutarse con Docker y un volumen, como en la experiencia anterior.

## 3. Arrancar PostgreSQL con Docker

Si no tienes ya un PostgreSQL preparado, puedes arrancar uno para esta practica:

```bash
docker volume create postgres_control_horario

docker run --name postgres-control-horario -e POSTGRES_USER=python -e POSTGRES_PASSWORD=CONTRASENA_DE_EJEMPLO -e POSTGRES_DB=control_horario -p 5432:5432 -v postgres_control_horario:/var/lib/postgresql/data -d postgres:16
```

El volumen `postgres_control_horario` permite que los datos sigan existiendo aunque pares el contenedor.

Si el contenedor ya existe y esta parado:

```bash
docker start postgres-control-horario
```

## 4. Entender las tablas

Necesitamos dos tablas:

```text
trabajadores
     |
     | 1 trabajador
     |
     +-------------> fichajes
                    muchos fichajes
```

`trabajadores` guarda quien puede fichar.

`fichajes` guarda cada entrada o salida.

Una fila es un registro concreto. Por ejemplo, una fila de `trabajadores` puede ser Ana.

Una columna es un dato de esa fila. Por ejemplo, `id` o `nombre`.

Una clave primaria identifica cada fila. En esta practica, `id` es la clave primaria.

Una clave foranea conecta una tabla con otra. En `fichajes`, la columna `trabajador_id` apunta al `id` de `trabajadores`. Asi sabemos a que trabajador pertenece cada fichaje.

## 5. Crear las tablas

La aplicacion intenta crear las tablas automaticamente al arrancar.

Este es el SQL importante:

```sql
CREATE TABLE IF NOT EXISTS trabajadores (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL
);

CREATE TABLE IF NOT EXISTS fichajes (
    id SERIAL PRIMARY KEY,
    trabajador_id INTEGER NOT NULL REFERENCES trabajadores(id),
    tipo VARCHAR(10) NOT NULL CHECK (tipo IN ('ENTRADA', 'SALIDA')),
    fecha_hora TIMESTAMPTZ NOT NULL
);
```

No necesitamos escribir `INSERT` manualmente para fichar desde Swagger. Cuando usamos `POST /trabajadores`, FastAPI provoca un `INSERT` en `trabajadores`. Cuando usamos `POST /fichajes/entrada` o `POST /fichajes/salida`, FastAPI provoca un `INSERT` en `fichajes`.

Para consultar, FastAPI ejecuta consultas `SELECT`.

## 6. Configurar la conexion desde Python

Copia el archivo de ejemplo:

```bash
copy .env.example .env
```

En PowerShell tambien puedes usar:

```powershell
Copy-Item .env.example .env
```

El archivo `.env` no debe subirse a Git. Por eso esta incluido en `.gitignore`.

Ejemplo de configuracion local:

```text
DB_HOST=localhost
DB_PORT=5432
DB_NAME=control_horario
DB_USER=python
DB_PASSWORD=CONTRASENA_DE_EJEMPLO
```

Usa la misma contrasena que hayas puesto al arrancar PostgreSQL.

## 7. Crear y activar el entorno virtual

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 8. Ejecutar FastAPI

```bash
uvicorn main:app --reload
```

Abre:

```text
http://127.0.0.1:8000/docs
```

## 9. Crear una trabajadora

En Swagger, abre:

```text
POST /trabajadores
```

Pulsa `Try it out` y envia:

```json
{
  "nombre": "Ana"
}
```

La respuesta debe devolver algo parecido a:

```json
{
  "id": 1,
  "nombre": "Ana"
}
```

Recuerda el `id`, porque lo usaremos para fichar.

## 10. Consultar trabajadores

Ejecuta:

```text
GET /trabajadores
```

Debe aparecer Ana.

## 11. Fichar ENTRADA

Ejecuta:

```text
POST /fichajes/entrada
```

Con el cuerpo:

```json
{
  "trabajador_id": 1
}
```

La fecha y hora no la escribe el trabajador. La registra el servidor automaticamente en UTC cuando recibe la peticion.

## 12. Consultar historial

Ejecuta:

```text
GET /trabajadores/1/fichajes
```

Debe aparecer un fichaje de tipo `ENTRADA` con `fecha_hora`.

## 13. Romper una regla: doble ENTRADA

Sin fichar salida, intenta otra vez:

```text
POST /fichajes/entrada
```

Debe rechazarse con un mensaje comprensible:

```text
No se puede registrar otra ENTRADA sin una SALIDA previa
```

## 14. Fichar SALIDA

Ejecuta:

```text
POST /fichajes/salida
```

Con el cuerpo:

```json
{
  "trabajador_id": 1
}
```

Ahora debe aceptarse.

## 15. Romper otra regla: doble SALIDA

Intenta otra salida seguida:

```text
POST /fichajes/salida
```

Debe rechazarse con un mensaje comprensible:

```text
No se puede registrar una SALIDA sin una ENTRADA abierta
```

## 16. Consultar el historial final

Ejecuta:

```text
GET /trabajadores/1/fichajes
```

Debe mostrar los fichajes en orden:

```text
Ana
ENTRADA
SALIDA
```

## 17. Comprobar la persistencia real

Para la aplicacion FastAPI:

```text
CTRL+C
```

Vuelve a arrancarla:

```bash
uvicorn main:app --reload
```

Abre de nuevo Swagger:

```text
http://127.0.0.1:8000/docs
```

Ejecuta:

```text
GET /trabajadores/1/fichajes
```

Resultado esperado:

```text
Los fichajes de Ana siguen existiendo.
```

Esto ya no es una API de ejemplo.

Acabamos de construir el nucleo de una aplicacion real de control horario.

## 18. Pruebas automaticas

Las pruebas automaticas comprueban reglas de la API sin depender de una base de datos real:

```bash
python -m unittest
```

Estas pruebas ayudan a detectar errores en comportamientos como:

- trabajador valido;
- trabajador inexistente;
- entrada correcta;
- doble entrada rechazada;
- salida correcta;
- doble salida rechazada;
- historial.

Estas pruebas no sustituyen la validacion real con PostgreSQL. La persistencia se comprueba parando y volviendo a arrancar FastAPI mientras PostgreSQL conserva sus datos.

from fastapi import FastAPI, HTTPException, status

from base_datos import (
    crear_fichaje_db,
    crear_trabajador_db,
    inicializar_base_de_datos,
    listar_fichajes_db,
    listar_fichajes_de_trabajador_db,
    listar_trabajadores_db,
    obtener_trabajador_db,
    obtener_ultimo_fichaje_db,
)
from modelos import Fichaje, FichajeEntrada, Trabajador, TrabajadorEntrada


app = FastAPI(
    title="API de Control Horario",
    description="MVP para registrar entradas y salidas con FastAPI y PostgreSQL.",
    version="1.0.0",
)


@app.on_event("startup")
def preparar_base_de_datos():
    inicializar_base_de_datos()


@app.get("/")
def inicio():
    return {"mensaje": "API de Control Horario funcionando", "documentacion": "/docs"}


@app.post("/trabajadores", response_model=Trabajador, status_code=status.HTTP_201_CREATED)
def crear_trabajador(datos: TrabajadorEntrada):
    return crear_trabajador_db(datos)


@app.get("/trabajadores", response_model=list[Trabajador])
def listar_trabajadores():
    return listar_trabajadores_db()


@app.post("/fichajes/entrada", response_model=Fichaje, status_code=status.HTTP_201_CREATED)
def fichar_entrada(datos: FichajeEntrada):
    trabajador = obtener_trabajador_db(datos.trabajador_id)
    if trabajador is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No existe un trabajador con ese id",
        )

    ultimo_fichaje = obtener_ultimo_fichaje_db(datos.trabajador_id)
    if ultimo_fichaje is not None and ultimo_fichaje.tipo == "ENTRADA":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No se puede registrar otra ENTRADA sin una SALIDA previa",
        )

    return crear_fichaje_db(datos.trabajador_id, "ENTRADA")


@app.post("/fichajes/salida", response_model=Fichaje, status_code=status.HTTP_201_CREATED)
def fichar_salida(datos: FichajeEntrada):
    trabajador = obtener_trabajador_db(datos.trabajador_id)
    if trabajador is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No existe un trabajador con ese id",
        )

    ultimo_fichaje = obtener_ultimo_fichaje_db(datos.trabajador_id)
    if ultimo_fichaje is None or ultimo_fichaje.tipo == "SALIDA":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No se puede registrar una SALIDA sin una ENTRADA abierta",
        )

    return crear_fichaje_db(datos.trabajador_id, "SALIDA")


@app.get("/fichajes", response_model=list[Fichaje])
def listar_fichajes():
    return listar_fichajes_db()


@app.get("/trabajadores/{trabajador_id}/fichajes", response_model=list[Fichaje])
def listar_fichajes_de_trabajador(trabajador_id: int):
    trabajador = obtener_trabajador_db(trabajador_id)
    if trabajador is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No existe un trabajador con ese id",
        )

    return listar_fichajes_de_trabajador_db(trabajador_id)

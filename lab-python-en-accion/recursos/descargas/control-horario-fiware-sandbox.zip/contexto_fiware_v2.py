import os
from dataclasses import dataclass
from datetime import datetime

import httpx

from modelos import TipoFichaje


TIMEOUT_FIWARE_V2 = 2.0


@dataclass
class ResultadoContexto:
    actualizado: bool
    mensaje_error: str | None = None


def obtener_fiware_v2_url() -> str:
    return os.getenv("FIWARE_V2_URL", "https://cb.iotplatform.telefonica.com:10027").rstrip("/")


def obtener_fiware_service() -> str:
    return os.getenv("FIWARE_SERVICE", "dip_caceres_sandbox")


def obtener_fiware_service_path() -> str:
    return os.getenv("FIWARE_SERVICE_PATH", "/10_Jarandilla_de_la_Vera")


def construir_id_entidad(trabajador_id: int) -> str:
    return f"Python2027_Employee_{trabajador_id}"


def formatear_fecha_ngsi_v2(fecha_hora: datetime) -> str:
    return fecha_hora.isoformat().replace("+00:00", "Z")


def construir_headers() -> dict:
    return {
        "Fiware-Service": obtener_fiware_service(),
        "Fiware-ServicePath": obtener_fiware_service_path(),
        "X-Auth-Token": os.getenv("FIWARE_TOKEN", ""),
        "Content-Type": "application/json",
    }


def construir_atributos(tipo_evento: TipoFichaje, fecha_hora: datetime) -> dict:
    return {
        "working": {
            "type": "Boolean",
            "value": tipo_evento == "ENTRADA",
        },
        "lastEvent": {
            "type": "Text",
            "value": tipo_evento,
        },
        "lastEventAt": {
            "type": "DateTime",
            "value": formatear_fecha_ngsi_v2(fecha_hora),
        },
    }


def construir_entidad(
    trabajador_id: int,
    tipo_evento: TipoFichaje,
    fecha_hora: datetime,
) -> dict:
    entidad = {
        "id": construir_id_entidad(trabajador_id),
        "type": "Employee",
    }
    entidad.update(construir_atributos(tipo_evento, fecha_hora))
    return entidad


def _mensaje_http_controlado(status_code: int, operacion: str) -> str:
    if status_code == 401:
        return "Token FIWARE invalido o caducado"
    if status_code == 403:
        return "Permiso insuficiente para actualizar FIWARE"
    return f"FIWARE NGSI v2 respondio {status_code} al {operacion}"


def actualizar_contexto_trabajador(
    trabajador_id: int,
    tipo_evento: TipoFichaje,
    fecha_hora: datetime,
) -> ResultadoContexto:
    fiware_url = obtener_fiware_v2_url()
    entity_id = construir_id_entidad(trabajador_id)
    headers = construir_headers()

    try:
        with httpx.Client(timeout=TIMEOUT_FIWARE_V2) as cliente:
            respuesta_patch = cliente.patch(
                f"{fiware_url}/v2/entities/{entity_id}/attrs",
                json=construir_atributos(tipo_evento, fecha_hora),
                headers=headers,
            )

            if respuesta_patch.status_code == 404:
                respuesta_post = cliente.post(
                    f"{fiware_url}/v2/entities",
                    json=construir_entidad(trabajador_id, tipo_evento, fecha_hora),
                    headers=headers,
                )
                if 200 <= respuesta_post.status_code < 300:
                    return ResultadoContexto(actualizado=True)

                return ResultadoContexto(
                    actualizado=False,
                    mensaje_error=_mensaje_http_controlado(respuesta_post.status_code, "crear la entidad"),
                )

            if 200 <= respuesta_patch.status_code < 300:
                return ResultadoContexto(actualizado=True)

            return ResultadoContexto(
                actualizado=False,
                mensaje_error=_mensaje_http_controlado(respuesta_patch.status_code, "actualizar la entidad"),
            )
    except httpx.TimeoutException:
        return ResultadoContexto(
            actualizado=False,
            mensaje_error="Timeout al actualizar FIWARE NGSI v2",
        )
    except httpx.RequestError as exc:
        return ResultadoContexto(
            actualizado=False,
            mensaje_error=f"No se pudo conectar con FIWARE NGSI v2: {exc.__class__.__name__}",
        )

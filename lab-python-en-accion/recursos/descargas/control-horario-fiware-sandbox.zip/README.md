# Control horario FIWARE sandbox

Practica temporal para una master class con sandbox FIWARE / ThinkingCity / Telefonica autorizado.

Esta carpeta parte de `control-horario-fiware`, pero no sustituye a la practica base. La integracion de esta copia usa NGSI v2, no Orion-LD ni NGSI-LD.

AVISO: NO PUBLICAR TOKENS NI CREDENCIALES.

## Objetivo

El control horario conserva el historico en PostgreSQL y, despues de guardar cada fichaje valido, intenta publicar el estado actual del trabajador en el Context Broker NGSI v2.

```text
TRABAJADOR
  -> FastAPI
  -> PostgreSQL historico
  -> Python + httpx
  -> Context Broker Telefonica contexto NGSI v2
```

## Requisitos

- Python con las dependencias de `requirements.txt`.
- PostgreSQL configurado como en la practica de control horario.
- Acceso autorizado al sandbox.
- Token FIWARE valido obtenido previamente.

La primera version no genera tokens desde Python. Usa `FIWARE_TOKEN` desde `.env`.

## Configuracion

Copia `.env.example` a `.env` y completa los valores locales:

```text
DB_HOST=localhost
DB_PORT=5432
DB_NAME=control_horario
DB_USER=python
DB_PASSWORD=...
EMPRESA_USUARIO=...
EMPRESA_PASSWORD=...
APP_TIMEZONE=Europe/Madrid
FIWARE_V2_URL=https://cb.iotplatform.telefonica.com:10027
FIWARE_SERVICE=dip_caceres_sandbox
FIWARE_SERVICE_PATH=/10_Jarandilla_de_la_Vera
FIWARE_TOKEN=...
```

No guardes tokens reales en el repositorio.

## Modelo NGSI v2

Entidad por trabajador:

```text
Python2027_Employee_{trabajador_id}
```

Tipo:

```text
Employee
```

Solo se publican estos atributos:

- `working`
- `lastEvent`
- `lastEventAt`

No se publican nombre, ubicacion, precision, credenciales, sesiones, hashes ni historico.

## Headers

Las peticiones al Context Broker construyen estos headers desde configuracion:

```text
Fiware-Service: dip_caceres_sandbox
Fiware-ServicePath: /10_Jarandilla_de_la_Vera
X-Auth-Token: <FIWARE_TOKEN>
Content-Type: application/json
```

## Actualizacion

Primero se intenta:

```text
PATCH /v2/entities/{id}/attrs
```

Body de ENTRADA:

```json
{
  "working": {
    "type": "Boolean",
    "value": true
  },
  "lastEvent": {
    "type": "Text",
    "value": "ENTRADA"
  },
  "lastEventAt": {
    "type": "DateTime",
    "value": "2026-08-30T08:02:00Z"
  }
}
```

Body de SALIDA:

```json
{
  "working": {
    "type": "Boolean",
    "value": false
  },
  "lastEvent": {
    "type": "Text",
    "value": "SALIDA"
  },
  "lastEventAt": {
    "type": "DateTime",
    "value": "2026-08-30T11:30:00Z"
  }
}
```

Si el PATCH devuelve `404`, Python crea la entidad con:

```text
POST /v2/entities
```

No se usan operaciones batch.

## Orden del fichaje

ENTRADA:

```text
1. Validar sesion y rol.
2. Comprobar que no exista otra ENTRADA abierta.
3. Guardar PostgreSQL.
4. Usar la fecha_hora guardada.
5. Intentar actualizar FIWARE NGSI v2.
```

SALIDA:

```text
1. Validar sesion y rol.
2. Comprobar que exista una ENTRADA abierta.
3. Guardar PostgreSQL.
4. Usar la fecha_hora guardada.
5. Intentar actualizar FIWARE NGSI v2.
```

PostgreSQL siempre tiene prioridad. Si FIWARE falla, no se revierte el fichaje historico.

## Errores controlados

- `401`: token invalido o caducado.
- `403`: permiso insuficiente.
- `404` en PATCH: se intenta crear la entidad.
- timeout: contexto no actualizado.
- error de conexion: contexto no actualizado.
- otros HTTP: fallo controlado.

La respuesta de trabajador mantiene lenguaje simple:

```text
Fichaje registrado.
```

Si el contexto falla:

```text
Fichaje registrado. Hay un problema temporal actualizando el estado compartido.
```

La interfaz del trabajador no menciona Keystone, NGSI v2, Telefonica ni token.

## Arrancar FastAPI

Desde esta carpeta:

```powershell
python -m uvicorn main:app --reload
```

Abrir:

```text
http://127.0.0.1:8000/app/fichar/
http://127.0.0.1:8000/app/empresa/
http://127.0.0.1:8000/docs
```

## Validacion manual del sandbox

Con token valido:

CASO A:

```text
ENTRADA
PostgreSQL guarda el fichaje.
Sandbox: working=true, lastEvent=ENTRADA.
```

CASO B:

```text
SALIDA
PostgreSQL guarda el fichaje.
Sandbox: working=false, lastEvent=SALIDA.
```

CASO C:

```text
Token invalido o caducado.
PostgreSQL guarda el fichaje.
La aplicacion devuelve el aviso comprensible.
```

Consultar una entidad desde Postman:

```text
GET https://cb.iotplatform.telefonica.com:10027/v2/entities/Python2027_Employee_7
```

Usar los mismos headers `Fiware-Service`, `Fiware-ServicePath` y `X-Auth-Token`.

## Tests automaticos

```powershell
python -m unittest -v test_api.py
python -m py_compile main.py contexto_fiware_v2.py base_datos.py modelos.py seguridad.py
```

Los tests automaticos usan mocks. No hacen llamadas reales al sandbox.

Evidencia validada:

```text
40 tests
OK

py_compile
OK
```

## Validacion real end-to-end

La practica fue validada contra PostgreSQL y el sandbox FIWARE / Telefonica autorizado.

Flujo confirmado:

```text
FastAPI
-> PostgreSQL
-> sandbox FIWARE Telefonica
-> entidad actualizada
```

Casos confirmados:

```text
ENTRADA
PostgreSQL guarda el fichaje.
FIWARE publica working=true y lastEvent=ENTRADA.

SALIDA
PostgreSQL guarda el fichaje.
FIWARE publica working=false y lastEvent=SALIDA.
```

La hora guardada en PostgreSQL y la hora publicada en FIWARE correspondieron al mismo instante, aunque se representaran en zonas horarias distintas.

No se documentan IDs reales de base de datos, nombres reales, tokens ni credenciales.

## No implementado todavia

- autenticacion Keystone automatica desde Python;
- RPA;
- MQTT;
- ESP32;
- IoT Agent;
- subscriptions;
- dashboard FIWARE;
- nuevos graficos;
- Keyrock;
- Wilma;
- OAuth;
- experiencia obligatoria nueva.

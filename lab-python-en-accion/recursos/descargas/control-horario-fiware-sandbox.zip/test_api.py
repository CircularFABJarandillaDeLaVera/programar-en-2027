import os
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import httpx
from fastapi.testclient import TestClient

import contexto_fiware_v2
import main
from base_datos import crear_resumen_empresa
from contexto_fiware_v2 import ResultadoContexto
from modelos import Fichaje, Trabajador, UsuarioSesion
from seguridad import crear_password_hash, crear_token_hash


class TestApiControlHorarioRoles(unittest.TestCase):
    def setUp(self):
        self.parche_inicio = patch("main.inicializar_base_de_datos")
        self.parche_inicio.start()
        self.cliente = TestClient(main.app)

    def tearDown(self):
        self.parche_inicio.stop()

    def poner_cookie_sesion(self):
        self.cliente.cookies.set(main.COOKIE_SESION, "token-de-prueba")

    def usuario_empresa(self):
        return UsuarioSesion(id=1, usuario="empresa", rol="EMPRESA")

    def usuario_trabajador(self):
        return UsuarioSesion(
            id=2,
            usuario="ana",
            rol="TRABAJADOR",
            trabajador_id=7,
            trabajador_nombre="Ana",
        )

    def fichaje(
        self,
        fichaje_id,
        trabajador_id,
        nombre,
        tipo,
        fecha_hora=None,
        latitud=None,
        longitud=None,
        precision_m=None,
    ):
        return Fichaje(
            id=fichaje_id,
            trabajador_id=trabajador_id,
            trabajador_nombre=nombre,
            tipo=tipo,
            fecha_hora=fecha_hora or datetime(2026, 8, 30, 8, 2, tzinfo=timezone.utc),
            latitud=latitud,
            longitud=longitud,
            precision_m=precision_m,
        )

    @patch("main.crear_sesion_db")
    @patch("main.obtener_usuario_por_nombre_db")
    def test_login_empresa_correcto_crea_cookie_de_sesion(self, obtener_usuario_por_nombre_db, crear_sesion_db):
        obtener_usuario_por_nombre_db.return_value = {
            "id": 1,
            "usuario": "empresa",
            "password_hash": crear_password_hash("password123"),
            "rol": "EMPRESA",
            "trabajador_id": None,
            "trabajador_nombre": None,
        }

        respuesta = self.cliente.post(
            "/auth/login",
            json={"usuario": "empresa", "password": "password123"},
        )

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.json()["rol"], "EMPRESA")
        self.assertIn(main.COOKIE_SESION, respuesta.headers["set-cookie"])
        crear_sesion_db.assert_called_once()

    @patch("main.obtener_usuario_por_nombre_db")
    def test_login_con_password_incorrecto_devuelve_401(self, obtener_usuario_por_nombre_db):
        obtener_usuario_por_nombre_db.return_value = {
            "id": 1,
            "usuario": "empresa",
            "password_hash": crear_password_hash("password123"),
            "rol": "EMPRESA",
            "trabajador_id": None,
            "trabajador_nombre": None,
        }

        respuesta = self.cliente.post(
            "/auth/login",
            json={"usuario": "empresa", "password": "mal"},
        )

        self.assertEqual(respuesta.status_code, 401)
        self.assertEqual(respuesta.json()["detail"], "Usuario o contrasena incorrectos")

    def test_endpoint_protegido_sin_sesion_devuelve_401(self):
        respuesta = self.cliente.get("/trabajadores")

        self.assertEqual(respuesta.status_code, 401)
        self.assertEqual(respuesta.json()["detail"], "Debes iniciar sesion")

    @patch("main.crear_trabajador_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_empresa_puede_crear_trabajador(self, obtener_usuario_por_token_hash_db, crear_trabajador_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_empresa()
        crear_trabajador_db.return_value = Trabajador(id=7, nombre="Ana")

        respuesta = self.cliente.post(
            "/trabajadores",
            json={"nombre": "Ana", "usuario": "ana", "password": "password123"},
        )

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json(), {"id": 7, "nombre": "Ana"})

    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_no_puede_crear_trabajador(self, obtener_usuario_por_token_hash_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()

        respuesta = self.cliente.post(
            "/trabajadores",
            json={"nombre": "Luis", "usuario": "luis", "password": "password123"},
        )

        self.assertEqual(respuesta.status_code, 403)
        self.assertEqual(respuesta.json()["detail"], "Esta operacion esta reservada a la empresa")

    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_no_puede_listar_trabajadores(self, obtener_usuario_por_token_hash_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()

        respuesta = self.cliente.get("/trabajadores")

        self.assertEqual(respuesta.status_code, 403)

    @patch("main.actualizar_contexto_trabajador")
    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_registra_entrada_con_su_identidad(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
        actualizar_contexto_trabajador,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None
        crear_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")
        actualizar_contexto_trabajador.return_value = ResultadoContexto(actualizado=True)

        respuesta = self.cliente.post("/fichajes/entrada", json={"trabajador_id": 999})

        self.assertEqual(respuesta.status_code, 201)
        crear_fichaje_db.assert_called_once_with(7, "ENTRADA", None, None, None)
        actualizar_contexto_trabajador.assert_called_once_with(
            7,
            "ENTRADA",
            crear_fichaje_db.return_value.fecha_hora,
        )

    @patch("main.actualizar_contexto_trabajador")
    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_registra_salida_con_su_identidad(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
        actualizar_contexto_trabajador,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")
        crear_fichaje_db.return_value = self.fichaje(2, 7, "Ana", "SALIDA")
        actualizar_contexto_trabajador.return_value = ResultadoContexto(actualizado=True)

        respuesta = self.cliente.post("/fichajes/salida", json={"trabajador_id": 999})

        self.assertEqual(respuesta.status_code, 201)
        crear_fichaje_db.assert_called_once_with(7, "SALIDA", None, None, None)
        actualizar_contexto_trabajador.assert_called_once_with(
            7,
            "SALIDA",
            crear_fichaje_db.return_value.fecha_hora,
        )

    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_doble_entrada_sigue_rechazada(self, obtener_usuario_por_token_hash_db, obtener_ultimo_fichaje_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")

        respuesta = self.cliente.post("/fichajes/entrada", json={})

        self.assertEqual(respuesta.status_code, 400)
        self.assertIn("SALIDA previa", respuesta.json()["detail"])

    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_salida_sin_entrada_sigue_rechazada(self, obtener_usuario_por_token_hash_db, obtener_ultimo_fichaje_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None

        respuesta = self.cliente.post("/fichajes/salida", json={})

        self.assertEqual(respuesta.status_code, 400)
        self.assertIn("ENTRADA abierta", respuesta.json()["detail"])

    @patch("main.actualizar_contexto_trabajador")
    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_entrada_con_ubicacion_sigue_guardando_geolocalizacion(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
        actualizar_contexto_trabajador,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None
        actualizar_contexto_trabajador.return_value = ResultadoContexto(actualizado=True)
        crear_fichaje_db.return_value = self.fichaje(
            1,
            7,
            "Ana",
            "ENTRADA",
            latitud=40.4168,
            longitud=-3.7038,
            precision_m=12.0,
        )

        respuesta = self.cliente.post(
            "/fichajes/entrada",
            json={"latitud": 40.4168, "longitud": -3.7038, "precision_m": 12.0},
        )

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json()["latitud"], 40.4168)
        crear_fichaje_db.assert_called_once_with(7, "ENTRADA", 40.4168, -3.7038, 12.0)

    @patch("main.actualizar_contexto_trabajador")
    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_entrada_sin_ubicacion_sigue_permitida(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
        actualizar_contexto_trabajador,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None
        crear_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")
        actualizar_contexto_trabajador.return_value = ResultadoContexto(actualizado=True)

        respuesta = self.cliente.post("/fichajes/entrada", json={})

        self.assertEqual(respuesta.status_code, 201)
        self.assertIsNone(respuesta.json()["latitud"])
        crear_fichaje_db.assert_called_once_with(7, "ENTRADA", None, None, None)

    @patch("main.actualizar_contexto_trabajador")
    @patch("main.crear_fichaje_db")
    @patch("main.obtener_ultimo_fichaje_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_fallo_fiware_no_revierte_el_fichaje(
        self,
        obtener_usuario_por_token_hash_db,
        obtener_ultimo_fichaje_db,
        crear_fichaje_db,
        actualizar_contexto_trabajador,
    ):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        obtener_ultimo_fichaje_db.return_value = None
        crear_fichaje_db.return_value = self.fichaje(1, 7, "Ana", "ENTRADA")
        actualizar_contexto_trabajador.return_value = ResultadoContexto(
            actualizado=False,
            mensaje_error="No se pudo conectar con FIWARE NGSI v2",
        )

        respuesta = self.cliente.post("/fichajes/entrada", json={})

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json()["tipo"], "ENTRADA")
        self.assertFalse(respuesta.json()["contexto_actualizado"])
        self.assertEqual(respuesta.json()["aviso"], main.AVISO_CONTEXTO)
        crear_fichaje_db.assert_called_once()

    @patch("main.listar_fichajes_de_trabajador_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_solo_consulta_sus_fichajes(self, obtener_usuario_por_token_hash_db, listar_fichajes):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()
        listar_fichajes.return_value = [self.fichaje(1, 7, "Ana", "ENTRADA")]

        respuesta = self.cliente.get("/yo/fichajes")

        self.assertEqual(respuesta.status_code, 200)
        listar_fichajes.assert_called_once_with(7)

    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_no_puede_consultar_fichajes_de_otro_trabajador(self, obtener_usuario_por_token_hash_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()

        respuesta = self.cliente.get("/trabajadores/8/fichajes")

        self.assertEqual(respuesta.status_code, 403)

    @patch("main.listar_fichajes_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_empresa_puede_consultar_todos_los_fichajes(self, obtener_usuario_por_token_hash_db, listar_fichajes):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_empresa()
        listar_fichajes.return_value = [self.fichaje(1, 7, "Ana", "ENTRADA")]

        respuesta = self.cliente.get("/fichajes")

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.json()[0]["trabajador_id"], 7)

    @patch("main.obtener_resumen_empresa_db")
    @patch("main.obtener_usuario_por_token_hash_db")
    def test_empresa_obtiene_resumen(self, obtener_usuario_por_token_hash_db, obtener_resumen_empresa_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_empresa()
        obtener_resumen_empresa_db.return_value = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana")],
            [],
            datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc),
            datetime(2026, 8, 31, 0, 0, tzinfo=timezone.utc),
            "2026-08-30",
            "UTC",
        )

        respuesta = self.cliente.get("/empresa/resumen")

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.json()["trabajando_ahora"], 0)

    @patch("main.obtener_usuario_por_token_hash_db")
    def test_trabajador_no_puede_obtener_resumen(self, obtener_usuario_por_token_hash_db):
        self.poner_cookie_sesion()
        obtener_usuario_por_token_hash_db.return_value = self.usuario_trabajador()

        respuesta = self.cliente.get("/empresa/resumen")

        self.assertEqual(respuesta.status_code, 403)

    def test_resumen_sin_sesion_devuelve_401(self):
        respuesta = self.cliente.get("/empresa/resumen")

        self.assertEqual(respuesta.status_code, 401)

    def test_resumen_sin_fichajes(self):
        resumen = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana")],
            [],
            datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc),
            datetime(2026, 8, 31, 0, 0, tzinfo=timezone.utc),
            "2026-08-30",
            "UTC",
        )

        self.assertEqual(resumen.trabajando_ahora, 0)
        self.assertEqual(resumen.entradas_hoy, 0)
        self.assertEqual(resumen.salidas_hoy, 0)
        self.assertEqual(resumen.trabajadores[0].estado, "SIN ACTIVIDAD")

    def test_resumen_trabajador_con_jornada_cerrada(self):
        inicio = datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc)
        resumen = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana")],
            [
                self.fichaje(1, 7, "Ana", "ENTRADA", fecha_hora=inicio + timedelta(hours=8)),
                self.fichaje(2, 7, "Ana", "SALIDA", fecha_hora=inicio + timedelta(hours=11)),
            ],
            inicio,
            inicio + timedelta(days=1),
            "2026-08-30",
            "UTC",
        )

        self.assertEqual(resumen.trabajadores[0].estado, "FUERA")
        self.assertEqual(resumen.trabajadores[0].tiempo_cerrado_hoy_minutos, 180)

    def test_resumen_trabajador_con_jornada_abierta(self):
        inicio = datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc)
        resumen = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana")],
            [self.fichaje(1, 7, "Ana", "ENTRADA", fecha_hora=inicio + timedelta(hours=8))],
            inicio,
            inicio + timedelta(days=1),
            "2026-08-30",
            "UTC",
        )

        self.assertEqual(resumen.trabajando_ahora, 1)
        self.assertEqual(resumen.trabajadores[0].estado, "TRABAJANDO")
        self.assertEqual(resumen.trabajadores[0].tiempo_cerrado_hoy_minutos, 0)

    def test_resumen_varios_trabajadores(self):
        inicio = datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc)
        resumen = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana"), Trabajador(id=8, nombre="Luis")],
            [
                self.fichaje(1, 7, "Ana", "ENTRADA", fecha_hora=inicio + timedelta(hours=8)),
                self.fichaje(2, 7, "Ana", "SALIDA", fecha_hora=inicio + timedelta(hours=10)),
                self.fichaje(3, 8, "Luis", "ENTRADA", fecha_hora=inicio + timedelta(hours=9)),
            ],
            inicio,
            inicio + timedelta(days=1),
            "2026-08-30",
            "UTC",
        )

        estados = {trabajador.nombre: trabajador.estado for trabajador in resumen.trabajadores}
        self.assertEqual(resumen.trabajando_ahora, 1)
        self.assertEqual(estados["Ana"], "FUERA")
        self.assertEqual(estados["Luis"], "TRABAJANDO")

    def test_resumen_suma_varios_tramos(self):
        inicio = datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc)
        resumen = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana")],
            [
                self.fichaje(1, 7, "Ana", "ENTRADA", fecha_hora=inicio + timedelta(hours=8)),
                self.fichaje(2, 7, "Ana", "SALIDA", fecha_hora=inicio + timedelta(hours=10)),
                self.fichaje(3, 7, "Ana", "ENTRADA", fecha_hora=inicio + timedelta(hours=11)),
                self.fichaje(4, 7, "Ana", "SALIDA", fecha_hora=inicio + timedelta(hours=12, minutes=30)),
            ],
            inicio,
            inicio + timedelta(days=1),
            "2026-08-30",
            "UTC",
        )

        self.assertEqual(resumen.trabajadores[0].tiempo_cerrado_hoy_minutos, 210)

    def test_resumen_cuenta_entradas_y_salidas_de_hoy(self):
        inicio = datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc)
        resumen = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana"), Trabajador(id=8, nombre="Luis")],
            [
                self.fichaje(1, 7, "Ana", "ENTRADA", fecha_hora=inicio + timedelta(hours=8)),
                self.fichaje(2, 7, "Ana", "SALIDA", fecha_hora=inicio + timedelta(hours=10)),
                self.fichaje(3, 8, "Luis", "ENTRADA", fecha_hora=inicio + timedelta(hours=9)),
            ],
            inicio,
            inicio + timedelta(days=1),
            "2026-08-30",
            "UTC",
        )

        self.assertEqual(resumen.entradas_hoy, 2)
        self.assertEqual(resumen.salidas_hoy, 1)

    def test_resumen_ultima_actividad(self):
        inicio = datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc)
        resumen = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana"), Trabajador(id=8, nombre="Luis")],
            [
                self.fichaje(1, 7, "Ana", "ENTRADA", fecha_hora=inicio + timedelta(hours=8)),
                self.fichaje(2, 8, "Luis", "ENTRADA", fecha_hora=inicio + timedelta(hours=9)),
            ],
            inicio,
            inicio + timedelta(days=1),
            "2026-08-30",
            "UTC",
        )

        self.assertEqual(resumen.ultima_actividad.trabajador_nombre, "Luis")

    def test_resumen_fichajes_fuera_de_hoy_no_contaminan_contadores(self):
        inicio = datetime(2026, 8, 30, 0, 0, tzinfo=timezone.utc)
        resumen = crear_resumen_empresa(
            [Trabajador(id=7, nombre="Ana")],
            [
                self.fichaje(1, 7, "Ana", "ENTRADA", fecha_hora=inicio - timedelta(hours=4)),
                self.fichaje(2, 7, "Ana", "SALIDA", fecha_hora=inicio - timedelta(hours=2)),
            ],
            inicio,
            inicio + timedelta(days=1),
            "2026-08-30",
            "UTC",
        )

        self.assertEqual(resumen.entradas_hoy, 0)
        self.assertEqual(resumen.salidas_hoy, 0)
        self.assertEqual(resumen.trabajadores[0].estado, "FUERA")

    @patch("main.eliminar_sesion_db")
    def test_logout_elimina_la_sesion_por_hash(self, eliminar_sesion_db):
        self.poner_cookie_sesion()

        respuesta = self.cliente.post("/auth/logout")

        self.assertEqual(respuesta.status_code, 200)
        eliminar_sesion_db.assert_called_once_with(crear_token_hash("token-de-prueba"))

    def test_interfaz_empresa_se_puede_servir(self):
        respuesta = self.cliente.get("/app/empresa/")

        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("text/html", respuesta.headers["content-type"])
        self.assertIn("Empresa", respuesta.text)

    def test_interfaz_fichar_se_puede_servir(self):
        respuesta = self.cliente.get("/app/fichar/")

        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("text/html", respuesta.headers["content-type"])
        self.assertIn("Fichar", respuesta.text)


class TestContextoFiwareV2(unittest.TestCase):
    def fecha_fichaje(self):
        return datetime(2026, 8, 30, 8, 2, tzinfo=timezone.utc)

    def test_construir_id_pedagogico_ngsi_v2_correctamente(self):
        self.assertEqual(
            contexto_fiware_v2.construir_id_entidad(7),
            "Python2027_Employee_7",
        )

    def test_last_event_at_procede_del_fichaje(self):
        atributos = contexto_fiware_v2.construir_atributos("ENTRADA", self.fecha_fichaje())

        self.assertEqual(atributos["lastEventAt"]["value"], "2026-08-30T08:02:00Z")
        self.assertEqual(atributos["lastEventAt"]["type"], "DateTime")

    @patch.dict(
        os.environ,
        {
            "FIWARE_SERVICE": "dip_caceres_sandbox",
            "FIWARE_SERVICE_PATH": "/10_Jarandilla_de_la_Vera",
            "FIWARE_TOKEN": "token-de-prueba",
        },
        clear=False,
    )
    def test_headers_correctos_incluyen_token(self):
        headers = contexto_fiware_v2.construir_headers()

        self.assertEqual(headers["Fiware-Service"], "dip_caceres_sandbox")
        self.assertEqual(headers["Fiware-ServicePath"], "/10_Jarandilla_de_la_Vera")
        self.assertEqual(headers["X-Auth-Token"], "token-de-prueba")
        self.assertEqual(headers["Content-Type"], "application/json")

    @patch.dict(
        os.environ,
        {
            "FIWARE_V2_URL": "https://cb.example.test",
            "FIWARE_SERVICE": "dip_caceres_sandbox",
            "FIWARE_SERVICE_PATH": "/10_Jarandilla_de_la_Vera",
            "FIWARE_TOKEN": "token-de-prueba",
        },
        clear=False,
    )
    @patch("contexto_fiware_v2.httpx.Client")
    def test_entidad_existente_hace_patch(self, cliente_http):
        cliente = cliente_http.return_value.__enter__.return_value
        cliente.patch.return_value = httpx.Response(204)

        resultado = contexto_fiware_v2.actualizar_contexto_trabajador(
            7,
            "ENTRADA",
            self.fecha_fichaje(),
        )

        self.assertTrue(resultado.actualizado)
        cliente.patch.assert_called_once()
        self.assertEqual(
            cliente.patch.call_args.args[0],
            "https://cb.example.test/v2/entities/Python2027_Employee_7/attrs",
        )
        self.assertEqual(cliente.patch.call_args.kwargs["headers"]["X-Auth-Token"], "token-de-prueba")
        self.assertEqual(cliente.patch.call_args.kwargs["json"]["working"]["value"], True)
        self.assertFalse(cliente.post.called)

    @patch("contexto_fiware_v2.httpx.Client")
    def test_entidad_inexistente_hace_patch_y_post(self, cliente_http):
        cliente = cliente_http.return_value.__enter__.return_value
        cliente.patch.return_value = httpx.Response(404)
        cliente.post.return_value = httpx.Response(201)

        resultado = contexto_fiware_v2.actualizar_contexto_trabajador(
            7,
            "ENTRADA",
            self.fecha_fichaje(),
        )

        self.assertTrue(resultado.actualizado)
        cliente.patch.assert_called_once()
        cliente.post.assert_called_once()
        entidad = cliente.post.call_args.kwargs["json"]
        self.assertEqual(cliente.post.call_args.args[0], "https://cb.iotplatform.telefonica.com:10027/v2/entities")
        self.assertEqual(entidad["id"], "Python2027_Employee_7")
        self.assertEqual(entidad["type"], "Employee")
        self.assertTrue(entidad["working"]["value"])

    @patch("contexto_fiware_v2.httpx.Client")
    def test_patch_salida_envia_working_false(self, cliente_http):
        cliente = cliente_http.return_value.__enter__.return_value
        cliente.patch.return_value = httpx.Response(204)

        resultado = contexto_fiware_v2.actualizar_contexto_trabajador(
            7,
            "SALIDA",
            self.fecha_fichaje(),
        )

        self.assertTrue(resultado.actualizado)
        atributos = cliente.patch.call_args.kwargs["json"]
        self.assertFalse(atributos["working"]["value"])
        self.assertEqual(atributos["lastEvent"]["value"], "SALIDA")

    @patch("contexto_fiware_v2.httpx.Client")
    def test_401_se_maneja_como_token_invalido(self, cliente_http):
        cliente = cliente_http.return_value.__enter__.return_value
        cliente.patch.return_value = httpx.Response(401)

        resultado = contexto_fiware_v2.actualizar_contexto_trabajador(
            7,
            "ENTRADA",
            self.fecha_fichaje(),
        )

        self.assertFalse(resultado.actualizado)
        self.assertIn("Token FIWARE invalido o caducado", resultado.mensaje_error)

    @patch("contexto_fiware_v2.httpx.Client")
    def test_403_se_maneja_como_permiso_insuficiente(self, cliente_http):
        cliente = cliente_http.return_value.__enter__.return_value
        cliente.patch.return_value = httpx.Response(403)

        resultado = contexto_fiware_v2.actualizar_contexto_trabajador(
            7,
            "ENTRADA",
            self.fecha_fichaje(),
        )

        self.assertFalse(resultado.actualizado)
        self.assertIn("Permiso insuficiente", resultado.mensaje_error)

    @patch("contexto_fiware_v2.httpx.Client")
    def test_error_de_conexion_se_maneja(self, cliente_http):
        cliente = cliente_http.return_value.__enter__.return_value
        cliente.patch.side_effect = httpx.ConnectError("sin conexion")

        resultado = contexto_fiware_v2.actualizar_contexto_trabajador(
            7,
            "ENTRADA",
            self.fecha_fichaje(),
        )

        self.assertFalse(resultado.actualizado)
        self.assertIn("FIWARE NGSI v2", resultado.mensaje_error)

    @patch("contexto_fiware_v2.httpx.Client")
    def test_timeout_se_maneja(self, cliente_http):
        cliente = cliente_http.return_value.__enter__.return_value
        cliente.patch.side_effect = httpx.TimeoutException("lento")

        resultado = contexto_fiware_v2.actualizar_contexto_trabajador(
            7,
            "ENTRADA",
            self.fecha_fichaje(),
        )

        self.assertFalse(resultado.actualizado)
        self.assertIn("Timeout", resultado.mensaje_error)


if __name__ == "__main__":
    unittest.main()

from pydantic import BaseModel, Field

class ParticipanteEntrada(BaseModel):
    nombre: str = Field(min_length=1, max_length=80)
    edad: int = Field(ge=0, le=120)

class Participante(ParticipanteEntrada):
    id: int

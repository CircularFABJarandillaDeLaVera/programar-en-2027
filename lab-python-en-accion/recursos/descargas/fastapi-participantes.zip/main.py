from fastapi import FastAPI, HTTPException, status
from modelos import Participante, ParticipanteEntrada

app = FastAPI(
    title="API de Participantes",
    description="API mínima para aprender FastAPI paso a paso.",
    version="1.0.0",
)

participantes: list[Participante] = []
siguiente_id = 1

@app.get("/")
def inicio():
    return {"mensaje": "API de Participantes funcionando", "documentacion": "/docs"}

@app.get("/participantes", response_model=list[Participante])
def listar_participantes():
    return participantes

@app.post("/participantes", response_model=Participante, status_code=status.HTTP_201_CREATED)
def crear_participante(datos: ParticipanteEntrada):
    global siguiente_id
    participante = Participante(id=siguiente_id, nombre=datos.nombre, edad=datos.edad)
    participantes.append(participante)
    siguiente_id += 1
    return participante

@app.get("/participantes/{participante_id}", response_model=Participante)
def obtener_participante(participante_id: int):
    for participante in participantes:
        if participante.id == participante_id:
            return participante
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail="Participante no encontrado",
    )

import unittest
from fastapi.testclient import TestClient
import main

class TestApiParticipantes(unittest.TestCase):
    def setUp(self):
        main.participantes.clear()
        main.siguiente_id = 1
        self.cliente = TestClient(main.app)

    def test_inicio_indica_que_la_api_funciona(self):
        r = self.cliente.get("/")
        self.assertEqual(r.status_code, 200)

    def test_lista_inicial_esta_vacia(self):
        r = self.cliente.get("/participantes")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json(), [])

    def test_crear_participante(self):
        r = self.cliente.post("/participantes", json={"nombre": "Ana", "edad": 35})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.json(), {"id": 1, "nombre": "Ana", "edad": 35})

    def test_consultar_participante_por_id(self):
        self.cliente.post("/participantes", json={"nombre": "Luis", "edad": 28})
        r = self.cliente.get("/participantes/1")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["nombre"], "Luis")

    def test_participante_inexistente_devuelve_404(self):
        r = self.cliente.get("/participantes/999")
        self.assertEqual(r.status_code, 404)
        self.assertEqual(r.json()["detail"], "Participante no encontrado")

    def test_edad_negativa_devuelve_error_de_validacion(self):
        r = self.cliente.post("/participantes", json={"nombre": "Marta", "edad": -5})
        self.assertEqual(r.status_code, 422)

if __name__ == "__main__":
    unittest.main()

# Experiencia 8 · Tu primera API con FastAPI

## 0. Antes de ejecutar nada: ubícate

Abre PowerShell en esta carpeta y ejecuta:

```powershell
dir
```

Debes ver `main.py`, `modelos.py`, `test_api.py`, `requirements.txt` y este `README.md`.
Si no aparecen, entra primero en la carpeta correcta.

## API en 5 minutos

Una API permite que dos programas se comuniquen.

```text
NAVEGADOR / APP
      ↓ HTTP
   FASTAPI
      ↓
    PYTHON
```

Métodos básicos:

- `GET`: consultar información.
- `POST`: crear o enviar información.
- `PUT/PATCH`: modificar información.
- `DELETE`: eliminar información.

Códigos habituales:

- `200`: petición correcta.
- `201`: recurso creado correctamente.
- `400`: la petición tiene algún problema.
- `404`: el recurso no existe.
- `422`: los datos enviados no cumplen las reglas esperadas.
- `500`: error del servidor.

## 1. Crear el entorno virtual

```powershell
python -m venv .venv
```

No hace falta activar `Activate.ps1`. Instalamos directamente con el Python del entorno:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 2. Arrancar la API

```powershell
.\.venv\Scripts\python.exe -m uvicorn main:app --reload
```

Abre:

```text
http://127.0.0.1:8000/docs
```

## 3. Cómo usar Swagger

Traducción rápida:

- `Try it out` → preparar una prueba.
- `Execute` → enviar la petición.
- `Request body` → datos que enviamos.
- `Server response` → respuesta del servidor.
- `Response body` → contenido recibido.
- `Code` → código HTTP.

Ver un ejemplo no significa que sea editable: primero pulsa `Try it out`.

## 4. GET /participantes

Abre `GET /participantes`.

Verás `No parameters`: no tienes que pegar nada.

Pulsa:

```text
Try it out → Execute
```

Busca:

```text
Code: 200
Response body: []
```

`[]` significa que la lista está vacía.

## 5. POST /participantes

Abre `POST /participantes` → `Try it out`.

En `Request body` escribe:

```json
{
  "nombre": "Ana",
  "edad": 35
}
```

Pulsa `Execute`.

Esperamos:

```text
Code: 201
```

y:

```json
{
  "nombre": "Ana",
  "edad": 35,
  "id": 1
}
```

Swagger puede mostrar una petición `curl`; no tienes que copiarla ni ejecutarla.

## 6. GET otra vez

Repite `GET /participantes`.

Ahora debe aparecer Ana.

```text
POST crea
GET consulta
```

## 7. Consultar por ID

En `GET /participantes/{participante_id}` prueba `1`.

Esperamos `200` y los datos del participante.

Después prueba `999`.

Esperamos:

```text
404
```

y:

```json
{"detail": "Participante no encontrado"}
```

## 8. Validación automática

En `POST /participantes`, prueba una edad negativa:

```json
{
  "nombre": "Luis",
  "edad": -10
}
```

Esperamos `422`.

La regla está en `modelos.py`:

```python
edad: int = Field(ge=0, le=120)
```

## 9. Tests

Detén Uvicorn con `Ctrl + C` y ejecuta:

```powershell
.\.venv\Scripts\python.exe -m unittest -v
```

Antes del mini-reto esperamos:

```text
Ran 6 tests
OK
```

Puede aparecer un `warning` de Starlette/TestClient. Si termina en `OK`, los tests han pasado.

# MINI-RETO · DELETE

Añade:

```text
DELETE /participantes/{participante_id}
```

Debe:

1. eliminar si el ID existe;
2. devolver un mensaje claro;
3. devolver `404` con `Participante no encontrado` si no existe;
4. añadir un test de eliminación correcta;
5. añadir otro test para un ID inexistente.

No añadas dependencias ni base de datos.

Objetivo final validado durante la preparación:

```text
POST Ana
→ GET Ana
→ DELETE Ana
→ GET Ana otra vez
→ 404
```

y:

```text
Ran 8 tests
OK
```

## Qué has aprendido

```text
GET     → consultar
POST    → crear
DELETE  → eliminar
200     → correcto
201     → creado
404     → no existe
422     → datos no válidos
```

La siguiente experiencia usará esta API para introducir Docker.

from fastapi import FastAPI, HTTPException, status

from base_datos import (
    crear_participante_db,
    inicializar_base_de_datos,
    listar_participantes_db,
    obtener_participante_db,
)
from modelos import Participante, ParticipanteEntrada


app = FastAPI(
    title="API de Participantes con PostgreSQL",
    description="API minima para aprender persistencia con FastAPI y PostgreSQL.",
    version="1.0.0",
)


@app.on_event("startup")
def preparar_base_de_datos():
    inicializar_base_de_datos()


@app.get("/")
def inicio():
    return {"mensaje": "API de Participantes con PostgreSQL funcionando", "documentacion": "/docs"}


@app.get("/participantes", response_model=list[Participante])
def listar_participantes():
    return listar_participantes_db()


@app.post("/participantes", response_model=Participante, status_code=status.HTTP_201_CREATED)
def crear_participante(datos: ParticipanteEntrada):
    return crear_participante_db(datos)


@app.get("/participantes/{participante_id}", response_model=Participante)
def obtener_participante(participante_id: int):
    participante = obtener_participante_db(participante_id)
    if participante is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Participante no encontrado",
        )
    return participante

import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

import main
from modelos import Participante


class TestApiParticipantesPostgreSQL(unittest.TestCase):
    def setUp(self):
        self.parche_inicio = patch("main.inicializar_base_de_datos")
        self.parche_inicio.start()
        self.cliente = TestClient(main.app)

    def tearDown(self):
        self.parche_inicio.stop()

    def test_inicio_indica_que_la_api_funciona(self):
        respuesta = self.cliente.get("/")
        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(
            respuesta.json()["mensaje"],
            "API de Participantes con PostgreSQL funcionando",
        )

    @patch("main.listar_participantes_db")
    def test_listar_participantes(self, listar_participantes_db):
        listar_participantes_db.return_value = [
            Participante(id=1, nombre="Ana", edad=35),
        ]

        respuesta = self.cliente.get("/participantes")

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.json(), [{"id": 1, "nombre": "Ana", "edad": 35}])

    @patch("main.crear_participante_db")
    def test_crear_participante(self, crear_participante_db):
        crear_participante_db.return_value = Participante(id=1, nombre="Ana", edad=35)

        respuesta = self.cliente.post("/participantes", json={"nombre": "Ana", "edad": 35})

        self.assertEqual(respuesta.status_code, 201)
        self.assertEqual(respuesta.json(), {"id": 1, "nombre": "Ana", "edad": 35})

    @patch("main.obtener_participante_db")
    def test_consultar_participante_por_id(self, obtener_participante_db):
        obtener_participante_db.return_value = Participante(id=1, nombre="Luis", edad=28)

        respuesta = self.cliente.get("/participantes/1")

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.json()["nombre"], "Luis")

    @patch("main.obtener_participante_db")
    def test_participante_inexistente_devuelve_404(self, obtener_participante_db):
        obtener_participante_db.return_value = None

        respuesta = self.cliente.get("/participantes/999")

        self.assertEqual(respuesta.status_code, 404)
        self.assertEqual(respuesta.json()["detail"], "Participante no encontrado")

    def test_edad_negativa_devuelve_error_de_validacion(self):
        respuesta = self.cliente.post("/participantes", json={"nombre": "Marta", "edad": -5})
        self.assertEqual(respuesta.status_code, 422)


if __name__ == "__main__":
    unittest.main()

# Experiencia 10 · Participantes con PostgreSQL

## Parte A · El problema: memoria

En las experiencias anteriores la API guardaba participantes en una lista de Python:

```text
Swagger -> FastAPI -> memoria
```

Eso funciona mientras la API está encendida, pero los datos no viven en una base de datos. Lo comprobamos así:

1. Creamos Ana desde Swagger en la API anterior.
2. Entramos en PostgreSQL.
3. Ejecutamos:

```sql
SELECT * FROM participantes;
```

PostgreSQL devolvió:

```text
(0 rows)
```

Conclusión: PostgreSQL estaba funcionando, pero la API todavía no estaba conectada a él.

---

## Parte B · PostgreSQL

PostgreSQL es una base de datos. Sirve para guardar información de forma organizada y recuperarla después.

En esta práctica usamos PostgreSQL 17 dentro de Docker:

```powershell
docker run --name postgres-python `
  -e POSTGRES_USER=python `
  -e POSTGRES_PASSWORD=python2027 `
  -e POSTGRES_DB=participantes `
  -p 5432:5432 `
  -d postgres:17
```

Estas son credenciales de laboratorio local, no credenciales de producción.

Comprueba que el contenedor está funcionando:

```powershell
docker ps
```

Debes ver algo equivalente a:

```text
postgres:17
0.0.0.0:5432->5432/tcp
postgres-python
```

Entra en PostgreSQL:

```powershell
docker exec -it postgres-python psql -U python -d participantes
```

---

## Tabla, fila, columna y clave primaria

Una base de datos organiza la información en tablas.

```text
TABLA: participantes

id | nombre | edad
---+--------+-----
1  | Ana    | 35
```

- Una `tabla` agrupa datos del mismo tipo.
- Una `fila` representa un registro concreto, por ejemplo Ana.
- Una `columna` representa un dato de cada registro, por ejemplo `nombre`.
- Una `clave primaria` identifica cada fila de forma única. Aquí será `id`.

Crea la tabla:

```sql
CREATE TABLE participantes (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    edad INTEGER NOT NULL
);
```

Comprueba que está vacía:

```sql
SELECT * FROM participantes;
```

---

## Parte C · Conectar FastAPI con PostgreSQL

Ahora queremos:

```text
Swagger -> FastAPI -> psycopg -> PostgreSQL
```

Abre otra terminal PowerShell en esta carpeta y comprueba:

```powershell
dir
```

Debes ver:

```text
main.py
modelos.py
base_datos.py
test_api.py
requirements.txt
.env.example
README.md
```

Crea el entorno e instala dependencias:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Usamos:

- `fastapi` y `uvicorn` para la API.
- `psycopg` para conectar Python con PostgreSQL.
- `python-dotenv` para leer variables desde `.env`.

Copia `.env.example` como `.env`:

```powershell
Copy-Item .env.example .env
```

Contenido de laboratorio:

```text
DB_HOST=localhost
DB_PORT=5432
DB_NAME=participantes
DB_USER=python
DB_PASSWORD=python2027
```

Como FastAPI se ejecuta en Windows y PostgreSQL está en Docker:

```text
FastAPI en Windows
        ↓
localhost:5432
        ↓
PostgreSQL en Docker
```

No subas `.env` a Git. Está incluido en `.gitignore`.

Arranca FastAPI:

```powershell
.\.venv\Scripts\python.exe -m uvicorn main:app --reload
```

Abre Swagger:

```text
http://127.0.0.1:8000/docs
```

---

## POST = INSERT

En Swagger, abre `POST /participantes`, pulsa `Try it out` y usa:

```json
{
  "nombre": "Ana",
  "edad": 35
}
```

Pulsa `Execute`.

Lo que ocurre por dentro:

```text
FastAPI recibe POST
        ↓
Python ejecuta INSERT
        ↓
PostgreSQL guarda la fila
```

SQL visible en `base_datos.py`:

```sql
INSERT INTO participantes (nombre, edad)
VALUES (..., ...)
RETURNING id, nombre, edad;
```

No hagas este `INSERT` a mano si ya lo haces desde Swagger.

---

## GET = SELECT

Ejecuta `GET /participantes` en Swagger.

Lo que ocurre por dentro:

```text
FastAPI recibe GET
        ↓
Python ejecuta SELECT
        ↓
PostgreSQL devuelve las filas
```

SQL visible en `base_datos.py`:

```sql
SELECT id, nombre, edad FROM participantes ORDER BY id;
```

Vuelve a `psql` y comprueba directamente:

```sql
SELECT * FROM participantes;
```

Ahora debe aparecer Ana con un `id` generado por PostgreSQL.

---

## Parte D · Persistencia

Para comprobar que ya no dependemos de la memoria de FastAPI:

1. Para Uvicorn con `Ctrl + C`.
2. Vuelve a arrancarlo:

```powershell
.\.venv\Scripts\python.exe -m uvicorn main:app --reload
```

3. Abre Swagger.
4. Ejecuta `GET /participantes`.

Resultado:

```text
Ana sigue existiendo.
```

Conclusión:

```text
MEMORIA -> los datos desaparecen
BASE DE DATOS -> los datos permanecen
```

Persistencia FastAPI -> PostgreSQL: validada.

---

## Parte E · Contenedor vs datos

Hay un segundo problema importante.

PostgreSQL está dentro de un contenedor. Si paramos y arrancamos el mismo contenedor:

```powershell
docker stop postgres-python
docker start postgres-python
```

Los datos siguen ahí.

Pero si eliminamos el contenedor y creamos otro sin almacenamiento persistente, el almacenamiento anterior no se conserva:

```text
docker rm + nuevo contenedor sin volumen -> tabla y datos desaparecen
```

Esto también se comprobó realmente.

---

## Parte F · Volumen Docker

La solución es separar la vida del contenedor de la vida de los datos.

```text
CONTENEDOR
    ↓
VOLUMEN
    ↓
DATOS
```

Crea un volumen:

```powershell
docker volume create datos-postgres-python
```

Arranca PostgreSQL usando ese volumen:

```powershell
docker run --name postgres-python `
  -e POSTGRES_USER=python `
  -e POSTGRES_PASSWORD=python2027 `
  -e POSTGRES_DB=participantes `
  -p 5432:5432 `
  -v datos-postgres-python:/var/lib/postgresql/data `
  -d postgres:17
```

Entra con `psql`, crea la tabla y añade un dato de prueba desde Swagger o con SQL mínimo:

```sql
INSERT INTO participantes (nombre, edad)
VALUES ('Luis', 28);
```

Comprueba:

```sql
SELECT * FROM participantes;
```

Ahora elimina el contenedor y crea otro conectado al mismo volumen. Al ejecutar de nuevo:

```sql
SELECT * FROM participantes;
```

Luis sigue existiendo.

Resultado final:

```text
No solo hemos conseguido que FastAPI guarde datos en PostgreSQL.
También hemos separado la vida del contenedor de la vida de los datos.
```

---

## Tests automatizados y prueba real

Puedes ejecutar:

```powershell
.\.venv\Scripts\python.exe -m unittest -v
```

Estos tests comprueban rutas, validaciones y respuestas usando dobles de prueba. Son útiles, pero no sustituyen la prueba real con PostgreSQL.

La prueba real completa es:

```text
POST Ana -> SELECT en PostgreSQL -> parar FastAPI -> arrancar FastAPI -> GET participantes -> volumen conserva datos
```

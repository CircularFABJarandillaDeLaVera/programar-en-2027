import os

import psycopg
from dotenv import load_dotenv
from psycopg.rows import dict_row

from modelos import Participante, ParticipanteEntrada


load_dotenv()


def obtener_conexion():
    return psycopg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "participantes"),
        user=os.getenv("DB_USER", "python"),
        password=os.getenv("DB_PASSWORD", ""),
        row_factory=dict_row,
    )


def inicializar_base_de_datos() -> None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS participantes (
                    id SERIAL PRIMARY KEY,
                    nombre VARCHAR(100) NOT NULL,
                    edad INTEGER NOT NULL
                )
                """
            )


def listar_participantes_db() -> list[Participante]:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute("SELECT id, nombre, edad FROM participantes ORDER BY id")
            filas = cursor.fetchall()

    return [Participante(**fila) for fila in filas]


def crear_participante_db(datos: ParticipanteEntrada) -> Participante:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO participantes (nombre, edad)
                VALUES (%s, %s)
                RETURNING id, nombre, edad
                """,
                (datos.nombre, datos.edad),
            )
            fila = cursor.fetchone()

    return Participante(**fila)


def obtener_participante_db(participante_id: int) -> Participante | None:
    with obtener_conexion() as conexion:
        with conexion.cursor() as cursor:
            cursor.execute(
                "SELECT id, nombre, edad FROM participantes WHERE id = %s",
                (participante_id,),
            )
            fila = cursor.fetchone()

    if fila is None:
        return None

    return Participante(**fila)

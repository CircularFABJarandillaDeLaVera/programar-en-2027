import argparse
import json
import os
from pathlib import Path
from typing import TypedDict

import requests
from langgraph.graph import END, START, StateGraph

ORION_URL = os.getenv("ORION_URL", "http://localhost:1026").rstrip("/")
DEMO_PATH = Path(__file__).with_name("datos_contexto_demo.json")


class EstadoContexto(TypedDict):
    dispositivo_id: str
    temperatura_c: float | None
    humedad_pct: int | None
    datos_validos: bool
    estado_revision: str
    mensaje: str
    usa_demo: bool
    fuente: str
    ruta: str


def cargar_contexto_demo() -> dict:
    with DEMO_PATH.open("r", encoding="utf-8") as archivo:
        return json.load(archivo)


def consultar_fiware_real(dispositivo_id: str = "compostera-cf-01") -> dict:
    url = f"{ORION_URL}/ngsi-ld/v1/entities/urn:ngsi-ld:Device:{dispositivo_id}"
    try:
        respuesta = requests.get(url, timeout=3)
        if respuesta.status_code == 200:
            datos = respuesta.json()
            return {
                "dispositivo_id": dispositivo_id,
                "temperatura_c": datos.get("temperature", {}).get("value"),
                "humedad_pct": datos.get("humidity", {}).get("value"),
            }
        raise RuntimeError(f"FIWARE no disponible: HTTP {respuesta.status_code}. Ejecuta --demo para explorar el flujo con datos de demostración.")
    except requests.RequestException as exc:
        raise RuntimeError(f"FIWARE no disponible: {exc}. Ejecuta --demo para explorar el flujo con datos de demostración.") from exc


def obtener_contexto(estado: EstadoContexto) -> EstadoContexto:
    usa_demo = bool(estado.get("usa_demo", False))
    if usa_demo:
        contexto = cargar_contexto_demo()
        fuente = "DATOS DE DEMOSTRACIÓN"
    else:
        try:
            contexto = consultar_fiware_real(estado.get("dispositivo_id", "compostera-cf-01"))
            fuente = "FIWARE REAL"
        except RuntimeError as exc:
            raise RuntimeError(
                "FIWARE no disponible. Ejecuta --demo para explorar el flujo con datos de demostración."
            ) from exc

    estado["dispositivo_id"] = contexto.get("dispositivo_id", "compostera-cf-01")
    estado["temperatura_c"] = contexto.get("temperatura_c")
    estado["humedad_pct"] = contexto.get("humedad_pct")
    estado["usa_demo"] = usa_demo
    estado["fuente"] = fuente
    estado["mensaje"] = f"FUENTE DE DATOS: {fuente}"
    return estado


def validar_datos(estado: EstadoContexto) -> EstadoContexto:
    temperatura = estado.get("temperatura_c")
    humedad = estado.get("humedad_pct")
    if temperatura is None or humedad is None:
        estado["datos_validos"] = False
        estado["estado_revision"] = "DATOS_INCOMPLETOS"
        estado["mensaje"] = f"{estado.get('mensaje', '')} | Datos incompletos."
        return estado

    estado["datos_validos"] = True
    estado["estado_revision"] = ""
    estado["mensaje"] = f"{estado.get('mensaje', '')} | Datos válidos."
    return estado


def evaluar_estado(estado: EstadoContexto) -> EstadoContexto:
    if not estado.get("datos_validos", False):
        estado["estado_revision"] = "DATOS_INCOMPLETOS"
        estado["ruta"] = "datos_incompletos"
        return estado

    temperatura = estado.get("temperatura_c")
    humedad = estado.get("humedad_pct")

    if temperatura is not None and temperatura >= 45:
        estado["estado_revision"] = "REVISAR_TEMPERATURA"
        estado["ruta"] = "revisar_temperatura"
        return estado

    if humedad is not None and humedad < 50:
        estado["estado_revision"] = "REVISAR_HUMEDAD"
        estado["ruta"] = "revisar_humedad"
        return estado

    estado["estado_revision"] = "SIN_REVISION_PRIORITARIA"
    estado["ruta"] = "sin_revision"
    return estado


def seleccionar_ruta(estado: EstadoContexto) -> str:
    alternativas = {
        "DATOS_INCOMPLETOS": "datos_incompletos",
        "REVISAR_TEMPERATURA": "revisar_temperatura",
        "REVISAR_HUMEDAD": "revisar_humedad",
    }
    return alternativas.get(estado.get("estado_revision", "SIN_REVISION_PRIORITARIA"), "sin_revision")


def nodo_datos_incompletos(estado: EstadoContexto) -> EstadoContexto:
    estado["ruta"] = "datos_incompletos"
    return estado


def nodo_revisar_temperatura(estado: EstadoContexto) -> EstadoContexto:
    estado["ruta"] = "revisar_temperatura"
    return estado


def nodo_revisar_humedad(estado: EstadoContexto) -> EstadoContexto:
    estado["ruta"] = "revisar_humedad"
    return estado


def nodo_sin_revision(estado: EstadoContexto) -> EstadoContexto:
    estado["ruta"] = "sin_revision"
    return estado


def construir_grafo():
    grafo = StateGraph(EstadoContexto)
    grafo.add_node("obtener_contexto", obtener_contexto)
    grafo.add_node("validar_datos", validar_datos)
    grafo.add_node("evaluar_estado", evaluar_estado)
    grafo.add_node("datos_incompletos", nodo_datos_incompletos)
    grafo.add_node("revisar_temperatura", nodo_revisar_temperatura)
    grafo.add_node("revisar_humedad", nodo_revisar_humedad)
    grafo.add_node("sin_revision", nodo_sin_revision)

    grafo.add_edge(START, "obtener_contexto")
    grafo.add_edge("obtener_contexto", "validar_datos")
    grafo.add_edge("validar_datos", "evaluar_estado")
    grafo.add_conditional_edges(
        "evaluar_estado",
        seleccionar_ruta,
        {
            "datos_incompletos": "datos_incompletos",
            "revisar_temperatura": "revisar_temperatura",
            "revisar_humedad": "revisar_humedad",
            "sin_revision": "sin_revision",
        },
    )
    grafo.add_edge("datos_incompletos", END)
    grafo.add_edge("revisar_temperatura", END)
    grafo.add_edge("revisar_humedad", END)
    grafo.add_edge("sin_revision", END)
    return grafo.compile()


def ejecutar_flujo(dispositivo_id: str = "compostera-cf-01", usa_demo: bool = False) -> dict:
    estado_inicial: EstadoContexto = {
        "dispositivo_id": dispositivo_id,
        "temperatura_c": None,
        "humedad_pct": None,
        "datos_validos": False,
        "estado_revision": "",
        "mensaje": "",
        "usa_demo": usa_demo,
        "fuente": "",
        "ruta": "",
    }

    try:
        app = construir_grafo()
        resultado = app.invoke(estado_inicial)
    except RuntimeError as exc:
        print(f"ERROR: {exc}")
        raise

    print(f"FUENTE DE DATOS: {resultado['fuente']}")
    print()
    print("CONTEXTO RECIBIDO")
    print(f"Dispositivo: {resultado['dispositivo_id']}")
    print(f"Temperatura: {resultado['temperatura_c']} °C")
    print(f"Humedad: {resultado['humedad_pct']} %")
    print()
    print("GRAFO")
    print(f"obtener_contexto → validar_datos → evaluar_estado → {resultado['ruta']}")
    print()
    print("RESULTADO")
    print(resultado["estado_revision"])
    return resultado


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Flujo de contexto para la experiencia 22.")
    parser.add_argument("--demo", action="store_true", help="Usa datos de demostración en lugar de FIWARE real.")
    parser.add_argument("--dispositivo", default="compostera-cf-01", help="ID del dispositivo a consultar.")
    args = parser.parse_args()
    ejecutar_flujo(dispositivo_id=args.dispositivo, usa_demo=args.demo)

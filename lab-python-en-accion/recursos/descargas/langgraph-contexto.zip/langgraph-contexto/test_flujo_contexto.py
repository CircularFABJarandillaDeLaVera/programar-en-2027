import json
from pathlib import Path

import pytest

from flujo_contexto import (
    construir_grafo,
    evaluar_estado,
    obtener_contexto,
    validar_datos,
)


@pytest.fixture
def demo_data():
    return json.loads(Path("datos_contexto_demo.json").read_text(encoding="utf-8"))


def estado_base(**overrides):
    estado = {
        "dispositivo_id": "compostera-cf-01",
        "temperatura_c": None,
        "humedad_pct": None,
        "datos_validos": False,
        "estado_revision": "",
        "mensaje": "",
        "usa_demo": False,
        "fuente": "",
        "ruta": "",
    }
    estado.update(overrides)
    return estado


def test_datos_normales():
    estado = {
        "dispositivo_id": "compostera-cf-01",
        "temperatura_c": 43.5,
        "humedad_pct": 60,
        "datos_validos": True,
        "estado_revision": "",
        "mensaje": "",
    }
    estado = validar_datos(estado)
    resultado = evaluar_estado(estado)
    assert resultado["estado_revision"] == "SIN_REVISION_PRIORITARIA"


def test_temperatura_alta():
    estado = {
        "dispositivo_id": "compostera-cf-01",
        "temperatura_c": 48,
        "humedad_pct": 60,
        "datos_validos": True,
        "estado_revision": "",
        "mensaje": "",
    }
    estado = validar_datos(estado)
    resultado = evaluar_estado(estado)
    assert resultado["estado_revision"] == "REVISAR_TEMPERATURA"


def test_humedad_baja():
    estado = {
        "dispositivo_id": "compostera-cf-01",
        "temperatura_c": 40,
        "humedad_pct": 45,
        "datos_validos": True,
        "estado_revision": "",
        "mensaje": "",
    }
    estado = validar_datos(estado)
    resultado = evaluar_estado(estado)
    assert resultado["estado_revision"] == "REVISAR_HUMEDAD"


def test_datos_incompletos():
    estado = {
        "dispositivo_id": "compostera-cf-01",
        "temperatura_c": None,
        "humedad_pct": 60,
        "datos_validos": True,
        "estado_revision": "",
        "mensaje": "",
    }
    estado = validar_datos(estado)
    resultado = evaluar_estado(estado)
    assert resultado["estado_revision"] == "DATOS_INCOMPLETOS"


def test_grafo_ruta_normal(monkeypatch):
    monkeypatch.setattr(
        "flujo_contexto.consultar_fiware_real",
        lambda dispositivo_id="compostera-cf-01": {
            "dispositivo_id": dispositivo_id,
            "temperatura_c": 43.5,
            "humedad_pct": 60,
        },
    )
    app = construir_grafo()
    resultado = app.invoke(estado_base(usa_demo=False))

    assert resultado["fuente"] == "FIWARE REAL"
    assert resultado["estado_revision"] == "SIN_REVISION_PRIORITARIA"
    assert resultado["ruta"] == "sin_revision"


def test_grafo_ruta_temperatura_alta(monkeypatch):
    monkeypatch.setattr(
        "flujo_contexto.consultar_fiware_real",
        lambda dispositivo_id="compostera-cf-01": {
            "dispositivo_id": dispositivo_id,
            "temperatura_c": 48,
            "humedad_pct": 60,
        },
    )
    app = construir_grafo()
    resultado = app.invoke(estado_base(usa_demo=False))

    assert resultado["fuente"] == "FIWARE REAL"
    assert resultado["estado_revision"] == "REVISAR_TEMPERATURA"
    assert resultado["ruta"] == "revisar_temperatura"


def test_grafo_ruta_humedad_baja(monkeypatch):
    monkeypatch.setattr(
        "flujo_contexto.consultar_fiware_real",
        lambda dispositivo_id="compostera-cf-01": {
            "dispositivo_id": dispositivo_id,
            "temperatura_c": 40,
            "humedad_pct": 45,
        },
    )
    app = construir_grafo()
    resultado = app.invoke(estado_base(usa_demo=False))

    assert resultado["fuente"] == "FIWARE REAL"
    assert resultado["estado_revision"] == "REVISAR_HUMEDAD"
    assert resultado["ruta"] == "revisar_humedad"


def test_grafo_ruta_datos_incompletos(monkeypatch):
    monkeypatch.setattr(
        "flujo_contexto.consultar_fiware_real",
        lambda dispositivo_id="compostera-cf-01": {
            "dispositivo_id": dispositivo_id,
            "temperatura_c": None,
            "humedad_pct": 60,
        },
    )
    app = construir_grafo()
    resultado = app.invoke(estado_base(usa_demo=False))

    assert resultado["fuente"] == "FIWARE REAL"
    assert resultado["estado_revision"] == "DATOS_INCOMPLETOS"
    assert resultado["ruta"] == "datos_incompletos"


def test_demo_usa_fuente_demo_y_pasa_por_langgraph(monkeypatch):
    monkeypatch.setattr(
        "flujo_contexto.cargar_contexto_demo",
        lambda: {
            "dispositivo_id": "compostera-cf-01",
            "temperatura_c": 48,
            "humedad_pct": 60,
        },
    )
    app = construir_grafo()
    resultado = app.invoke(estado_base(usa_demo=True))

    assert resultado["fuente"] == "DATOS DE DEMOSTRACIÓN"
    assert resultado["estado_revision"] == "REVISAR_TEMPERATURA"
    assert resultado["ruta"] == "revisar_temperatura"


def test_fiware_usa_fuente_fiware():
    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(
        "flujo_contexto.consultar_fiware_real",
        lambda dispositivo_id="compostera-cf-01": {
            "dispositivo_id": dispositivo_id,
            "temperatura_c": 43.5,
            "humedad_pct": 60,
        },
    )
    try:
        app = construir_grafo()
        resultado = app.invoke(estado_base(usa_demo=False))
        assert resultado["fuente"] == "FIWARE REAL"
        assert resultado["ruta"] == "sin_revision"
    finally:
        monkeypatch.undo()


def test_fiware_falla_no_hace_fallback_silencioso(monkeypatch):
    monkeypatch.setattr(
        "flujo_contexto.consultar_fiware_real",
        lambda dispositivo_id="compostera-cf-01": (_ for _ in ()).throw(RuntimeError("FIWARE no disponible")),
    )

    with pytest.raises(RuntimeError, match="Ejecuta --demo"):
        construir_grafo().invoke(estado_base(usa_demo=False))

    assert True

# Experiencia 22 · Del contexto a una decisión

## Necesidad primero

La empresa ya puede consultar el contexto actual de un dispositivo. Eso aporta datos, pero no organiza un proceso de decisión.

El siguiente paso es convertir esa información en un flujo con estado y rutas condicionales.

```text
FIWARE -> contexto actual
      ↓
  LANGGRAPH
      ↓
  DECISIÓN
```

No se empieza por la tecnología. Primero aparece la necesidad: entender el estado del dispositivo y decidir qué hacer según él.

## ¿Por qué LangGraph aquí?

La lógica también podría resolverse con `if/else` sencillos. La razón de esta práctica es pedagógica: mostrar de forma pequeña y visible:

- estado;
- nodo;
- transición;
- ruta condicional.

La intención no es vender LangGraph como la única solución. Es una forma clara de representar un flujo de decisión antes de construir uno más grande.

## Qué no se hace aquí

Esta experiencia es determinista y no usa LLM ni APIs externas.

No se usa:

- OpenAI
- Claude
- Gemini
- Ollama
- LangChain agents
- modelos generativos

La siguiente experiencia podrá introducir ese salto.

## Arquitectura didáctica

```text
ORION-LD / FIWARE
       ↓
NODO 1: obtener_contexto
       ↓
NODO 2: validar_datos
       ↓
NODO 3: evaluar_estado
       ↓
  DECISIÓN CONDICIONAL
     ↙              ↘
SIN REVISIÓN      REVISAR
     ↓              ↓
   RESULTADO      RESULTADO
```

## Estado del grafo

El flujo trabaja con un estado pequeño y legible:

- `dispositivo_id`
- `temperatura_c`
- `humedad_pct`
- `datos_validos`
- `estado_revision`
- `mensaje`

## Fuente de datos principal

La práctica intenta consultar Orion-LD real en:

```text
http://localhost:1026
```

Entidad esperada:

```text
urn:ngsi-ld:Device:compostera-cf-01
```

Se reutiliza el mismo modelo FIWARE de la Experiencia 21.

## Plan B educativo

Si FIWARE no está disponible, la práctica usa datos preparados en `datos_contexto_demo.json`.

Debe quedar visible la fuente:

```text
FUENTE DE DATOS: FIWARE REAL
```

o:

```text
FUENTE DE DATOS: DATOS DE DEMOSTRACIÓN
```

Nunca se ocultará un fallo de FIWARE con un valor silencioso.

## Reglas didácticas

Las reglas son ficticias para aprender rutas condicionales y no implican criterio agronómico real.

- si falta temperatura o humedad: `DATOS_INCOMPLETOS`
- si temperatura_c >= 45: `REVISAR_TEMPERATURA`
- si humedad_pct < 50: `REVISAR_HUMEDAD`
- en otro caso: `SIN_REVISION_PRIORITARIA`

## Resultado observable

Ejemplo de salida esperada:

```text
CONTEXTO RECIBIDO
Dispositivo: compostera-cf-01
Temperatura: 43.5 °C
Humedad: 60 %

GRAFO
obtener_contexto
→ validar_datos
→ evaluar_estado
→ sin_revision

RESULTADO
Sin revisión prioritaria según las reglas didácticas de esta práctica.
```

## Mini-reto

Modifica únicamente `datos_contexto_demo.json` y prueba valores distintos:

```json
{
  "dispositivo_id": "compostera-cf-01",
  "temperatura_c": 48,
  "humedad_pct": 60
}
```

La ruta esperada es:

```text
evaluar_estado → revisar_temperatura
```

Después prueba:

```json
{
  "dispositivo_id": "compostera-cf-01",
  "temperatura_c": 40,
  "humedad_pct": 45
}
```

La ruta esperada es:

```text
evaluar_estado → revisar_humedad
```

No es necesario cambiar el grafo.

## Diferencias entre tecnologías

```text
POSTGRESQL -> guarda histórico
MQTT -> mueve mensajes
FIWARE -> representa contexto actual interoperable
LANGGRAPH -> organiza un proceso con estado y decisiones
```

LangGraph no sustituye a FIWARE ni es un broker.

## Requisitos

```bash
pip install -r requirements.txt
```

## Ejecución

### Modo real

1. Levanta Orion-LD local.
2. Ejecuta:

```bash
python flujo_contexto.py
```

### Modo demo

```bash
python flujo_contexto.py --demo
```

## Tests

```bash
pytest -q
```

## Limitaciones

- No hay un agente con LLM.
- No se implementa reasoning generativo.
- No se registran secretos ni tokens.
- No se añade un segundo stack FIWARE.

## Puente hacia la siguiente experiencia

Ahora el workflow puede consultar contexto y decidir una ruta, pero el mensaje final sigue siendo escrito por nosotros.

La siguiente etapa será abrir esa decisión a un modelo para que explique la situación en lenguaje natural sin resolverla todavía.

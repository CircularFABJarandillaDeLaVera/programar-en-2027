import os
from dataclasses import dataclass
from datetime import datetime

import httpx

from modelos import TipoFichaje


TIMEOUT_ORION_LD = 2.0
CONTEXTO_NGSI_LD = "https://uri.etsi.org/ngsi-ld/v1/ngsi-ld-core-context.jsonld"


@dataclass
class ResultadoContexto:
    actualizado: bool
    mensaje_error: str | None = None


def obtener_orion_ld_url() -> str:
    return os.getenv("ORION_LD_URL", "http://localhost:1026").rstrip("/")


def construir_id_entidad(trabajador_id: int) -> str:
    return f"urn:ngsi-ld:Employee:{trabajador_id}"


def formatear_fecha_ngsi_ld(fecha_hora: datetime) -> str:
    return fecha_hora.isoformat().replace("+00:00", "Z")


def construir_atributos(tipo_evento: TipoFichaje, fecha_hora: datetime) -> dict:
    return {
        "working": {
            "type": "Property",
            "value": tipo_evento == "ENTRADA",
        },
        "lastEvent": {
            "type": "Property",
            "value": tipo_evento,
        },
        "lastEventAt": {
            "type": "Property",
            "value": formatear_fecha_ngsi_ld(fecha_hora),
        },
        "@context": [
            CONTEXTO_NGSI_LD,
        ],
    }


def construir_entidad(
    trabajador_id: int,
    tipo_evento: TipoFichaje,
    fecha_hora: datetime,
) -> dict:
    entidad = {
        "id": construir_id_entidad(trabajador_id),
        "type": "Employee",
    }
    entidad.update(construir_atributos(tipo_evento, fecha_hora))
    return entidad


def actualizar_contexto_trabajador(
    trabajador_id: int,
    tipo_evento: TipoFichaje,
    fecha_hora: datetime,
) -> ResultadoContexto:
    orion_ld_url = obtener_orion_ld_url()
    entity_id = construir_id_entidad(trabajador_id)
    atributos = construir_atributos(tipo_evento, fecha_hora)
    headers = {
        "Content-Type": "application/ld+json",
        "Accept": "application/ld+json",
    }

    try:
        with httpx.Client(timeout=TIMEOUT_ORION_LD) as cliente:
            respuesta_patch = cliente.patch(
                f"{orion_ld_url}/ngsi-ld/v1/entities/{entity_id}/attrs",
                json=atributos,
                headers=headers,
            )

            if respuesta_patch.status_code == 404:
                respuesta_post = cliente.post(
                    f"{orion_ld_url}/ngsi-ld/v1/entities",
                    json=construir_entidad(trabajador_id, tipo_evento, fecha_hora),
                    headers=headers,
                )
                if 200 <= respuesta_post.status_code < 300:
                    return ResultadoContexto(actualizado=True)

                return ResultadoContexto(
                    actualizado=False,
                    mensaje_error=f"Orion-LD respondio {respuesta_post.status_code} al crear la entidad",
                )

            if 200 <= respuesta_patch.status_code < 300:
                return ResultadoContexto(actualizado=True)

            return ResultadoContexto(
                actualizado=False,
                mensaje_error=f"Orion-LD respondio {respuesta_patch.status_code} al actualizar la entidad",
            )
    except httpx.TimeoutException:
        return ResultadoContexto(
            actualizado=False,
            mensaje_error="Timeout al actualizar Orion-LD",
        )
    except httpx.RequestError as exc:
        return ResultadoContexto(
            actualizado=False,
            mensaje_error=f"No se pudo conectar con Orion-LD: {exc.__class__.__name__}",
        )

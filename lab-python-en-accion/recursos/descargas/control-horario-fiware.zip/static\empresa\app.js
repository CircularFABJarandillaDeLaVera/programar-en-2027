const seccionesPrivadas = [
    document.querySelector("#panel"),
    document.querySelector("#alta"),
    document.querySelector("#resumen"),
    document.querySelector("#trabajadores"),
    document.querySelector("#fichajes"),
];

const login = document.querySelector("#login");
const formLogin = document.querySelector("#form-login");
const formTrabajador = document.querySelector("#form-trabajador");
const mensajeLogin = document.querySelector("#mensaje-login");
const mensajeTrabajador = document.querySelector("#mensaje-trabajador");
const usuarioActivo = document.querySelector("#usuario-activo");
const listaTrabajadores = document.querySelector("#lista-trabajadores");
const listaFichajes = document.querySelector("#lista-fichajes");
const listaResumen = document.querySelector("#lista-resumen");
const trabajandoAhora = document.querySelector("#trabajando-ahora");
const entradasHoy = document.querySelector("#entradas-hoy");
const salidasHoy = document.querySelector("#salidas-hoy");
const ultimaActividad = document.querySelector("#ultima-actividad");
const botonActualizar = document.querySelector("#boton-actualizar");
const botonSalir = document.querySelector("#boton-salir");

function mostrarMensaje(elemento, texto, tipo = "ok") {
    elemento.textContent = texto;
    elemento.className = `mensaje ${tipo}`;
}

function mostrarPanel(usuario) {
    login.classList.add("oculto");
    seccionesPrivadas.forEach((seccion) => seccion.classList.remove("oculto"));
    usuarioActivo.textContent = `Sesion de empresa: ${usuario.usuario}`;
}

function ocultarPanel() {
    login.classList.remove("oculto");
    seccionesPrivadas.forEach((seccion) => seccion.classList.add("oculto"));
    usuarioActivo.textContent = "";
}

async function leerRespuesta(respuesta) {
    const datos = await respuesta.json().catch(() => ({}));
    if (!respuesta.ok) {
        throw new Error(datos.detail || "No se pudo completar la operacion");
    }
    return datos;
}

async function cargarTrabajadores() {
    const respuesta = await fetch("/trabajadores");
    const trabajadores = await leerRespuesta(respuesta);

    if (trabajadores.length === 0) {
        listaTrabajadores.innerHTML = '<p class="muted">Todavia no hay trabajadores.</p>';
        return;
    }

    listaTrabajadores.innerHTML = trabajadores
        .map((trabajador) => `
            <article class="item">
                <strong>${trabajador.nombre}</strong>
                <span class="muted">ID ${trabajador.id}</span>
            </article>
        `)
        .join("");
}

function formatearMinutos(minutos) {
    const horas = Math.floor(minutos / 60);
    const restoMinutos = minutos % 60;

    if (horas === 0) {
        return `${restoMinutos} min`;
    }

    return `${horas} h ${restoMinutos} min`;
}

async function cargarResumen() {
    const respuesta = await fetch("/empresa/resumen");
    const resumen = await leerRespuesta(respuesta);

    trabajandoAhora.textContent = resumen.trabajando_ahora;
    entradasHoy.textContent = resumen.entradas_hoy;
    salidasHoy.textContent = resumen.salidas_hoy;

    if (resumen.ultima_actividad === null) {
        ultimaActividad.textContent = `Fecha local: ${resumen.fecha_local}. Todavia no hay actividad.`;
    } else {
        const fecha = new Date(resumen.ultima_actividad.fecha_hora).toLocaleString();
        ultimaActividad.textContent = `Fecha local: ${resumen.fecha_local}. Última actividad: ${resumen.ultima_actividad.trabajador_nombre} - ${resumen.ultima_actividad.tipo} (${fecha}).`;
    }

    if (resumen.trabajadores.length === 0) {
        listaResumen.innerHTML = '<p class="muted">Todavia no hay trabajadores.</p>';
        return;
    }

    listaResumen.innerHTML = resumen.trabajadores
        .map((trabajador) => {
            const ultimo = trabajador.ultimo_fichaje === null
                ? "Sin fichajes"
                : trabajador.ultimo_fichaje;
            const fecha = trabajador.ultima_actividad === null
                ? ""
                : `<br><span class="muted">${new Date(trabajador.ultima_actividad).toLocaleString()}</span>`;

            return `
                <article class="item">
                    <strong>${trabajador.nombre} - ${trabajador.estado}</strong>
                    <span>Último fichaje: ${ultimo}</span>${fecha}<br>
                    <span>Tiempo registrado hoy: ${formatearMinutos(trabajador.tiempo_cerrado_hoy_minutos)}</span>
                </article>
            `;
        })
        .join("");
}

async function cargarFichajes() {
    const respuesta = await fetch("/fichajes");
    const fichajes = await leerRespuesta(respuesta);

    if (fichajes.length === 0) {
        listaFichajes.innerHTML = '<p class="muted">Todavia no hay fichajes.</p>';
        return;
    }

    listaFichajes.innerHTML = fichajes
        .map((fichaje) => {
            const fecha = new Date(fichaje.fecha_hora).toLocaleString();
            const ubicacion = fichaje.latitud === null
                ? "Sin ubicacion"
                : `${fichaje.latitud}, ${fichaje.longitud} (${fichaje.precision_m} m)`;

            return `
                <article class="item">
                    <strong>${fichaje.trabajador_nombre} - ${fichaje.tipo}</strong>
                    <span>${fecha}</span><br>
                    <span class="muted">${ubicacion}</span>
                </article>
            `;
        })
        .join("");
}

async function refrescarDatos() {
    await cargarResumen();
    await cargarTrabajadores();
    await cargarFichajes();
}

async function comprobarSesion() {
    const respuesta = await fetch("/auth/me");
    if (!respuesta.ok) {
        ocultarPanel();
        return;
    }

    const usuario = await respuesta.json();
    if (usuario.rol !== "EMPRESA") {
        mostrarMensaje(mensajeLogin, "Esta pantalla esta reservada a la empresa", "error");
        ocultarPanel();
        return;
    }

    mostrarPanel(usuario);
    await refrescarDatos();
}

formLogin.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    mostrarMensaje(mensajeLogin, "");

    const datos = {
        usuario: document.querySelector("#login-usuario").value,
        password: document.querySelector("#login-password").value,
    };

    try {
        const respuesta = await fetch("/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datos),
        });
        const usuario = await leerRespuesta(respuesta);

        if (usuario.rol !== "EMPRESA") {
            await fetch("/auth/logout", { method: "POST" });
            throw new Error("Esta pantalla esta reservada a la empresa");
        }

        mostrarPanel(usuario);
        await refrescarDatos();
    } catch (error) {
        mostrarMensaje(mensajeLogin, error.message, "error");
    }
});

formTrabajador.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    mostrarMensaje(mensajeTrabajador, "");

    const datos = {
        nombre: document.querySelector("#trabajador-nombre").value,
        usuario: document.querySelector("#trabajador-usuario").value,
        password: document.querySelector("#trabajador-password").value,
    };

    try {
        const respuesta = await fetch("/trabajadores", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(datos),
        });
        await leerRespuesta(respuesta);
        formTrabajador.reset();
        mostrarMensaje(mensajeTrabajador, "Trabajador creado");
        await refrescarDatos();
    } catch (error) {
        mostrarMensaje(mensajeTrabajador, error.message, "error");
    }
});

botonActualizar.addEventListener("click", async () => {
    try {
        await refrescarDatos();
    } catch (error) {
        mostrarMensaje(mensajeTrabajador, error.message, "error");
    }
});

botonSalir.addEventListener("click", async () => {
    await fetch("/auth/logout", { method: "POST" });
    ocultarPanel();
});

comprobarSesion();

# Control horario conectado con FIWARE

Esta es una práctica temporal para preparar la Experiencia 18.

Venimos de dos ideas ya comprobadas:

```text
PostgreSQL conserva el histórico de fichajes.
Orion-LD publica el contexto actual que queremos compartir.
```

En la experiencia anterior actualizábamos Orion-LD a mano desde PowerShell.

Ahora queremos que lo haga Python cuando una persona ficha.

## 1. Qué problema resolvemos

Antes:

```text
trabajador ficha ENTRADA
  ↓
PostgreSQL guarda ENTRADA
```

Ahora:

```text
trabajador ficha ENTRADA
  ↓
PostgreSQL guarda ENTRADA
  ↓
Python envía HTTP + JSON
  ↓
Orion-LD publica contexto actual
```

La regla principal no cambia:

```text
POSTGRESQL = histórico
ORION-LD = contexto actual que publicamos
```

## 2. Configuración

Copia `.env.example` a `.env` y completa la conexión a PostgreSQL como en la práctica anterior.

Además aparece:

```text
ORION_LD_URL=http://localhost:1026
```

Esa URL indica dónde está escuchando Orion-LD.

No está escrita directamente dentro de las funciones: Python la lee desde la configuración.

## 3. Qué hace contexto_fiware.py

El archivo `contexto_fiware.py` concentra la comunicación con Orion-LD.

Contiene funciones pequeñas:

- construir el identificador NGSI-LD;
- construir el JSON de contexto;
- intentar actualizar Orion-LD;
- crear la entidad si todavía no existe;
- devolver éxito o fallo controlado.

Ejemplo:

```text
trabajador_id = 7
↓
urn:ngsi-ld:Employee:7
```

## 4. Qué datos se envían

Solo se envía el contexto mínimo:

- `working`
- `lastEvent`
- `lastEventAt`

ENTRADA:

```text
working = true
lastEvent = ENTRADA
```

SALIDA:

```text
working = false
lastEvent = SALIDA
```

`lastEventAt` usa la misma fecha/hora del fichaje que PostgreSQL acaba de guardar.

No se genera otra hora independiente para FIWARE.

## 5. Qué datos no se envían

Interoperable no significa publicar todo.

No se envía:

- nombre;
- latitud;
- longitud;
- `precision_m`;
- usuario;
- contraseña;
- hashes;
- sesiones;
- histórico de fichajes.

## 6. Qué ocurre en una ENTRADA

Orden obligatorio:

```text
1. FastAPI valida la sesión y el rol.
2. FastAPI comprueba que no haya otra ENTRADA abierta.
3. PostgreSQL guarda el fichaje histórico.
4. Python intenta actualizar Orion-LD.
```

Nunca se actualiza Orion-LD antes de guardar PostgreSQL.

El histórico tiene prioridad.

## 7. Qué ocurre en una SALIDA

Orden obligatorio:

```text
1. FastAPI valida la sesión y el rol.
2. FastAPI comprueba que exista una ENTRADA abierta.
3. PostgreSQL guarda la SALIDA histórica.
4. Python intenta actualizar Orion-LD.
```

## 8. PATCH y POST

Primero se intenta:

```text
PATCH /ngsi-ld/v1/entities/{entity_id}/attrs
```

Si la entidad no existe y Orion-LD responde `404`, entonces se crea:

```text
POST /ngsi-ld/v1/entities
```

La creación inicial contiene todas las propiedades que después vamos a actualizar:

- `working`
- `lastEvent`
- `lastEventAt`

No usamos operaciones batch ni upsert en esta experiencia.

## 9. Si Orion-LD falla

Este caso es importante:

```text
PostgreSQL guarda el fichaje.
Orion-LD está apagado o no responde.
```

Resultado:

```text
EL FICHAJE EXISTE.
```

No decimos "el fichaje ha fallado", porque sería falso.

La respuesta incluye:

```text
contexto_actualizado = false
aviso = "Fichaje registrado. Hay un problema temporal actualizando el estado compartido."
```

El frontend muestra el aviso sin presentar el fichaje como error.

FastAPI también registra un mensaje en servidor indicando que el fichaje histórico se guardó, pero el contexto no se actualizó.

## 10. Ejecutar tests automáticos

```powershell
python -m unittest -v test_api.py
```

Los tests no necesitan Orion-LD real para validar la lógica Python.

Usan mocks para comprobar:

- construcción de la URN;
- ENTRADA produce `working=true`;
- SALIDA produce `working=false`;
- `lastEventAt` procede del fichaje;
- entidad existente usa `PATCH`;
- entidad inexistente usa `PATCH` y después `POST`;
- error de conexión manejado;
- timeout manejado;
- fallo de contexto sin revertir el fichaje;
- autorización anterior intacta.

## 11. Validación real realizada

Esta práctica fue validada con PostgreSQL y Orion-LD reales.

CASO A: Orion-LD encendido

```text
ENTRADA
PostgreSQL guarda el fichaje.
Orion-LD publica working=true y lastEvent=ENTRADA.

SALIDA
PostgreSQL guarda el fichaje.
Orion-LD publica working=false y lastEvent=SALIDA.
```

CASO B: Orion-LD apagado

```text
PostgreSQL siguió guardando fichajes válidos.
La aplicación mostró el aviso.
FastAPI siguió operativo.
```

Durante el fallo se observó una situación importante:

```text
PostgreSQL:
último evento = ENTRADA

Orion-LD:
lastEvent = SALIDA
```

El histórico podía estar correcto mientras el contexto publicado quedaba desactualizado.

CASO C: Orion-LD recuperado

```text
El siguiente fichaje válido volvió a publicar el contexto actual.
```

Esto no reconstruye automáticamente todos los posibles estados perdidos. Solo demuestra que el siguiente evento puede volver a publicar el contexto vigente.

## 12. Qué no hacemos todavía

No implementamos reconstrucción automática de contexto.

Si Orion-LD queda desactualizado, PostgreSQL conserva suficiente información como para reconstruir posteriormente el contexto a partir del último fichaje.

Pero todavía no añadimos:

- reintentos automáticos;
- colas;
- jobs;
- Outbox;
- sincronizador;
- worker en background.

## 13. Dashboard

El dashboard sigue leyendo PostgreSQL.

No se modifica `/empresa/resumen` para consultar Orion-LD.

No rompemos una pieza ya validada para demostrar esta integración.
